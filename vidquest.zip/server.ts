import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Server-side Gemini Client
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build'
      }
    }
  });
};

// Health Check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// AI Quiz Generation API
app.post('/api/generate-quiz', async (req, res) => {
  try {
    const { youtubeUrl, videoTitle, contextDescription } = req.body;
    const ai = getGeminiClient();

    if (!ai) {
      // Smart contextual fallback questions when GEMINI_API_KEY is not configured
      const title = videoTitle || 'the video presentation';
      return res.json({
        questions: [
          {
            id: 'q1',
            question: `What is the core subject demonstrated in "${title}"?`,
            options: [
              `Core principles, practical demonstration, and key walkthrough of ${title}`,
              'Unrelated filler content without educational value',
              'Purely static background screen with no explanation',
              'Discredited practices not recommended for use'
            ],
            correctAnswerIndex: 0
          },
          {
            id: 'q2',
            question: 'Which key technique or insight was emphasized by the creator?',
            options: [
              'Systematic implementation and following verified industry standards',
              'Skipping configuration testing prior to launch',
              'Disregarding error indicators and log outputs',
              'Using unverified arbitrary workarounds'
            ],
            correctAnswerIndex: 0
          },
          {
            id: 'q3',
            question: 'How did the presenter demonstrate the effectiveness of the workflow?',
            options: [
              'Through step-by-step code/setup walkthrough and measurable outcomes',
              'By presenting theories without practical execution',
              'By showing simulated unrelated screenshots',
              'By skipping the core demonstration entirely'
            ],
            correctAnswerIndex: 0
          },
          {
            id: 'q4',
            question: 'What common mistake did the creator warn against during execution?',
            options: [
              'Overlooking prerequisite setup and environment configuration',
              'Checking validation errors early in the cycle',
              'Adhering strictly to official guidelines',
              'Maintaining clean modular architecture'
            ],
            correctAnswerIndex: 0
          },
          {
            id: 'q5',
            question: 'What is the primary conclusion viewers should apply from this video?',
            options: [
              'Iterative testing and verified best practices achieve optimal long-term results',
              'One-time viewing replaces practical hands-on application',
              'Documentation should be ignored in production',
              'Security and verification steps can be skipped safely'
            ],
            correctAnswerIndex: 0
          }
        ]
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `You are an educational video assessment specialist. Generate an engaging 5-question multiple choice quiz testing viewer comprehension of this video.
Video Title: ${videoTitle || 'YouTube Video'}
Video URL: ${youtubeUrl || ''}
Video Context: ${contextDescription || ''}

Rules:
1. Provide exactly 5 distinct multiple choice questions.
2. Each question must have 4 options.
3. Specify the zero-based index of the correct answer (0, 1, 2, or 3).
4. Questions must directly evaluate whether the viewer paid attention to the key concepts, instructions, or demonstrated techniques.
5. Return JSON adhering to the schema.`,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          description: 'Array of exactly 5 multiple choice questions',
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              question: { type: Type.STRING },
              options: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              correctAnswerIndex: { type: Type.INTEGER }
            },
            required: ['id', 'question', 'options', 'correctAnswerIndex']
          }
        }
      }
    });

    const parsed = JSON.parse(response.text?.trim() || '[]');
    res.json({ questions: parsed });
  } catch (err: unknown) {
    console.error('Quiz Generation Error:', err);
    res.status(500).json({ error: err instanceof Error ? err.message : 'Failed to generate quiz' });
  }
});

// Vite Middleware & Static Serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
