# VidQuest Security Specification & TDD Spec

## 1. Data Invariants
1. **Super Admin Exclusivity:** The Super Admin role and administrative access to `/admin` routes and review mutations (approving creators, activating campaigns with verified UTR, marking payouts as paid) are strictly locked to `mrinalkantisingharoy2009@gmail.com`.
2. **User Identity Boundary:** Authenticated users can only read and update their own `users/{userId}` record. A regular user cannot self-assign `role: "approved_creator"` or `role: "super_admin"`.
3. **Application Ownership:** A user can submit a creator application for their own UID (`request.auth.uid == resource.data.uid`). Only the Super Admin can transition `status` from `pending` to `approved` or `rejected`.
4. **Campaign Verification Boundary:** Only approved creators (or Super Admin) can create campaigns. Initial campaign status must be `pending_verification`. Only Super Admin can transition `pending_verification` to `active`. Active campaigns can be read by any authenticated user for the video feed.
5. **Withdrawal Integrity:** Users can only create withdrawal requests for their own account with valid tier amounts (e.g. 40, 50, 100). Only Super Admin can mark a withdrawal as `paid`. Marking as paid decrements `escrow_locked`.
6. **Quiz Anti-Cheat:** Users can only take a quiz once per campaign video ID; completing a quiz appends the video ID to `completed_quizzes`.

## 2. The "Dirty Dozen" Threat Payloads
1. **Payload 1 (Self-Privilege Escalation):** Regular user tries to write `role: "super_admin"` or `role: "approved_creator"` on `users/{userId}`.
2. **Payload 2 (Impersonation):** User A tries to create or overwrite `users/{userB}` where `userId != request.auth.uid`.
3. **Payload 3 (Direct Application Approval):** Regular user tries to create a creator application with `status: "approved"` directly.
4. **Payload 4 (Tampering with Someone Else's Application):** User A tries to approve or reject User B's creator application.
5. **Payload 5 (Unverified Campaign Self-Activation):** Creator submits a campaign with `status: "active"` bypassing UPI verification.
6. **Payload 6 (Unauthorized Campaign Activation):** Non-admin tries to change campaign `status` from `pending_verification` to `active`.
7. **Payload 7 (Fake Withdrawal Fulfill):** Regular user sets their own withdrawal request `status: "paid"`.
8. **Payload 8 (Foreign Payout Tampering):** User A updates User B's withdrawal payment details or deletes it.
9. **Payload 9 (Oversized ID Injection):** Malicious user attempts to create document with 2000-character junk ID string (denial-of-wallet).
10. **Payload 10 (Negative or Arbitrary Withdrawal Request):** Malicious user creates withdrawal with negative amount or arbitrary float.
11. **Payload 11 (Campaign Creator Spoofing):** User A creates a campaign with `creator_uid: userB`.
12. **Payload 12 (Ghost Field Attack):** Malicious client sends extra unexpected fields (`isSuperUser: true`, `backdoor: true`) into user doc.

All twelve payloads must be strictly blocked by Firestore Security Rules.
