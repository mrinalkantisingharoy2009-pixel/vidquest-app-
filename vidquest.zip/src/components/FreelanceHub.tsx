import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Briefcase,
  ExternalLink,
  Clock,
  DollarSign,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  RefreshCw,
  Send,
  FileCheck,
  Film,
  User,
  Filter,
  Layers,
  ChevronRight,
  Info
} from 'lucide-react';
import {
  FreelanceJob,
  FreelanceApplication,
  FreelanceJobCategory,
  MARKET_RATE_BENCHMARKS
} from '../types';
import {
  getOpenFreelanceJobs,
  getMyFreelanceApplications,
  applyForFreelanceJob,
  submitJobDeliverable
} from '../services/freelanceService';

interface FreelanceHubProps {
  openAuthModal: () => void;
}

export const FreelanceHub: React.FC<FreelanceHubProps> = ({ openAuthModal }) => {
  const { currentUser } = useAuth();

  const [activeTab, setActiveTab] = useState<'browse' | 'my_work'>('browse');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [openJobs, setOpenJobs] = useState<FreelanceJob[]>([]);
  const [myApplications, setMyApplications] = useState<FreelanceApplication[]>([]);
  const [loading, setLoading] = useState(false);

  // Application Modal State
  const [applyingJob, setApplyingJob] = useState<FreelanceJob | null>(null);
  const [portfolioLink, setPortfolioLink] = useState('');
  const [pitch, setPitch] = useState('');
  const [turnaroundCommitment, setTurnaroundCommitment] = useState('');
  const [upiId, setUpiId] = useState('');
  const [isApplying, setIsApplying] = useState(false);
  const [applySuccess, setApplySuccess] = useState(false);
  const [applyError, setApplyError] = useState<string | null>(null);

  // Work Submission Modal State (for accepted editors)
  const [submittingWorkApp, setSubmittingWorkApp] = useState<FreelanceApplication | null>(null);
  const [deliverableUrl, setDeliverableUrl] = useState('');
  const [deliverableNotes, setDeliverableNotes] = useState('');
  const [isSubmittingWork, setIsSubmittingWork] = useState(false);
  const [workSubmitSuccess, setWorkSubmitSuccess] = useState(false);
  const [workSubmitError, setWorkSubmitError] = useState<string | null>(null);

  const loadOpenJobs = async () => {
    setLoading(true);
    try {
      const jobs = await getOpenFreelanceJobs();
      setOpenJobs(jobs);
    } catch (err) {
      console.error('Error fetching open jobs:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadMyApplications = async () => {
    if (!currentUser) return;
    try {
      const apps = await getMyFreelanceApplications(currentUser.uid);
      setMyApplications(apps);
    } catch (err) {
      console.error('Error fetching my applications:', err);
    }
  };

  useEffect(() => {
    loadOpenJobs();
    if (currentUser) {
      loadMyApplications();
    }
  }, [currentUser]);

  const handleApply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      openAuthModal();
      return;
    }
    if (!applyingJob || !applyingJob.id) return;
    setApplyError(null);

    if (!portfolioLink.trim()) {
      setApplyError('Please provide a valid link to your portfolio or sample edit work.');
      return;
    }
    if (!pitch.trim() || pitch.trim().length < 15) {
      setApplyError('Please write a brief pitch explaining your experience and editing tools.');
      return;
    }
    if (!upiId.trim() || !upiId.includes('@')) {
      setApplyError('Please provide a valid UPI ID (e.g. name@okhdfcbank) so the Super Admin can disburse your payout upon completion.');
      return;
    }

    setIsApplying(true);
    try {
      await applyForFreelanceJob({
        job_id: applyingJob.id,
        job_title: applyingJob.title,
        freelancer_uid: currentUser.uid,
        freelancer_email: currentUser.email || 'freelancer@vidquest.com',
        freelancer_name: currentUser.displayName || 'Freelance Editor',
        portfolio_link: portfolioLink.trim(),
        pitch: pitch.trim(),
        turnaround_commitment: turnaroundCommitment.trim() || `${applyingJob.turnaround_days} Days`,
        upi_id: upiId.trim()
      });

      setApplySuccess(true);
      loadOpenJobs();
      loadMyApplications();
    } catch (err: unknown) {
      setApplyError(err instanceof Error ? err.message : 'Application submission failed');
    } finally {
      setIsApplying(false);
    }
  };

  const handleSubmitWork = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!submittingWorkApp || !submittingWorkApp.job_id || !submittingWorkApp.id) return;
    setWorkSubmitError(null);

    if (!deliverableUrl.trim()) {
      setWorkSubmitError('Please provide a valid link to your finished video files (e.g. Google Drive, WeTransfer, or unlisted YouTube).');
      return;
    }

    setIsSubmittingWork(true);
    try {
      await submitJobDeliverable(
        submittingWorkApp.job_id,
        submittingWorkApp.id,
        deliverableUrl.trim(),
        deliverableNotes.trim()
      );
      setWorkSubmitSuccess(true);
      loadMyApplications();
    } catch (err: unknown) {
      setWorkSubmitError(err instanceof Error ? err.message : 'Deliverable submission failed');
    } finally {
      setIsSubmittingWork(false);
    }
  };

  const filteredJobs = selectedCategory === 'all'
    ? openJobs
    : openJobs.filter((job) => job.category === selectedCategory);

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8">
      {/* Hero Marketplace Banner */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-indigo-950 via-slate-900 to-purple-950 border border-indigo-500/30 p-6 sm:p-10 shadow-2xl">
        <div className="max-w-2xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
            <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
            <span>VidQuest Freelance Marketplace</span>
          </div>

          <h1 className="text-2xl sm:text-4xl font-extrabold text-white tracking-tight leading-tight">
            Earn as a Video Editor & Content Creator for YouTube
          </h1>

          <p className="text-sm text-slate-300 leading-relaxed">
            Creators deposit 100% of their project budget into Super Admin escrow before jobs go live. Browse open editing tasks, submit your portfolio, and receive verified UPI payouts upon delivery!
          </p>

          <div className="flex flex-wrap items-center gap-4 pt-2 text-xs text-slate-300">
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>100% Escrow Guaranteed</span>
            </div>
            <div className="flex items-center gap-1.5">
              <DollarSign className="w-4 h-4 text-amber-400" />
              <span>Low 10%–15% Platform Fee</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-indigo-400" />
              <span>Direct UPI Disbursal</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Navigation Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-2xl p-1">
          <button
            onClick={() => setActiveTab('browse')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'browse'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Browse Open Jobs ({openJobs.length})
          </button>
          <button
            onClick={() => {
              if (!currentUser) {
                openAuthModal();
                return;
              }
              setActiveTab('my_work');
              loadMyApplications();
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'my_work'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            My Work & Applications ({myApplications.length})
          </button>
        </div>

        <button
          onClick={() => { loadOpenJobs(); if (currentUser) loadMyApplications(); }}
          className="text-xs text-slate-400 hover:text-white flex items-center gap-1 self-start sm:self-auto"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Listings</span>
        </button>
      </div>

      {activeTab === 'browse' ? (
        <div className="space-y-6">
          {/* Category Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedCategory === 'all'
                  ? 'bg-indigo-600 text-white shadow'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              All Categories ({openJobs.length})
            </button>
            {(Object.keys(MARKET_RATE_BENCHMARKS) as FreelanceJobCategory[]).map((catKey) => {
              const count = openJobs.filter((j) => j.category === catKey).length;
              const isSelected = selectedCategory === catKey;
              return (
                <button
                  key={catKey}
                  onClick={() => setSelectedCategory(catKey)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                    isSelected
                      ? 'bg-indigo-600 text-white shadow'
                      : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {MARKET_RATE_BENCHMARKS[catKey].name} ({count})
                </button>
              );
            })}
          </div>

          {/* Jobs Listing */}
          {loading ? (
            <div className="py-16 text-center text-slate-400 text-xs flex items-center justify-center gap-2">
              <RefreshCw className="w-5 h-5 animate-spin text-indigo-400" />
              <span>Loading verified freelance jobs...</span>
            </div>
          ) : filteredJobs.length === 0 ? (
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center space-y-3">
              <Briefcase className="w-12 h-12 text-slate-600 mx-auto" />
              <h3 className="text-base font-bold text-white">No Open Jobs In This Category</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                All submitted jobs are currently in review or assigned. Creators post new editing jobs frequently, so check back shortly!
              </p>
            </div>
          ) : (
            <div className="grid gap-4 sm:gap-6">
              {filteredJobs.map((job) => {
                const benchmark = MARKET_RATE_BENCHMARKS[job.category] || MARKET_RATE_BENCHMARKS.video_editing;
                return (
                  <div
                    key={job.id}
                    className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 sm:p-7 space-y-4 hover:border-slate-700 transition-all shadow-lg"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                      <div className="space-y-1.5">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/15 text-indigo-300 border border-indigo-500/30">
                            {benchmark.name}
                          </span>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                            <ShieldCheck className="w-3 h-3" />
                            <span>Escrow Verified</span>
                          </span>
                          <span className="text-[11px] text-slate-400 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            <span>Turnaround: {job.turnaround_days} Days</span>
                          </span>
                        </div>

                        <h3 className="text-lg font-bold text-white tracking-tight">{job.title}</h3>
                        <p className="text-xs text-slate-400">
                          Posted by: <span className="text-slate-300 font-medium">{job.creator_name || job.creator_email}</span> • {new Date(job.createdAt).toLocaleDateString()}
                        </p>
                      </div>

                      {/* Financial Card: Net Payout */}
                      <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 sm:text-right shrink-0">
                        <div className="text-[11px] text-slate-400 uppercase tracking-wider font-semibold">
                          Net Editor Payout
                        </div>
                        <div className="text-2xl font-mono font-bold text-emerald-400">
                          ₹{job.editor_net_payout.toLocaleString('en-IN')}
                        </div>
                        <div className="text-[10px] text-slate-500 mt-0.5">
                          Total Budget: ₹{job.budget} (Fee: ₹{job.platform_fee_amount})
                        </div>
                      </div>
                    </div>

                    <p className="text-xs text-slate-300 leading-relaxed bg-slate-950/60 p-4 rounded-2xl border border-slate-800/80">
                      {job.description}
                    </p>

                    <div className="flex flex-wrap items-center justify-between gap-4 pt-2 border-t border-slate-800/80">
                      <div className="flex flex-wrap items-center gap-4 text-xs">
                        <a
                          href={job.raw_footage_url}
                          target="_blank"
                          rel="noreferrer"
                          className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1 underline font-medium"
                        >
                          <Film className="w-3.5 h-3.5" />
                          <span>Inspect Raw Footage / Assets Folder</span>
                        </a>

                        {job.reference_video_url && (
                          <a
                            href={job.reference_video_url}
                            target="_blank"
                            rel="noreferrer"
                            className="text-purple-400 hover:text-purple-300 flex items-center gap-1 underline font-medium"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                            <span>Style Reference Video</span>
                          </a>
                        )}
                      </div>

                      <button
                        onClick={() => {
                          if (!currentUser) {
                            openAuthModal();
                            return;
                          }
                          setApplyingJob(job);
                          setApplySuccess(false);
                          setApplyError(null);
                        }}
                        className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl shadow-lg shadow-indigo-950/50 flex items-center gap-1.5 transition-all"
                      >
                        <Send className="w-3.5 h-3.5" />
                        <span>Apply for this Job</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : (
        /* My Work & Applications Tab */
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white">Your Submitted Applications</h3>
            <span className="text-xs text-slate-400">Total: {myApplications.length}</span>
          </div>

          {myApplications.length === 0 ? (
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center space-y-3">
              <FileCheck className="w-12 h-12 text-slate-600 mx-auto" />
              <h3 className="text-base font-bold text-white">No Applications Yet</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                You haven't applied for any editing jobs yet. Browse open jobs to find projects matching your skills!
              </p>
              <button
                onClick={() => setActiveTab('browse')}
                className="px-4 py-2 bg-indigo-600 text-white text-xs font-semibold rounded-xl"
              >
                Browse Open Jobs
              </button>
            </div>
          ) : (
            <div className="grid gap-4">
              {myApplications.map((app) => (
                <div
                  key={app.id}
                  className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                    <div>
                      <h4 className="text-sm font-bold text-white">{app.job_title || 'Freelance Editing Job'}</h4>
                      <p className="text-[11px] text-slate-400">
                        Applied: {new Date(app.createdAt).toLocaleDateString()} • Your UPI: <span className="font-mono text-slate-300">{app.upi_id}</span>
                      </p>
                    </div>

                    <div>
                      {app.status === 'pending' && (
                        <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-500/15 text-amber-300 border border-amber-500/30">
                          Application Under Review
                        </span>
                      )}
                      {app.status === 'accepted' && (
                        <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                          Hired! Complete Deliverable
                        </span>
                      )}
                      {app.status === 'work_submitted' && (
                        <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                          Work Submitted — Pending Review & Payout
                        </span>
                      )}
                      {app.status === 'rejected' && (
                        <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-slate-800 text-slate-400 border border-slate-700">
                          Not Selected
                        </span>
                      )}
                    </div>
                  </div>

                  <p className="text-xs text-slate-300">
                    <span className="text-slate-500">Your Pitch:</span> "{app.pitch}"
                  </p>

                  <div className="flex flex-wrap items-center justify-between gap-3 pt-2 text-xs">
                    <a
                      href={app.portfolio_link}
                      target="_blank"
                      rel="noreferrer"
                      className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1 underline"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>Your Portfolio Link</span>
                    </a>

                    {app.status === 'accepted' && (
                      <button
                        onClick={() => {
                          setSubmittingWorkApp(app);
                          setWorkSubmitSuccess(false);
                          setWorkSubmitError(null);
                        }}
                        className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow"
                      >
                        <Film className="w-3.5 h-3.5" />
                        <span>Submit Finished Video Work</span>
                      </button>
                    )}

                    {app.status === 'work_submitted' && app.work_deliverable_url && (
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] text-slate-400">Delivered:</span>
                        <a
                          href={app.work_deliverable_url}
                          target="_blank"
                          rel="noreferrer"
                          className="text-cyan-400 underline font-mono text-[11px]"
                        >
                          View Deliverable Link
                        </a>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Application Modal */}
      {applyingJob && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 max-w-lg w-full space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-white">Apply for Job</h3>
                <p className="text-xs text-slate-400">{applyingJob.title}</p>
              </div>
              <button
                onClick={() => setApplyingJob(null)}
                className="text-slate-400 hover:text-white text-xs font-semibold px-2 py-1 bg-slate-800 rounded-lg"
              >
                Close
              </button>
            </div>

            {applySuccess ? (
              <div className="text-center py-6 space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/20">
                  <CheckCircle2 className="w-7 h-7" />
                </div>
                <h4 className="text-base font-bold text-white">Application Submitted!</h4>
                <p className="text-xs text-slate-300">
                  The creator will review your portfolio. If selected, you'll receive notification to begin editing!
                </p>
                <button
                  onClick={() => { setApplyingJob(null); setActiveTab('my_work'); }}
                  className="px-5 py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-bold"
                >
                  View My Applications
                </button>
              </div>
            ) : (
              <form onSubmit={handleApply} className="space-y-4">
                {applyError && (
                  <div className="p-3 bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs rounded-xl flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                    <span>{applyError}</span>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Portfolio / Sample Edit Link <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="url"
                    value={portfolioLink}
                    onChange={(e) => setPortfolioLink(e.target.value)}
                    placeholder="https://youtube.com/watch?v=... or Google Drive / Behance link"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                    required
                  />
                  <p className="text-[10px] text-slate-500 mt-1">
                    Show your best relevant edit so the creator can evaluate your style.
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Your Pitch & Software Used <span className="text-rose-400">*</span>
                  </label>
                  <textarea
                    rows={3}
                    value={pitch}
                    onChange={(e) => setPitch(e.target.value)}
                    placeholder="Explain why you're a good fit, what software you use (Premiere, DaVinci, CapCut, After Effects), and how fast you can deliver..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Turnaround Commitment
                  </label>
                  <input
                    type="text"
                    value={turnaroundCommitment}
                    onChange={(e) => setTurnaroundCommitment(e.target.value)}
                    placeholder={`e.g. Within ${applyingJob.turnaround_days} Days`}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Your UPI ID (For Direct Payout) <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                    placeholder="yourname@okhdfcbank or yournumber@upi"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 font-mono focus:outline-none focus:border-indigo-500"
                    required
                  />
                  <p className="text-[10px] text-slate-500 mt-1">
                    Net Payout upon job completion: <span className="text-emerald-400 font-bold font-mono">₹{applyingJob.editor_net_payout}</span>
                  </p>
                </div>

                <button
                  type="submit"
                  disabled={isApplying}
                  className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-lg transition-all flex items-center justify-center gap-2"
                >
                  {isApplying ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Submitting Application...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>Send Application to Creator</span>
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Work Submission Modal */}
      {submittingWorkApp && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 max-w-lg w-full space-y-5">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-white">Submit Finished Deliverable</h3>
                <p className="text-xs text-slate-400">{submittingWorkApp.job_title}</p>
              </div>
              <button
                onClick={() => setSubmittingWorkApp(null)}
                className="text-slate-400 hover:text-white text-xs font-semibold px-2 py-1 bg-slate-800 rounded-lg"
              >
                Close
              </button>
            </div>

            {workSubmitSuccess ? (
              <div className="text-center py-6 space-y-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/20">
                  <CheckCircle2 className="w-7 h-7" />
                </div>
                <h4 className="text-base font-bold text-white">Deliverable Work Received!</h4>
                <p className="text-xs text-slate-300">
                  Your work link has been transmitted to the creator and Super Admin. Once the edit is reviewed, your payout will be disbursed to your UPI ID.
                </p>
                <button
                  onClick={() => setSubmittingWorkApp(null)}
                  className="px-5 py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-bold"
                >
                  Done
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmitWork} className="space-y-4">
                {workSubmitError && (
                  <div className="p-3 bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs rounded-xl flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                    <span>{workSubmitError}</span>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Deliverable Video / File URL <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="url"
                    value={deliverableUrl}
                    onChange={(e) => setDeliverableUrl(e.target.value)}
                    placeholder="https://drive.google.com/file/... or WeTransfer / unlisted YouTube link"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                    required
                  />
                  <p className="text-[10px] text-slate-500 mt-1">
                    Make sure share permissions are set to "Anyone with the link can view/download".
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Delivery Notes / Revision Info
                  </label>
                  <textarea
                    rows={3}
                    value={deliverableNotes}
                    onChange={(e) => setDeliverableNotes(e.target.value)}
                    placeholder="Mention resolution (1080p/4K), color grade LUT used, audio balance notes, or any revisions made..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmittingWork}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-lg transition-all flex items-center justify-center gap-2"
                >
                  {isSubmittingWork ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Submitting Deliverable...</span>
                    </>
                  ) : (
                    <>
                      <FileCheck className="w-4 h-4" />
                      <span>Submit Completed Work</span>
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
