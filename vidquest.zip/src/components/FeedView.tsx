import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Play,
  Award,
  CheckCircle2,
  Users,
  Coins,
  Sparkles,
  ExternalLink,
  ShieldCheck,
  Video,
  Clock,
  Flame,
  Plus,
  Film,
  X,
  Trash2,
  AlertTriangle
} from 'lucide-react';
import { Campaign } from '../types';
import { getActiveCampaigns, createCampaign, deleteCampaign } from '../services/campaignService';
import { QuizModal } from './QuizModal';
import { creditWatchRewardDirectly } from '../services/quizService';
import { SUPER_ADMIN_EMAIL } from '../lib/firebase';

interface FeedViewProps {
  onGoToCreatorStudio: () => void;
  openAuthModal: () => void;
}

const getDeletedCampaignIds = (): string[] => {
  try {
    const raw = localStorage.getItem('vidquest_deleted_campaigns');
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
};

const markCampaignDeleted = (id: string) => {
  try {
    const current = getDeletedCampaignIds();
    if (!current.includes(id)) {
      localStorage.setItem('vidquest_deleted_campaigns', JSON.stringify([...current, id]));
    }
  } catch (e) {
    console.error('Failed to store deleted campaign id:', e);
  }
};

export const FeedView: React.FC<FeedViewProps> = ({
  onGoToCreatorStudio,
  openAuthModal
}) => {
  const { currentUser, userProfile, isSuperAdmin } = useAuth();
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(null);
  const [isQuizOpen, setIsQuizOpen] = useState(false);
  const [activeVideoId, setActiveVideoId] = useState<string | null>(null);
  const [activeTeaserId, setActiveTeaserId] = useState<string | null>(null);
  const [deleteModalCampaign, setDeleteModalCampaign] = useState<Campaign | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteToast, setDeleteToast] = useState<string | null>(null);
  const [watchClaimingId, setWatchClaimingId] = useState<string | null>(null);
  const [claimToast, setClaimToast] = useState<string | null>(null);

  const fetchCampaigns = async () => {
    setLoading(true);
    const deletedIds = getDeletedCampaignIds();
    try {
      const activeList = await getActiveCampaigns();
      // Strict rule: Only show and play verified active campaigns that are accepted by Super Admin
      const filteredActive = (activeList || []).filter(
        (c) => c.id && !deletedIds.includes(c.id) && c.status === 'active' && c.super_admin_accepted !== false
      );
      setCampaigns(filteredActive);
    } catch (err) {
      console.warn('Feed load error:', err);
      setCampaigns([]);
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteCampaign = async (campaign: Campaign) => {
    if (!campaign.id) return;
    setIsDeleting(true);
    try {
      await deleteCampaign(campaign.id);
      markCampaignDeleted(campaign.id);
      setCampaigns((prev) => prev.filter((c) => c.id !== campaign.id));
      setDeleteModalCampaign(null);
      setDeleteToast(`"${campaign.title || 'Video Campaign'}" deleted successfully.`);
      setTimeout(() => setDeleteToast(null), 4000);
    } catch (err: unknown) {
      alert('Error deleting campaign: ' + (err instanceof Error ? err.message : String(err)));
    } finally {
      setIsDeleting(false);
    }
  };

  useEffect(() => {
    fetchCampaigns();
  }, []);

  const handleOpenQuiz = (campaign: Campaign) => {
    if (!currentUser) {
      openAuthModal();
      return;
    }
    setSelectedCampaign(campaign);
    setIsQuizOpen(true);
  };

  const handleClaimDirectWatch = async (campaign: Campaign) => {
    if (!currentUser) {
      openAuthModal();
      return;
    }
    const videoId = campaign.video_id || campaign.id || 'sample_vid';
    const isTest = Boolean(
      campaign.is_test ||
      (campaign.creator_email && campaign.creator_email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase()) ||
      campaign.utr_number === 'SUPER_ADMIN_TEST_BYPASS' ||
      (campaign.reward_coins === 0 && campaign.budget === 0)
    );
    const rewardCoins = isTest ? 0 : (campaign.reward_coins || 50);

    setWatchClaimingId(campaign.id || videoId);
    try {
      const res = await creditWatchRewardDirectly(currentUser.uid, videoId, rewardCoins);
      if (res?.passed) {
        setClaimToast(res.message);
        setTimeout(() => setClaimToast(null), 4500);
      }
    } catch (err: unknown) {
      alert(err instanceof Error ? err.message : 'Failed to claim reward');
    } finally {
      setWatchClaimingId(null);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Toast Notification */}
      {deleteToast && (
        <div className="mb-6 p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center justify-between shadow-lg animate-in fade-in">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="font-medium">{deleteToast}</span>
          </div>
          <button
            type="button"
            onClick={() => setDeleteToast(null)}
            className="text-emerald-400 hover:text-white p-1 rounded-lg transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {claimToast && (
        <div className="mb-6 p-4 rounded-2xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-200 text-xs flex items-center justify-between shadow-lg animate-in fade-in">
          <div className="flex items-center gap-2.5">
            <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="font-semibold">{claimToast}</span>
          </div>
          <button
            type="button"
            onClick={() => setClaimToast(null)}
            className="text-emerald-400 hover:text-white p-1 rounded-lg transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Feed Hero Header */}
      <div className="mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/60 border border-slate-800 p-6 rounded-3xl backdrop-blur-sm">
        <div>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 text-amber-400 text-xs font-semibold mb-2 border border-amber-500/20">
            <Flame className="w-3.5 h-3.5" />
            <span>Active Creator Campaigns</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
            Watch, Learn & Earn Escrow Rewards
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-xl">
            Watch creator videos, score 4/5 or higher on the verification quiz, and earn instant coin balance credited directly to your wallet.
          </p>
        </div>

        <div className="flex sm:flex-col items-center gap-2">
          <button
            id="feed-launch-campaign-btn"
            onClick={onGoToCreatorStudio}
            className="w-full sm:w-auto px-4 py-2.5 bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-white font-semibold text-xs rounded-xl shadow-lg shadow-rose-950/40 transition-all flex items-center justify-center gap-2 shrink-0"
          >
            <Video className="w-4 h-4" />
            <span>Launch Campaign</span>
          </button>
        </div>
      </div>

      {/* Campaigns Feed List */}
      {loading ? (
        <div className="space-y-6">
          {[1, 2].map((i) => (
            <div key={i} className="bg-slate-900 border border-slate-800 rounded-3xl p-6 animate-pulse h-96" />
          ))}
        </div>
      ) : campaigns.length === 0 ? (
        <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-12 text-center text-slate-400">
          <Video className="w-12 h-12 mx-auto mb-3 text-slate-600" />
          <h3 className="text-lg font-bold text-white">No Active Campaigns Live Right Now</h3>
          <p className="text-xs text-slate-400 mt-1 mb-5 max-w-md mx-auto">
            Only verified campaigns accepted by the Super Admin appear on the feed. No unverified or unpaid placeholder videos will ever play here.
          </p>
          <button
            onClick={onGoToCreatorStudio}
            className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow transition-colors"
          >
            Launch Campaign in Creator Studio
          </button>
        </div>
      ) : (
        <div className="space-y-8">
          {campaigns.map((camp) => {
            const videoId = camp.video_id || 'dQw4w9WgXcQ';
            const isCompleted = userProfile?.completed_quizzes?.includes(videoId);
            const isPlaying = activeVideoId === camp.id;
            const isTest = Boolean(
              camp.is_test ||
              (camp.creator_email && camp.creator_email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase()) ||
              camp.utr_number === 'SUPER_ADMIN_TEST_BYPASS' ||
              (camp.reward_coins === 0 && camp.budget === 0)
            );

            return (
              <article
                key={camp.id}
                id={`campaign-card-${camp.id}`}
                className={`bg-slate-900 border rounded-3xl overflow-hidden shadow-xl transition-all ${
                  isTest
                    ? 'border-amber-500/30 hover:border-amber-500/50 bg-gradient-to-b from-slate-900 to-slate-950'
                    : 'border-slate-800 hover:border-slate-700/80'
                }`}
              >
                {/* Video Player / Thumbnail / Teaser Stage */}
                <div className="relative aspect-video w-full bg-slate-950 overflow-hidden group">
                  {activeTeaserId === camp.id && camp.teaser_url ? (
                    <div className="relative w-full h-full bg-black flex items-center justify-center">
                      <video
                        src={camp.teaser_url}
                        controls
                        autoPlay
                        playsInline
                        className="w-full h-full object-contain"
                      />
                      <div className="absolute top-4 left-4 flex items-center gap-2 z-10 pointer-events-none">
                        <span className="px-2.5 py-1 rounded-lg bg-purple-600/90 text-white font-bold text-xs flex items-center gap-1.5 shadow-lg backdrop-blur-md border border-purple-400/30">
                          <Film className="w-3.5 h-3.5 text-purple-200" />
                          <span>15s Teaser Hook</span>
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setActiveTeaserId(null)}
                        className="absolute top-4 right-4 px-2.5 py-1 rounded-lg bg-slate-900/90 hover:bg-slate-800 text-white font-semibold text-xs flex items-center gap-1 border border-slate-700 shadow-lg z-10 transition-colors"
                      >
                        <X className="w-3.5 h-3.5" />
                        <span>Close Teaser</span>
                      </button>
                    </div>
                  ) : isPlaying ? (
                    <iframe
                      src={`https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&rel=0`}
                      title={camp.title || 'Video'}
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                      className="w-full h-full border-0"
                    />
                  ) : (
                    <>
                      <img
                        src={`https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`}
                        onError={(e) => {
                          // Fallback to hqdefault
                          (e.target as HTMLImageElement).src = `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
                        }}
                        alt={camp.title || 'Video thumbnail'}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />

                      {/* Play Button Overlay */}
                      <button
                        id={`play-video-btn-${camp.id}`}
                        onClick={() => {
                          setActiveVideoId(camp.id || null);
                          setActiveTeaserId(null);
                        }}
                        className="absolute inset-0 flex items-center justify-center group/btn"
                        aria-label="Play Video"
                      >
                        <div className="w-16 h-16 rounded-2xl bg-rose-600 text-white flex items-center justify-center shadow-2xl group-hover/btn:scale-110 group-hover/btn:bg-rose-500 transition-all">
                          <Play className="w-7 h-7 fill-white translate-x-0.5" />
                        </div>
                      </button>

                      {/* 15s Teaser Hook Button */}
                      {camp.teaser_url && (
                        <button
                          id={`watch-teaser-btn-${camp.id}`}
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setActiveTeaserId(camp.id || null);
                            setActiveVideoId(null);
                          }}
                          className="absolute bottom-4 right-4 px-3 py-1.5 rounded-xl bg-purple-600/90 hover:bg-purple-500 text-white font-semibold text-xs flex items-center gap-1.5 shadow-lg backdrop-blur-md border border-purple-400/30 z-10 transition-transform hover:scale-105"
                        >
                          <Film className="w-3.5 h-3.5 text-purple-200" />
                          <span>Watch 15s Teaser</span>
                        </button>
                      )}

                      {/* Verification Tag */}
                      <div className="absolute top-4 left-4 flex items-center gap-2">
                        {isTest ? (
                          <span className="px-2.5 py-1 rounded-lg bg-amber-500 text-slate-950 font-black text-xs flex items-center gap-1 shadow-lg shadow-amber-950/60">
                            <Sparkles className="w-3.5 h-3.5 text-slate-950" />
                            <span>Only for Test Purposes</span>
                          </span>
                        ) : (
                          <span className="px-2.5 py-1 rounded-lg bg-black/70 backdrop-blur-md text-emerald-400 text-xs font-semibold flex items-center gap-1 border border-emerald-500/30">
                            <ShieldCheck className="w-3.5 h-3.5" />
                            <span>Escrow Verified</span>
                          </span>
                        )}
                      </div>

                      {/* Reward Badge */}
                      <div className="absolute top-4 right-4">
                        {isTest ? (
                          <span className="px-3 py-1 rounded-xl bg-slate-950/90 border border-amber-500/40 text-amber-300 font-bold text-xs flex items-center gap-1.5 shadow-lg backdrop-blur-md">
                            <Coins className="w-3.5 h-3.5 text-amber-400" />
                            <span>₹0 (Test Purpose Only — No Money)</span>
                          </span>
                        ) : (
                          <span className="px-3 py-1 rounded-xl bg-amber-500 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-amber-950/50">
                            <Coins className="w-3.5 h-3.5" />
                            <span>+₹{camp.reward_coins || 50} Coins</span>
                          </span>
                        )}
                      </div>
                    </>
                  )}
                </div>

                {/* Campaign Info & Quiz Trigger */}
                <div className="p-6 space-y-4">
                  {(() => {
                    const isTargetReached = (camp.views_count || 0) >= (camp.target_views || 1000);
                    const isSuperAdminUser = currentUser?.email?.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase();
                    const isCreatorOwner = Boolean(currentUser && camp.creator_uid && currentUser.uid === camp.creator_uid);
                    const canDelete = isSuperAdminUser || isCreatorOwner;

                    return (
                      <>
                        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                          <div className="space-y-1">
                            <div className="flex items-center gap-2 text-xs text-slate-400 flex-wrap">
                              <span className="font-semibold text-slate-300">
                                {isTest ? 'Admin Test Demo' : (camp.creator_name || camp.creator_email?.split('@')[0] || 'Verified Creator')}
                              </span>
                              <span>•</span>
                              <span className="flex items-center gap-1">
                                <Users className="w-3 h-3 text-slate-500" />
                                {camp.views_count || 0} / {camp.target_views || 1000} views
                              </span>
                              {isTargetReached && (
                                <>
                                  <span>•</span>
                                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold flex items-center gap-1">
                                    🎯 Target Audience Reached
                                  </span>
                                </>
                              )}
                              {isTest && (
                                <>
                                  <span>•</span>
                                  <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold">
                                    🧪 Only for Test Purposes
                                  </span>
                                </>
                              )}
                              {camp.teaser_url && (
                                <>
                                  <span>•</span>
                                  <span className="px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30 text-[10px] font-semibold flex items-center gap-1">
                                    <Film className="w-2.5 h-2.5 text-purple-400" />
                                    <span>15s Teaser</span>
                                  </span>
                                </>
                              )}
                            </div>

                            <h2 className="text-lg sm:text-xl font-bold text-white tracking-tight">
                              {camp.title || 'Interactive Creator Video Campaign'}
                            </h2>

                            {/* Audience Reach Progress Bar */}
                            <div className="pt-1 max-w-md">
                              <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                                <span>Audience Goal:</span>
                                <span className="font-mono text-slate-300">
                                  {Math.min(100, Math.round(((camp.views_count || 0) / (camp.target_views || 1000)) * 100))}% reached
                                </span>
                              </div>
                              <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                                <div
                                  className={`h-full transition-all duration-500 ${
                                    isTargetReached ? 'bg-emerald-400' : 'bg-gradient-to-r from-purple-500 to-amber-400'
                                  }`}
                                  style={{
                                    width: `${Math.min(100, Math.round(((camp.views_count || 0) / (camp.target_views || 1000)) * 100))}%`
                                  }}
                                />
                              </div>
                            </div>
                          </div>

                          {/* Action Buttons: Quiz and Delete */}
                          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 shrink-0">
                            {canDelete && (
                              <button
                                type="button"
                                id={`delete-video-btn-${camp.id}`}
                                onClick={() => setDeleteModalCampaign(camp)}
                                className="px-3 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                                title={
                                  isSuperAdminUser
                                    ? 'Super Admin: Delete this video/demo'
                                    : 'Creator: Delete your campaign'
                                }
                              >
                                <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                                <span>
                                  {isTargetReached
                                    ? 'Delete (Target Met)'
                                    : isTest
                                    ? 'Delete Demo'
                                    : 'Delete Video'}
                                </span>
                              </button>
                            )}

                            {isCompleted ? (
                              <div
                                id={`completed-badge-${camp.id}`}
                                className="px-4 py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-slate-300 text-xs font-semibold flex items-center justify-center gap-2"
                              >
                                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                                <span>
                                  {isTest ? 'Test Video Done (₹0)' : `Reward Claimed (+₹${camp.reward_coins || 50})`}
                                </span>
                              </div>
                            ) : camp.quiz_type === 'none' ? (
                              <button
                                id={`claim-watch-btn-${camp.id}`}
                                type="button"
                                disabled={watchClaimingId === (camp.id || camp.video_id)}
                                onClick={() => handleClaimDirectWatch(camp)}
                                className={`w-full sm:w-auto px-5 py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition-all ${
                                  isTest
                                    ? 'bg-slate-800 hover:bg-slate-700 border border-amber-500/40 text-amber-300 shadow-amber-950/30'
                                    : 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 shadow-emerald-500/20'
                                }`}
                              >
                                <Coins className="w-4 h-4 text-emerald-950" />
                                <span>
                                  {watchClaimingId === (camp.id || camp.video_id)
                                    ? 'Verifying Watch...'
                                    : isTest
                                    ? 'Claim Practice Watch (₹0)'
                                    : `Watch & Claim ₹${camp.reward_coins || 50}`}
                                </span>
                              </button>
                            ) : (
                              <button
                                id={`take-quiz-btn-${camp.id}`}
                                type="button"
                                onClick={() => handleOpenQuiz(camp)}
                                className={`w-full sm:w-auto px-5 py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition-all ${
                                  isTest
                                    ? 'bg-slate-800 hover:bg-slate-700 border border-amber-500/40 text-amber-300 shadow-amber-950/30'
                                    : 'bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-slate-950 shadow-amber-500/20'
                                }`}
                              >
                                <Award className="w-4 h-4 text-amber-400" />
                                <span>
                                  {isTest
                                    ? 'Practice Quiz (₹0 / No Money)'
                                    : `Take Quiz & Earn ₹${camp.reward_coins || 50}`}
                                </span>
                              </button>
                            )}
                          </div>
                        </div>

                        {/* Notice banner for test campaigns */}
                        {isTest && (
                          <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-200 text-xs">
                            <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
                            <span>
                              <strong>Only for Test Purposes:</strong> This feed is provided for testing. No money or coins will be given in that.
                            </span>
                          </div>
                        )}

                        {/* Campaign stats strip */}
                        <div className="flex items-center justify-between pt-3 border-t border-slate-800/80 text-xs text-slate-400">
                          <div className="flex items-center gap-4 flex-wrap">
                            {isTest ? (
                              <span className="text-amber-400/90 font-medium">
                                Status: <strong className="text-amber-300">Test Purpose Only (₹0 Escrow)</strong>
                              </span>
                            ) : (
                              <>
                                <span className="text-slate-500">
                                  Budget: <strong className="text-slate-300">₹{camp.budget}</strong>
                                </span>
                                <span className="text-slate-500">
                                  UTR: <strong className="text-slate-400 font-mono">{camp.utr_number}</strong>
                                </span>
                              </>
                            )}
                            {canDelete && (
                              <span className="text-[11px] text-slate-500 flex items-center gap-1">
                                <span>•</span>
                                <span className="text-slate-400">
                                  {isSuperAdminUser ? 'Super Admin can delete' : 'Creator can delete'}
                                </span>
                              </span>
                            )}
                          </div>

                          <a
                            href={camp.youtube_url}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-slate-400 hover:text-amber-400 flex items-center gap-1 transition-colors"
                          >
                            <span>Watch on YouTube</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        </div>
                      </>
                    );
                  })()}
                </div>
              </article>
            );
          })}
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteModalCampaign && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-rose-500/20 border border-rose-500/30 text-rose-400 flex items-center justify-center shrink-0">
                <Trash2 className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h3 className="text-lg font-bold text-white">Delete Video Campaign?</h3>
                <span
                  className={`text-[10px] uppercase font-mono px-2 py-0.5 rounded-full font-bold ${
                    currentUser?.email?.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase()
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                      : 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                  }`}
                >
                  {currentUser?.email?.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase()
                    ? 'Super Admin Authorization'
                    : 'Creator Owner Authorization'}
                </span>
              </div>
            </div>

            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-2 text-xs">
              <p className="font-semibold text-slate-200 line-clamp-2">
                {deleteModalCampaign.title || 'Video Campaign'}
              </p>
              <div className="flex items-center gap-3 text-slate-400 text-[11px] pt-1 border-t border-slate-900 flex-wrap">
                <span>
                  Views: <strong>{deleteModalCampaign.views_count || 0} / {deleteModalCampaign.target_views || 1000}</strong>
                </span>
                {(deleteModalCampaign.views_count || 0) >= (deleteModalCampaign.target_views || 1000) && (
                  <span className="text-emerald-400 font-semibold">• Target Audience Reached</span>
                )}
                {deleteModalCampaign.is_test && (
                  <span className="text-amber-400 font-semibold">• Demo Video</span>
                )}
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              {currentUser?.email?.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase()
                ? 'As Super Admin, you are deleting this campaign. It will be permanently removed from the user feed, demo list, and quiz portal.'
                : 'As the creator of this video, you are deleting your campaign. It will be permanently removed from the user feed and quiz portal.'}
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDeleteModalCampaign(null)}
                disabled={isDeleting}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                id="confirm-delete-video-btn"
                onClick={() => handleDeleteCampaign(deleteModalCampaign)}
                disabled={isDeleting}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-rose-950/50 disabled:opacity-50 transition-colors"
              >
                {isDeleting ? (
                  <span>Deleting...</span>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Confirm Delete</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Quiz Modal */}
      <QuizModal
        campaign={selectedCampaign}
        isOpen={isQuizOpen}
        onClose={() => setIsQuizOpen(false)}
        onQuizCompleted={() => {
          fetchCampaigns();
        }}
      />
    </div>
  );
};
