import React, { useState } from 'react';
import { Copy, Check, ShieldCheck, Smartphone, AlertCircle } from 'lucide-react';

interface UPIQRCodeProps {
  amount?: number;
  upiId?: string;
  payeeName?: string;
  phoneNumber?: string;
  qrImageUrl?: string;
  isSuperAdmin?: boolean;
}

export const UPIQRCode: React.FC<UPIQRCodeProps> = ({
  amount = 1000,
  upiId = 'mrinalkantisingharoy2009@okhdfcbank',
  payeeName = 'Mrinal Kanti Singha Roy',
  qrImageUrl = '',
  isSuperAdmin = false
}) => {
  const [copiedUpi, setCopiedUpi] = useState(false);

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(upiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2000);
  };

  const upiLink = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(payeeName)}&am=${amount}&cu=INR&tn=VidQuest%20Campaign%20Escrow`;

  return (
    <div id="upi-qr-card" className="bg-slate-900 border border-slate-800 rounded-3xl p-6 text-white max-w-sm mx-auto shadow-2xl space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-xs border border-emerald-500/30">
            UPI
          </div>
          <div>
            <div className="text-[11px] text-slate-400">Super Admin Escrow</div>
            <div className="font-semibold text-xs text-slate-200">Official Payment QR</div>
          </div>
        </div>
        <div className="flex items-center gap-1 text-[11px] text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/20 font-medium">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Verified</span>
        </div>
      </div>

      {/* QR Code Container - Displays either Super Admin's uploaded QR screenshot or generated SVG */}
      <div className="bg-white p-4 rounded-2xl flex flex-col items-center justify-center relative shadow-inner">
        <div className="w-52 h-52 bg-white flex items-center justify-center relative overflow-hidden rounded-xl">
          {qrImageUrl ? (
            <img
              src={qrImageUrl}
              alt="Super Admin UPI QR Code"
              className="w-full h-full object-contain"
            />
          ) : (
            /* Crisp SVG QR Code fallback */
            <svg viewBox="0 0 200 200" className="w-full h-full text-slate-900">
              {/* Top-Left Finder */}
              <rect x="15" y="15" width="50" height="50" rx="4" fill="currentColor" />
              <rect x="23" y="23" width="34" height="34" rx="2" fill="white" />
              <rect x="31" y="31" width="18" height="18" rx="1" fill="currentColor" />

              {/* Top-Right Finder */}
              <rect x="135" y="15" width="50" height="50" rx="4" fill="currentColor" />
              <rect x="143" y="23" width="34" height="34" rx="2" fill="white" />
              <rect x="151" y="31" width="18" height="18" rx="1" fill="currentColor" />

              {/* Bottom-Left Finder */}
              <rect x="15" y="135" width="50" height="50" rx="4" fill="currentColor" />
              <rect x="23" y="143" width="34" height="34" rx="2" fill="white" />
              <rect x="31" y="151" width="18" height="18" rx="1" fill="currentColor" />

              {/* Matrix pattern */}
              <g fill="currentColor">
                <rect x="75" y="35" width="10" height="10" />
                <rect x="95" y="35" width="10" height="10" />
                <rect x="115" y="35" width="10" height="10" />
                <rect x="35" y="75" width="10" height="10" />
                <rect x="35" y="95" width="10" height="10" />
                <rect x="35" y="115" width="10" height="10" />
                <rect x="75" y="75" width="12" height="12" />
                <rect x="95" y="75" width="12" height="12" />
                <rect x="115" y="75" width="12" height="12" />
                <rect x="75" y="95" width="12" height="12" />
                <rect x="115" y="95" width="12" height="12" />
                <rect x="75" y="115" width="12" height="12" />
                <rect x="95" y="115" width="12" height="12" />
                <rect x="115" y="115" width="12" height="12" />
                <rect x="15" y="75" width="10" height="10" />
                <rect x="15" y="95" width="10" height="10" />
                <rect x="75" y="15" width="10" height="10" />
                <rect x="95" y="15" width="10" height="10" />
                <rect x="115" y="15" width="10" height="10" />
                <rect x="135" y="75" width="10" height="10" />
                <rect x="155" y="75" width="10" height="10" />
                <rect x="175" y="75" width="10" height="10" />
                <rect x="135" y="95" width="10" height="10" />
                <rect x="155" y="95" width="10" height="10" />
                <rect x="175" y="95" width="10" height="10" />
                <rect x="135" y="115" width="10" height="10" />
                <rect x="155" y="115" width="10" height="10" />
                <rect x="175" y="115" width="10" height="10" />
                <rect x="75" y="135" width="10" height="10" />
                <rect x="95" y="135" width="10" height="10" />
                <rect x="115" y="135" width="10" height="10" />
                <rect x="75" y="155" width="10" height="10" />
                <rect x="95" y="155" width="10" height="10" />
                <rect x="115" y="155" width="10" height="10" />
                <rect x="75" y="175" width="10" height="10" />
                <rect x="95" y="175" width="10" height="10" />
                <rect x="115" y="175" width="10" height="10" />
                <rect x="135" y="135" width="10" height="10" />
                <rect x="175" y="135" width="10" height="10" />
                <rect x="135" y="175" width="10" height="10" />
                <rect x="155" y="175" width="10" height="10" />
                <rect x="175" y="175" width="10" height="10" />
              </g>

              {/* Central Badge */}
              <circle cx="100" cy="100" r="16" fill="white" />
              <circle cx="100" cy="100" r="13" fill="#10B981" />
              <text x="100" y="104" textAnchor="middle" fill="white" fontSize="9" fontWeight="bold">₹</text>
            </svg>
          )}
        </div>
        <div className="text-[11px] text-slate-500 mt-2 font-mono flex items-center gap-1">
          <Smartphone className="w-3.5 h-3.5 text-slate-400" />
          <span>Scan with GPay / PhonePe / Paytm</span>
        </div>
      </div>

      {/* Escrow Amount */}
      <div className="flex items-baseline justify-between bg-slate-950 px-4 py-2.5 rounded-xl border border-slate-800">
        <span className="text-xs text-slate-400">Total Campaign Escrow:</span>
        {isSuperAdmin ? (
          <div className="text-right">
            <span className="text-xl font-bold text-emerald-400 font-mono">₹0</span>
            <div className="text-[10px] text-amber-400 font-medium">Super Admin Test (Exempt)</div>
          </div>
        ) : (
          <span className="text-xl font-bold text-emerald-400 font-mono">
            ₹{amount.toLocaleString('en-IN')}
          </span>
        )}
      </div>

      {/* Super Admin Payment Details */}
      <div className="space-y-2.5">
        {/* UPI ID */}
        <div className="bg-slate-950 p-3 rounded-xl border border-slate-800">
          <div className="text-[10px] text-slate-400 mb-1 flex items-center justify-between">
            <span>Official UPI ID (VPA)</span>
            <span className="text-slate-500">{payeeName}</span>
          </div>
          <div className="flex items-center justify-between gap-2">
            <span className="font-mono text-xs text-emerald-300 font-semibold truncate select-all">
              {upiId}
            </span>
            <button
              id="copy-upi-btn"
              type="button"
              onClick={handleCopyUpi}
              className="text-xs px-2.5 py-1 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-200 flex items-center gap-1 transition-colors shrink-0"
            >
              {copiedUpi ? (
                <>
                  <Check className="w-3 h-3 text-emerald-400" />
                  <span className="text-emerald-400 text-[11px]">Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" />
                  <span className="text-[11px]">Copy</span>
                </>
              )}
            </button>
          </div>
        </div>

        {isSuperAdmin ? (
          <div className="w-full text-center text-xs py-2.5 px-3 bg-amber-500/10 border border-amber-500/30 text-amber-300 font-semibold rounded-xl">
            Super Admin Test Account: No payment required
          </div>
        ) : (
          <a
            id="open-upi-app-link"
            href={upiLink}
            className="block w-full text-center text-xs py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded-xl transition-colors shadow-lg shadow-emerald-950/40"
          >
            Open Installed UPI App to Pay
          </a>
        )}
      </div>
    </div>
  );
};
