import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Briefcase,
  Plus,
  Clock,
  DollarSign,
  AlertCircle,
  CheckCircle2,
  ExternalLink,
  FileText,
  Video,
  Sparkles,
  UploadCloud,
  Trash2,
  RefreshCw,
  User,
  Send,
  ChevronRight,
  Info,
  ShieldCheck,
  Check,
  Eye,
  MessageSquare,
  Layers,
  Calendar,
  AlertTriangle
} from 'lucide-react';
import { UPIQRCode } from './UPIQRCode';
import { SUPER_ADMIN_EMAIL } from '../lib/firebase';
import {
  FreelanceJob,
  FreelanceApplication,
  FreelanceJobCategory,
  MARKET_RATE_BENCHMARKS,
  calculatePlatformFee,
  EscrowSettings
} from '../types';
import {
  createFreelanceJob,
  getCreatorFreelanceJobs,
  deleteFreelanceJob,
  getJobApplications,
  assignFreelancerToJob
} from '../services/freelanceService';

interface CreatorFreelanceDeskProps {
  escrowSettings: EscrowSettings;
}

export const CreatorFreelanceDesk: React.FC<CreatorFreelanceDeskProps> = ({ escrowSettings }) => {
  const { currentUser, role, isSuperAdmin } = useAuth();

  const [activeTab, setActiveTab] = useState<'create' | 'my_jobs'>('create');
  const [step, setStep] = useState<1 | 2>(1);

  // Form State
  const [jobTitle, setJobTitle] = useState('');
  const [category, setCategory] = useState<FreelanceJobCategory>('video_editing');
  const [description, setDescription] = useState('');
  const [rawFootageUrl, setRawFootageUrl] = useState('');
  const [referenceVideoUrl, setReferenceVideoUrl] = useState('');
  const [turnaroundDays, setTurnaroundDays] = useState<number>(3);
  const [budgetInput, setBudgetInput] = useState<number>(1500);

  // Escrow Payment State
  const [utrNumber, setUtrNumber] = useState('');
  const [receiptImage, setReceiptImage] = useState('');
  const [receiptFileName, setReceiptFileName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // List of jobs
  const [myJobs, setMyJobs] = useState<FreelanceJob[]>([]);
  const [loadingJobs, setLoadingJobs] = useState(false);

  // Applicants Modal
  const [selectedJobForApplicants, setSelectedJobForApplicants] = useState<FreelanceJob | null>(null);
  const [jobApplicants, setJobApplicants] = useState<FreelanceApplication[]>([]);
  const [loadingApplicants, setLoadingApplicants] = useState(false);
  const [assigningAppId, setAssigningAppId] = useState<string | null>(null);
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);

  // Deliverable Review Modal
  const [reviewJob, setReviewJob] = useState<FreelanceJob | null>(null);

  const isSuperAdminUser = Boolean(
    isSuperAdmin ||
    (currentUser?.email && currentUser.email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase()) ||
    role === 'super_admin'
  );

  const currentBenchmark = MARKET_RATE_BENCHMARKS[category];
  const { feePercent, feeAmount, editorNetPayout } = calculatePlatformFee(budgetInput);

  // Market validation status
  const isBelowMin = budgetInput < currentBenchmark.minRecommended;
  const isBelowAvg = budgetInput >= currentBenchmark.minRecommended && budgetInput < currentBenchmark.marketAverage;
  const isCompetitive = budgetInput >= currentBenchmark.marketAverage;

  const loadJobs = async () => {
    if (!currentUser) return;
    setLoadingJobs(true);
    try {
      const data = await getCreatorFreelanceJobs(currentUser.uid);
      setMyJobs(data);
    } catch (err) {
      console.error('Failed to load freelance jobs:', err);
    } finally {
      setLoadingJobs(false);
    }
  };

  useEffect(() => {
    if (currentUser) {
      loadJobs();
    }
  }, [currentUser]);

  const handleReceiptUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        setFormError('Screenshot is too large. Max file size is 2MB.');
        return;
      }
      setReceiptFileName(file.name);
      const reader = new FileReader();
      reader.onloadend = () => {
        setReceiptImage(reader.result as string);
        setFormError(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleStep1Proceed = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (!jobTitle.trim()) {
      setFormError('Please enter a descriptive job title.');
      return;
    }
    if (!description.trim() || description.trim().length < 20) {
      setFormError('Please provide detailed instructions (at least 20 characters) describing what you need.');
      return;
    }
    if (!rawFootageUrl.trim()) {
      setFormError('Please provide a link to the video/assets to edit (e.g. Google Drive, Dropbox, or YouTube).');
      return;
    }
    if (isBelowMin) {
      setFormError(`The offered amount (₹${budgetInput}) is below the standard minimum rate for ${currentBenchmark.name} (min ₹${currentBenchmark.minRecommended}). Please offer fair market compensation.`);
      return;
    }

    setStep(2);
  };

  const handleSubmitJob = async () => {
    if (!currentUser) return;
    setFormError(null);

    if (!isSuperAdminUser) {
      if (!utrNumber.trim() || utrNumber.trim().length < 10) {
        setFormError('Please enter a valid 12-digit UPI UTR transaction reference number.');
        return;
      }
      if (!receiptImage) {
        setFormError('Please upload your payment screenshot receipt for Super Admin verification.');
        return;
      }
    }

    setIsSubmitting(true);
    try {
      await createFreelanceJob({
        creator_uid: currentUser.uid,
        creator_email: currentUser.email || 'creator@vidquest.com',
        creator_name: currentUser.displayName || 'Content Creator',
        title: jobTitle.trim(),
        category,
        description: description.trim(),
        raw_footage_url: rawFootageUrl.trim(),
        reference_video_url: referenceVideoUrl.trim() || undefined,
        turnaround_days: turnaroundDays,
        budget: isSuperAdminUser ? 0 : budgetInput,
        utr_number: isSuperAdminUser ? (utrNumber.trim() || 'ADMIN_TEST_BYPASS') : utrNumber.trim(),
        receipt_url: isSuperAdminUser ? (receiptImage || 'ADMIN_TEST_BYPASS') : receiptImage,
        status: isSuperAdminUser ? 'open' : 'pending_super_admin',
        is_test_mode: isSuperAdminUser
      });

      setSubmitSuccess(true);
      loadJobs();
    } catch (err: unknown) {
      setFormError(err instanceof Error ? err.message : 'Job submission failed. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleOpenApplicants = async (job: FreelanceJob) => {
    if (!job.id) return;
    setSelectedJobForApplicants(job);
    setLoadingApplicants(true);
    setActionSuccessMsg(null);
    try {
      const apps = await getJobApplications(job.id);
      setJobApplicants(apps);
    } catch (err) {
      console.error('Failed to load applications:', err);
    } finally {
      setLoadingApplicants(false);
    }
  };

  const handleAssignFreelancer = async (app: FreelanceApplication) => {
    if (!selectedJobForApplicants?.id || !app.id) return;
    setAssigningAppId(app.id);
    try {
      await assignFreelancerToJob(selectedJobForApplicants.id, app);
      setActionSuccessMsg(`Hired ${app.freelancer_email}! Job is now In Progress.`);
      loadJobs();
      // Reload applications list
      const apps = await getJobApplications(selectedJobForApplicants.id);
      setJobApplicants(apps);
      setSelectedJobForApplicants({
        ...selectedJobForApplicants,
        status: 'in_progress',
        assigned_freelancer_email: app.freelancer_email
      });
    } catch (err: unknown) {
      alert(err instanceof Error ? err.message : 'Failed to assign freelancer');
    } finally {
      setAssigningAppId(null);
    }
  };

  const resetForm = () => {
    setJobTitle('');
    setCategory('video_editing');
    setDescription('');
    setRawFootageUrl('');
    setReferenceVideoUrl('');
    setTurnaroundDays(3);
    setBudgetInput(1500);
    setUtrNumber('');
    setReceiptImage('');
    setReceiptFileName('');
    setStep(1);
    setSubmitSuccess(false);
    setFormError(null);
  };

  return (
    <div className="space-y-6">
      {/* Sub Header & Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-indigo-400" />
            <span>Freelance Creator Desk</span>
          </h2>
          <p className="text-xs text-slate-400">
            Post editing and creative jobs for your YouTube channel. Verified students and editors will apply to work on your videos.
          </p>
        </div>

        <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl p-1 self-start sm:self-auto">
          <button
            onClick={() => { setActiveTab('create'); resetForm(); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
              activeTab === 'create'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Post New Job</span>
          </button>
          <button
            onClick={() => { setActiveTab('my_jobs'); loadJobs(); }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
              activeTab === 'my_jobs'
                ? 'bg-indigo-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>My Posted Jobs ({myJobs.length})</span>
          </button>
        </div>
      </div>

      {activeTab === 'create' ? (
        submitSuccess ? (
          /* Success Screen */
          <div className="bg-slate-900 border border-emerald-500/30 rounded-3xl p-8 text-center max-w-xl mx-auto space-y-4">
            <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/20">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-xl font-bold text-white">Freelance Job Submitted to Escrow!</h3>
            <p className="text-sm text-slate-400 leading-relaxed">
              Your freelance job <span className="text-white font-semibold">"{jobTitle}"</span> has been queued for Super Admin inspection. Once the UTR is verified, it will be launched directly to our student and editor community on the Freelance Hub.
            </p>
            <div className="pt-2 flex justify-center gap-3">
              <button
                onClick={() => { resetForm(); setActiveTab('my_jobs'); }}
                className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded-xl"
              >
                View My Jobs
              </button>
              <button
                onClick={resetForm}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold rounded-xl"
              >
                Post Another Job
              </button>
            </div>
          </div>
        ) : (
          /* Two-Step Form */
          <div className="max-w-3xl mx-auto space-y-6">
            {/* Step indicator */}
            <div className="flex items-center gap-2">
              <div
                className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-semibold ${
                  step === 1 ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400'
                }`}
              >
                <span>1. Job Details & Rates</span>
              </div>
              <ChevronRight className="w-4 h-4 text-slate-600" />
              <div
                className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-semibold ${
                  step === 2 ? 'bg-indigo-600 text-white' : 'bg-slate-800 text-slate-400'
                }`}
              >
                <span>2. Escrow Payment & UTR</span>
              </div>
            </div>

            {formError && (
              <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{formError}</span>
              </div>
            )}

            {step === 1 ? (
              <form onSubmit={handleStep1Proceed} className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6">
                {/* Category Selection */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-2">
                    Freelance Category <span className="text-rose-400">*</span>
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                    {(Object.keys(MARKET_RATE_BENCHMARKS) as FreelanceJobCategory[]).map((catKey) => {
                      const item = MARKET_RATE_BENCHMARKS[catKey];
                      const isSelected = category === catKey;
                      return (
                        <button
                          key={catKey}
                          type="button"
                          onClick={() => {
                            setCategory(catKey);
                            setBudgetInput(item.marketAverage);
                          }}
                          className={`p-3 rounded-2xl border text-left transition-all ${
                            isSelected
                              ? 'bg-indigo-600/15 border-indigo-500 text-white ring-1 ring-indigo-500/50'
                              : 'bg-slate-950/70 border-slate-800 text-slate-400 hover:border-slate-700'
                          }`}
                        >
                          <div className="text-xs font-bold text-white mb-0.5">{item.name}</div>
                          <div className="text-[11px] text-indigo-400 font-mono">
                            Avg ₹{item.marketAverage.toLocaleString('en-IN')}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Job Title */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-2">
                    Job Title <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="text"
                    value={jobTitle}
                    onChange={(e) => setJobTitle(e.target.value)}
                    placeholder="e.g. YouTube Tech Video Editing (10-12 mins) with Fast Cuts & B-Roll"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                    required
                  />
                </div>

                {/* Raw Footage Link */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-2">
                    Video Raw Footage / Asset Link <span className="text-rose-400">*</span>
                  </label>
                  <input
                    type="url"
                    value={rawFootageUrl}
                    onChange={(e) => setRawFootageUrl(e.target.value)}
                    placeholder="https://drive.google.com/drive/folders/... or Dropbox / WeTransfer link"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                    required
                  />
                  <p className="text-[11px] text-slate-500 mt-1">
                    Provide the raw recording or asset folder link so the assigned editor can download the footage immediately.
                  </p>
                </div>

                {/* Reference Video Link */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-2">
                    Style Reference Video Link <span className="text-slate-500 font-normal">(Optional)</span>
                  </label>
                  <input
                    type="url"
                    value={referenceVideoUrl}
                    onChange={(e) => setReferenceVideoUrl(e.target.value)}
                    placeholder="e.g. https://www.youtube.com/watch?v=... (sample editing style you want)"
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                {/* Job Description & Editing Requirements */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-2">
                    Editing Instructions & Deliverable Requirements <span className="text-rose-400">*</span>
                  </label>
                  <textarea
                    rows={4}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Describe your editing style, preferred sound effects, pacing, color grading, thumbnail requirements, and deliverable format (1080p/4K MP4)..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500"
                    required
                  />
                </div>

                {/* Turnaround Delivery Time */}
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-2">
                    Required Turnaround Time <span className="text-rose-400">*</span>
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {[1, 2, 3, 5].map((days) => (
                      <button
                        key={days}
                        type="button"
                        onClick={() => setTurnaroundDays(days)}
                        className={`py-2 px-3 rounded-xl border text-xs font-semibold text-center transition-all ${
                          turnaroundDays === days
                            ? 'bg-indigo-600 border-indigo-500 text-white'
                            : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                        }`}
                      >
                        {days} {days === 1 ? 'Day (Rush)' : 'Days'}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Offered Budget & Market Rate Benchmark Verification */}
                <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-5 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-xs font-bold text-white uppercase tracking-wider">
                        Budget Offered (INR ₹)
                      </span>
                      <p className="text-[11px] text-slate-400">
                        Total escrow amount you will deposit for this deliverable.
                      </p>
                    </div>

                    <div className="text-right">
                      <span className="text-xs text-slate-400">Standard Market Avg:</span>
                      <div className="text-sm font-mono font-bold text-indigo-400">
                        ₹{currentBenchmark.marketAverage.toLocaleString('en-IN')}
                      </div>
                    </div>
                  </div>

                  <div className="relative">
                    <span className="absolute left-3.5 top-2.5 text-slate-500 font-bold">₹</span>
                    <input
                      type="number"
                      min={100}
                      step={50}
                      value={budgetInput}
                      onChange={(e) => setBudgetInput(Number(e.target.value))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-8 pr-4 py-2 text-sm text-white font-mono font-semibold focus:outline-none focus:border-indigo-500"
                      required
                    />
                  </div>

                  {/* Market Rate Health Indicator */}
                  <div className="p-3 rounded-xl border text-xs flex items-start gap-2.5 bg-slate-900/60">
                    {isBelowMin ? (
                      <>
                        <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                        <div className="space-y-0.5">
                          <span className="font-bold text-rose-400">Below Standard Market Minimum</span>
                          <p className="text-slate-400 text-[11px]">
                            Minimum fair rate for {currentBenchmark.name} is ₹{currentBenchmark.minRecommended}. Please adjust to ensure quality editors apply.
                          </p>
                        </div>
                      </>
                    ) : isBelowAvg ? (
                      <>
                        <Info className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                        <div className="space-y-0.5">
                          <span className="font-bold text-amber-400">Standard Budget Range</span>
                          <p className="text-slate-400 text-[11px]">
                            Acceptable market rate. Meets the minimum threshold for {currentBenchmark.name}.
                          </p>
                        </div>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <div className="space-y-0.5">
                          <span className="font-bold text-emerald-400">Competitive High-Tier Offer</span>
                          <p className="text-slate-400 text-[11px]">
                            Attracts top-rated video editors with fast turnaround delivery.
                          </p>
                        </div>
                      </>
                    )}
                  </div>

                  {/* Platform Fee & Net Editor Payout Breakdown */}
                  <div className="pt-2 border-t border-slate-800/80 space-y-1.5 text-xs">
                    <div className="flex justify-between text-slate-400">
                      <span>Total Escrow Deposit (You Pay):</span>
                      <span className="font-mono text-white font-semibold">₹{budgetInput.toLocaleString('en-IN')}</span>
                    </div>
                    <div className="flex justify-between text-slate-400">
                      <span>Platform Commission ({feePercent}%):</span>
                      <span className="font-mono text-indigo-400">-₹{feeAmount.toLocaleString('en-IN')}</span>
                    </div>
                    <div className="flex justify-between text-slate-200 font-bold pt-1 border-t border-slate-800">
                      <span>Editor Take-Home Payout (Upon Completion):</span>
                      <span className="font-mono text-emerald-400 font-bold">₹{editorNetPayout.toLocaleString('en-IN')}</span>
                    </div>
                    <p className="text-[10px] text-slate-500">
                      * Platform fee is 15% for jobs under ₹1,500 and reduced to 10% for jobs ₹1,500 and above.
                    </p>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isBelowMin}
                  className={`w-full py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${
                    isBelowMin
                      ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                      : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-950/50'
                  }`}
                >
                  <span>Proceed to Escrow Checkout</span>
                  <ChevronRight className="w-4 h-4" />
                </button>
              </form>
            ) : (
              /* Step 2: Escrow Payment */
              <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div>
                    <h3 className="text-base font-bold text-white">Deposit Job Escrow</h3>
                    <p className="text-xs text-slate-400">
                      Amount: <span className="text-emerald-400 font-mono font-bold">₹{budgetInput}</span> • Category: {currentBenchmark.name}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="text-xs text-slate-400 hover:text-white underline"
                  >
                    Edit Details
                  </button>
                </div>

                {/* Super Admin Official QR */}
                <UPIQRCode
                  amount={isSuperAdminUser ? 0 : budgetInput}
                  upiId={escrowSettings.upi_id}
                  payeeName={escrowSettings.payee_name}
                  phoneNumber={escrowSettings.phone_number}
                  qrImageUrl={escrowSettings.qr_image_url}
                  isSuperAdmin={isSuperAdminUser}
                />

                {/* UTR and Receipt Form */}
                <div className="space-y-4 max-w-sm mx-auto">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      12-Digit UPI UTR Reference Number <span className="text-rose-400">*</span>
                    </label>
                    <input
                      type="text"
                      maxLength={16}
                      value={utrNumber}
                      onChange={(e) => setUtrNumber(e.target.value)}
                      placeholder={isSuperAdminUser ? 'ADMIN_BYPASS' : 'e.g. 423984712093'}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 font-mono focus:outline-none focus:border-indigo-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">
                      Payment Screenshot Receipt <span className="text-rose-400">*</span>
                    </label>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleReceiptUpload}
                      className="w-full text-xs text-slate-400 file:mr-3 file:py-2 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-slate-800 file:text-slate-200 hover:file:bg-slate-700 cursor-pointer"
                    />
                    {receiptFileName && (
                      <p className="text-[11px] text-emerald-400 mt-1 flex items-center gap-1">
                        <Check className="w-3 h-3" />
                        <span>Attached: {receiptFileName}</span>
                      </p>
                    )}
                  </div>

                  <button
                    type="button"
                    onClick={handleSubmitJob}
                    disabled={isSubmitting}
                    className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-bold text-sm rounded-xl shadow-lg transition-all flex items-center justify-center gap-2"
                  >
                    {isSubmitting ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Submitting to Super Admin...</span>
                      </>
                    ) : (
                      <>
                        <ShieldCheck className="w-4 h-4" />
                        <span>Submit Job to Super Admin</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </div>
        )
      ) : (
        /* My Posted Jobs List */
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white">Your Posted Freelance Jobs</h3>
            <button
              onClick={loadJobs}
              className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loadingJobs ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </button>
          </div>

          {loadingJobs ? (
            <div className="py-12 text-center text-slate-400 text-xs flex items-center justify-center gap-2">
              <RefreshCw className="w-4 h-4 animate-spin text-indigo-400" />
              <span>Loading your freelance jobs...</span>
            </div>
          ) : myJobs.length === 0 ? (
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center space-y-3">
              <Briefcase className="w-10 h-10 text-slate-600 mx-auto" />
              <p className="text-sm text-slate-400">You haven't posted any freelance jobs yet.</p>
              <button
                onClick={() => { setActiveTab('create'); resetForm(); }}
                className="px-4 py-2 bg-indigo-600 text-white text-xs font-semibold rounded-xl"
              >
                Post Your First Job
              </button>
            </div>
          ) : (
            <div className="grid gap-4">
              {myJobs.map((job) => {
                const benchmark = MARKET_RATE_BENCHMARKS[job.category] || MARKET_RATE_BENCHMARKS.video_editing;
                return (
                  <div
                    key={job.id}
                    className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3 hover:border-slate-700 transition-colors"
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-bold text-white">{job.title}</span>
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                            {benchmark.name}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-3">
                          <span>Delivery: {job.turnaround_days} Days</span>
                          <span>•</span>
                          <span>Posted: {new Date(job.createdAt).toLocaleDateString()}</span>
                        </div>
                      </div>

                      {/* Status Badges */}
                      <div>
                        {job.status === 'pending_super_admin' && (
                          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-500/15 text-amber-300 border border-amber-500/30">
                            Awaiting Super Admin Launch
                          </span>
                        )}
                        {job.status === 'open' && (
                          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                            Live on Freelance Hub ({job.applicant_count || 0} applicants)
                          </span>
                        )}
                        {job.status === 'in_progress' && (
                          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-purple-500/15 text-purple-300 border border-purple-500/30">
                            In Progress: {job.assigned_freelancer_email}
                          </span>
                        )}
                        {job.status === 'submitted' && (
                          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 animate-pulse">
                            Work Submitted — Ready for Review
                          </span>
                        )}
                        {job.status === 'completed' && (
                          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                            Completed & Paid
                          </span>
                        )}
                        {job.status === 'rejected' && (
                          <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-500/15 text-rose-300 border border-rose-500/30">
                            Rejected by Super Admin
                          </span>
                        )}
                      </div>
                    </div>

                    <p className="text-xs text-slate-300 line-clamp-2">{job.description}</p>

                    <div className="flex flex-wrap items-center justify-between gap-3 pt-2 text-xs">
                      <div className="flex items-center gap-4">
                        <div>
                          <span className="text-slate-500">Escrow:</span>{' '}
                          <span className="font-mono text-white font-bold">₹{job.budget}</span>
                        </div>
                        <div>
                          <span className="text-slate-500">Editor Payout:</span>{' '}
                          <span className="font-mono text-emerald-400 font-bold">₹{job.editor_net_payout}</span>
                        </div>
                        <a
                          href={job.raw_footage_url}
                          target="_blank"
                          rel="noreferrer"
                          className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1 underline text-[11px]"
                        >
                          <ExternalLink className="w-3 h-3" />
                          <span>Raw Footage Link</span>
                        </a>
                      </div>

                      <div className="flex items-center gap-2">
                        {/* Applicants Inspection Button */}
                        {(job.status === 'open' || job.status === 'in_progress' || (job.applicant_count || 0) > 0) && (
                          <button
                            onClick={() => handleOpenApplicants(job)}
                            className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1"
                          >
                            <User className="w-3 h-3" />
                            <span>View Applicants ({job.applicant_count || 0})</span>
                          </button>
                        )}

                        {/* Review Deliverable Button */}
                        {(job.status === 'submitted' || job.status === 'completed') && job.deliverable_url && (
                          <button
                            onClick={() => setReviewJob(job)}
                            className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1"
                          >
                            <Eye className="w-3 h-3" />
                            <span>Review Deliverable Work</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Applicants Modal */}
      {selectedJobForApplicants && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-2xl w-full max-h-[85vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-white">Applicants for "{selectedJobForApplicants.title}"</h3>
                <p className="text-xs text-slate-400">
                  Select the best editor based on their portfolio and delivery commitment.
                </p>
              </div>
              <button
                onClick={() => setSelectedJobForApplicants(null)}
                className="text-slate-400 hover:text-white text-xs font-semibold px-2 py-1 bg-slate-800 rounded-lg"
              >
                Close
              </button>
            </div>

            {actionSuccessMsg && (
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs rounded-xl flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{actionSuccessMsg}</span>
              </div>
            )}

            {loadingApplicants ? (
              <div className="py-8 text-center text-slate-400 text-xs flex items-center justify-center gap-2">
                <RefreshCw className="w-4 h-4 animate-spin text-indigo-400" />
                <span>Loading applicants...</span>
              </div>
            ) : jobApplicants.length === 0 ? (
              <div className="py-8 text-center text-slate-400 text-xs">
                No editors have applied for this job yet. As soon as students and editors on the Freelance Hub submit their portfolio, they will appear here.
              </div>
            ) : (
              <div className="space-y-3">
                {jobApplicants.map((app) => (
                  <div
                    key={app.id}
                    className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2.5"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full bg-indigo-500/20 text-indigo-400 flex items-center justify-center text-xs font-bold">
                          {app.freelancer_email.charAt(0).toUpperCase()}
                        </div>
                        <div>
                          <div className="text-xs font-bold text-white">{app.freelancer_email}</div>
                          <div className="text-[10px] text-slate-500">
                            Applied: {new Date(app.createdAt).toLocaleDateString()}
                          </div>
                        </div>
                      </div>

                      {app.status === 'accepted' ? (
                        <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                          Hired & Assigned
                        </span>
                      ) : selectedJobForApplicants.status === 'open' ? (
                        <button
                          onClick={() => handleAssignFreelancer(app)}
                          disabled={assigningAppId === app.id}
                          className="px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold"
                        >
                          {assigningAppId === app.id ? 'Hiring...' : 'Hire this Editor'}
                        </button>
                      ) : (
                        <span className="text-[11px] text-slate-500">Applicant</span>
                      )}
                    </div>

                    <p className="text-xs text-slate-300 bg-slate-900/50 p-2.5 rounded-xl border border-slate-800/80">
                      "{app.pitch}"
                    </p>

                    <div className="flex items-center justify-between text-xs pt-1">
                      <a
                        href={app.portfolio_link}
                        target="_blank"
                        rel="noreferrer"
                        className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1 underline"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>Inspect Portfolio / Sample Edit</span>
                      </a>

                      <span className="text-[11px] text-slate-400 font-mono">
                        UPI: {app.upi_id}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Deliverable Review Modal */}
      {reviewJob && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-lg w-full space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Deliverable Work for "{reviewJob.title}"</h3>
              <button
                onClick={() => setReviewJob(null)}
                className="text-slate-400 hover:text-white text-xs font-semibold px-2 py-1 bg-slate-800 rounded-lg"
              >
                Close
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <span className="text-xs text-slate-400 block mb-1">Delivered Video / Files Link:</span>
                <a
                  href={reviewJob.deliverable_url}
                  target="_blank"
                  rel="noreferrer"
                  className="p-3 rounded-xl bg-slate-950 border border-cyan-500/30 text-cyan-300 text-xs font-mono break-all flex items-center gap-2 hover:bg-slate-900"
                >
                  <ExternalLink className="w-4 h-4 shrink-0" />
                  <span>{reviewJob.deliverable_url}</span>
                </a>
              </div>

              {reviewJob.deliverable_notes && (
                <div>
                  <span className="text-xs text-slate-400 block mb-1">Editor Notes:</span>
                  <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-slate-300 text-xs">
                    {reviewJob.deliverable_notes}
                  </div>
                </div>
              )}

              <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-xs text-slate-300 space-y-1">
                <span className="font-bold text-emerald-400 block">Escrow Release Policy</span>
                <p className="text-[11px] text-slate-400">
                  Inspect the delivered edit. The Super Admin reviews the deliverable and dispatches the net payout (₹{reviewJob.editor_net_payout}) directly to the editor's verified UPI ID.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
