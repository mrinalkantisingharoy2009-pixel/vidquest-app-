import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Video,
  Film,
  Play,
  Upload,
  UploadCloud,
  Trash2,
  RefreshCw,
  CheckCircle2,
  Clock,
  AlertCircle,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  FileText,
  DollarSign,
  Image as ImageIcon,
  ExternalLink,
  ChevronRight,
  Youtube,
  Send,
  HelpCircle,
  Bot,
  Edit3,
  Check,
  Loader2,
  Briefcase,
  Receipt,
  Phone,
  Hash,
  ArrowLeft,
  PlayCircle
} from 'lucide-react';
import { UPIQRCode } from './UPIQRCode';
import { CreatorFreelanceDesk } from './CreatorFreelanceDesk';
import { SUPER_ADMIN_EMAIL } from '../lib/firebase';
import {
  submitCreatorApplication,
  createCampaign,
  extractYouTubeId,
  getCreatorCampaigns,
  deleteCampaign
} from '../services/campaignService';
import {
  getEscrowSettings,
  DEFAULT_ESCROW_SETTINGS
} from '../services/adminService';
import { Campaign, EscrowSettings, QuizQuestion } from '../types';

interface CreatorStudioProps {
  openAuthModal: () => void;
}

export interface ViewTier {
  views: number;
  price: number;
  badge?: string;
}

export const VIEW_TIERS: ViewTier[] = [
  { views: 200, price: 100, badge: '₹0.50/view' },
  { views: 500, price: 250, badge: '₹0.50/view • ₹125 profit' },
  { views: 1000, price: 500, badge: '₹0.50/view • ₹250 profit' },
  { views: 2500, price: 1200, badge: '₹0.48/view • ₹575 profit' },
  { views: 5000, price: 2300, badge: '₹0.46/view • ₹1,050 profit' },
  { views: 10000, price: 4400, badge: 'Discounted to ₹0.44/view' },
];

export function calculateCampaignBudget(views: number): number {
  if (views <= 200) {
    return Math.round(views * 0.5);
  }
  if (views <= 500) {
    return Math.round(views * 0.5);
  }
  if (views <= 1000) {
    return Math.round(views * 0.5);
  }
  if (views <= 2500) {
    const ratio = (views - 1000) / (2500 - 1000);
    return Math.round(500 + ratio * (1200 - 500));
  }
  if (views <= 5000) {
    const ratio = (views - 2500) / (5000 - 2500);
    return Math.round(1200 + ratio * (2300 - 1200));
  }
  if (views <= 10000) {
    const ratio = (views - 5000) / (10000 - 5000);
    return Math.round(2300 + ratio * (4400 - 2300));
  }
  return Math.round(4400 + (views - 10000) * 0.44);
}

export const DEFAULT_QUESTIONS_TEMPLATE: QuizQuestion[] = [
  {
    id: 'q1',
    question: 'What is the primary topic or skill demonstrated in this video?',
    options: [
      'Core technique and practical walkthrough',
      'Unrelated entertainment clips',
      'Generic background wallpaper',
      'Incorrect methods not recommended'
    ],
    correctAnswerIndex: 0
  },
  {
    id: 'q2',
    question: 'Which key insight or technique was emphasized by the creator?',
    options: [
      'Verified best practices and efficient execution',
      'Skipping all setup instructions',
      'Ignoring error indicators',
      'Using outdated workarounds'
    ],
    correctAnswerIndex: 0
  },
  {
    id: 'q3',
    question: 'What step was highlighted during the central demonstration?',
    options: [
      'Step-by-step configuration and testing',
      'Closing the app immediately',
      'Deleting working code',
      'Skipping validation steps'
    ],
    correctAnswerIndex: 0
  },
  {
    id: 'q4',
    question: 'How did the presenter prove the effectiveness of the solution?',
    options: [
      'With real measurable results and practical proof',
      'By guessing without verification',
      'By avoiding practical testing',
      'By omitting key parameters'
    ],
    correctAnswerIndex: 0
  },
  {
    id: 'q5',
    question: 'What is the most important conclusion viewers should remember?',
    options: [
      'Consistent practice and verified guidelines achieve success',
      'Never review documentation',
      'Testing is useless in production',
      'Abandon projects at first error'
    ],
    correctAnswerIndex: 0
  }
];

export const CreatorStudio: React.FC<CreatorStudioProps> = ({ openAuthModal }) => {
  const { currentUser, userProfile, role, isSuperAdmin } = useAuth();

  // Escrow Configuration loaded from Firestore system_settings
  const [escrowSettings, setEscrowSettings] = useState<EscrowSettings>(DEFAULT_ESCROW_SETTINGS);

  // Top Section: Video Campaigns vs. Freelance Jobs Desk
  const [studioSection, setStudioSection] = useState<'campaigns' | 'freelance'>('campaigns');

  // Application Form State
  const [channelLink, setChannelLink] = useState('');
  const [channelName, setChannelName] = useState('');
  const [subscriberCount, setSubscriberCount] = useState('');
  const [appDescription, setAppDescription] = useState('');
  const [appSubmitting, setAppSubmitting] = useState(false);
  const [appSuccess, setAppSuccess] = useState(false);
  const [appError, setAppError] = useState<string | null>(null);

  // Campaign Setup State
  const [activeTab, setActiveTab] = useState<'create' | 'list'>('create');
  const [campaignStep, setCampaignStep] = useState<1 | 2>(1); // 1: Setup, 2: Checkout & UTR
  const [youtubeUrl, setYoutubeUrl] = useState('');
  const [campaignTitle, setCampaignTitle] = useState('');
  const [targetViews, setTargetViews] = useState(1000);
  const [senderUpiOrPhone, setSenderUpiOrPhone] = useState('');
  const [utrNumber, setUtrNumber] = useState('');
  const [receiptImage, setReceiptImage] = useState<string>('');
  const [receiptFileName, setReceiptFileName] = useState<string>('');
  const [campaignSubmitting, setCampaignSubmitting] = useState(false);
  const [campaignSuccess, setCampaignSuccess] = useState(false);
  const [campaignError, setCampaignError] = useState<string | null>(null);

  // Quiz Setup State (AI Automated vs. Creator Custom Questions vs. No Quiz)
  const [quizType, setQuizType] = useState<'ai_generated' | 'manual' | 'none'>('ai_generated');
  const [customQuestions, setCustomQuestions] = useState<QuizQuestion[]>(DEFAULT_QUESTIONS_TEMPLATE);
  const [isGeneratingQuiz, setIsGeneratingQuiz] = useState(false);
  const [quizGenSuccess, setQuizGenSuccess] = useState(false);
  const [quizGenError, setQuizGenError] = useState<string | null>(null);
  const [activeQuestionIndex, setActiveQuestionIndex] = useState(0);

  // 15-Second Teaser Video State
  const [teaserUrl, setTeaserUrl] = useState<string>('');
  const [teaserFileName, setTeaserFileName] = useState<string>('');
  const [teaserDuration, setTeaserDuration] = useState<number | null>(null);
  const [teaserSourceType, setTeaserSourceType] = useState<'upload' | 'url'>('upload');
  const [teaserExternalUrl, setTeaserExternalUrl] = useState<string>('');
  const [isDraggingTeaser, setIsDraggingTeaser] = useState<boolean>(false);
  const [teaserNotice, setTeaserNotice] = useState<string | null>(null);

  // Creator's existing campaigns
  const [creatorCampaigns, setCreatorCampaigns] = useState<Campaign[]>([]);
  const [loadingCampaigns, setLoadingCampaigns] = useState(false);
  const [deleteModalCampaign, setDeleteModalCampaign] = useState<Campaign | null>(null);
  const [isDeletingCampaign, setIsDeletingCampaign] = useState(false);
  const [deleteToast, setDeleteToast] = useState<string | null>(null);

  const budget = calculateCampaignBudget(targetViews);
  const basePrice = targetViews * 1;
  const savings = Math.max(0, basePrice - budget);
  const effectiveRate = (budget / targetViews).toFixed(2);

  const isSuperAdminUser = Boolean(
    isSuperAdmin ||
    (currentUser?.email && currentUser.email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase()) ||
    role === 'super_admin'
  );

  // User rule: AI Quiz costs ₹10 if budget < 500. If budget >= 500, AI Quiz is 100% FREE.
  // Manual Quiz is always FREE. Super admin testing is always FREE.
  const isAiFree = budget >= 500;
  const aiQuizFee = (quizType === 'ai_generated' && !isAiFree && !isSuperAdminUser) ? 10 : 0;
  const totalCampaignAmount = (isSuperAdminUser ? 0 : budget) + aiQuizFee;

  const videoId = extractYouTubeId(youtubeUrl);

  const isEligibleToCreate = role === 'approved_creator' || isSuperAdminUser;

  // AI Quiz Generator Handler
  const handleGenerateAiQuiz = async () => {
    if (!youtubeUrl) {
      setCampaignError('Please enter a YouTube video URL first so the AI can analyze your video.');
      return;
    }
    setIsGeneratingQuiz(true);
    setQuizGenError(null);
    setCampaignError(null);
    try {
      const res = await fetch('/api/generate-quiz', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          youtubeUrl,
          videoTitle: campaignTitle || 'Creator Video'
        })
      });
      if (!res.ok) {
        throw new Error('Failed to generate quiz from server');
      }
      const data = await res.json();
      if (Array.isArray(data.questions) && data.questions.length === 5) {
        setCustomQuestions(data.questions);
        setQuizGenSuccess(true);
        setQuizGenError(null);
      } else {
        throw new Error('AI returned an unexpected format. Please try again.');
      }
    } catch (err: unknown) {
      console.error('Quiz Gen Error:', err);
      setQuizGenError(err instanceof Error ? err.message : 'Error generating AI quiz');
    } finally {
      setIsGeneratingQuiz(false);
    }
  };

  const handleUpdateQuestionText = (index: number, text: string) => {
    setCustomQuestions((prev) => {
      const copy = [...prev];
      copy[index] = { ...copy[index], question: text };
      return copy;
    });
  };

  const handleUpdateOption = (qIndex: number, optIndex: number, text: string) => {
    setCustomQuestions((prev) => {
      const copy = [...prev];
      const newOptions = [...copy[qIndex].options];
      newOptions[optIndex] = text;
      copy[qIndex] = { ...copy[qIndex], options: newOptions };
      return copy;
    });
  };

  const handleSetCorrectAnswer = (qIndex: number, optIndex: number) => {
    setCustomQuestions((prev) => {
      const copy = [...prev];
      copy[qIndex] = { ...copy[qIndex], correctAnswerIndex: optIndex };
      return copy;
    });
  };

  const handleDeleteCampaign = async (campaign: Campaign) => {
    if (!campaign.id) return;
    setIsDeletingCampaign(true);
    try {
      await deleteCampaign(campaign.id);
      setCreatorCampaigns((prev) => prev.filter((c) => c.id !== campaign.id));
      setDeleteModalCampaign(null);
      setDeleteToast(`"${campaign.title || 'Video Campaign'}" was deleted successfully.`);
      setTimeout(() => setDeleteToast(null), 4000);
    } catch (err: unknown) {
      alert('Error deleting campaign: ' + (err instanceof Error ? err.message : String(err)));
    } finally {
      setIsDeletingCampaign(false);
    }
  };

  useEffect(() => {
    // Fetch Super Admin escrow settings (UPI ID, QR screenshot, phone number)
    getEscrowSettings().then((settings) => {
      setEscrowSettings(settings);
    }).catch(console.error);
  }, []);

  useEffect(() => {
    if (currentUser && isEligibleToCreate) {
      loadCreatorCampaigns();
    }
  }, [currentUser, isEligibleToCreate]);

  const loadCreatorCampaigns = async () => {
    if (!currentUser) return;
    setLoadingCampaigns(true);
    try {
      const list = await getCreatorCampaigns(currentUser.uid);
      setCreatorCampaigns(list);
    } catch (e) {
      console.error('Error fetching creator campaigns:', e);
    } finally {
      setLoadingCampaigns(false);
    }
  };

  // 1. Submit Creator Application (User -> Creator Transformation Request)
  const handleApplicationSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      openAuthModal();
      return;
    }
    if (!channelLink) {
      setAppError('Please enter your YouTube channel link');
      return;
    }

    setAppSubmitting(true);
    setAppError(null);
    try {
      await submitCreatorApplication(
        currentUser.uid,
        currentUser.email || '',
        channelLink.trim(),
        channelName.trim(),
        subscriberCount.trim(),
        appDescription.trim()
      );
      setAppSuccess(true);
    } catch (err: unknown) {
      setAppError(err instanceof Error ? err.message : 'Application submission failed');
    } finally {
      setAppSubmitting(false);
    }
  };

  // 2. Handle Receipt Image Upload
  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setCampaignError('Please upload an image file (PNG, JPG, or WEBP)');
      return;
    }

    setReceiptFileName(file.name);
    const reader = new FileReader();
    reader.onloadend = () => {
      setReceiptImage(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  // 2b. Handle 15-Second Teaser Video File Upload (Drag-and-Drop & Picker)
  const handleTeaserFileSelect = (file: File) => {
    if (!file) return;

    if (!file.type.startsWith('video/')) {
      setCampaignError('Please upload a valid video file (MP4, WebM, MOV) for your 15-second teaser.');
      return;
    }

    // Limit to 35MB
    if (file.size > 35 * 1024 * 1024) {
      setCampaignError('Video file exceeds 35MB. Please upload a short compressed 15-second teaser clip.');
      return;
    }

    setCampaignError(null);
    setTeaserFileName(file.name);

    // Create object URL for instant zero-lag playback in preview
    const objectUrl = URL.createObjectURL(file);
    setTeaserUrl(objectUrl);
    setTeaserNotice('Loading video metadata to verify 15-second duration...');
  };

  const handleUseSampleTeaser = (sampleUrl: string, name: string) => {
    setTeaserUrl(sampleUrl);
    setTeaserFileName(name);
    setTeaserDuration(15);
    setTeaserNotice('Sample 15-second teaser attached successfully.');
    setCampaignError(null);
  };

  // 3. Super Admin Direct 1-Click Post (Bypasses money, UTR & receipt for super admin testing)
  const handleSuperAdminDirectPost = async () => {
    if (!currentUser) {
      openAuthModal();
      return;
    }
    if (!isSuperAdminUser) return;

    if (!youtubeUrl) {
      setCampaignError('Please enter a YouTube video URL first');
      return;
    }

    setCampaignSubmitting(true);
    setCampaignError(null);

    const defaultTeaser = 'https://assets.mixkit.co/videos/preview/mixkit-software-developer-working-on-code-screen-close-up-1728-large.mp4';
    const finalTeaserUrl = teaserUrl || defaultTeaser;

    try {
      await createCampaign({
        creator_uid: currentUser.uid,
        creator_email: currentUser.email || SUPER_ADMIN_EMAIL,
        creator_name: userProfile?.displayName || currentUser.email?.split('@')[0] || 'Super Admin (Test)',
        title: campaignTitle ? (campaignTitle.startsWith('[Test]') ? campaignTitle : `[Test] ${campaignTitle}`) : `[Test Video] ${youtubeUrl}`,
        youtube_url: youtubeUrl,
        budget: 0, // Super admin does not pay anything for test
        target_views: targetViews,
        views_count: 0,
        sender_upi_or_phone: 'SUPER_ADMIN_TEST_BYPASS',
        utr_number: 'SUPER_ADMIN_TEST_BYPASS',
        receipt_url: 'SUPER_ADMIN_TEST_BYPASS',
        reward_coins: 0, // No money/coins given for test campaigns
        is_test: true,
        teaser_url: finalTeaserUrl,
        teaser_duration: teaserDuration || 15,
        quiz_type: quizType,
        has_quiz: quizType !== 'none',
        ai_quiz_fee: 0,
        custom_questions: quizType !== 'none' ? customQuestions : [],
        super_admin_accepted: true,
        status: 'active' // Immediately active for testing
      });

      setCampaignSuccess(true);
      loadCreatorCampaigns();
    } catch (err: unknown) {
      setCampaignError(err instanceof Error ? err.message : 'Super Admin campaign creation failed');
    } finally {
      setCampaignSubmitting(false);
    }
  };

  // 4. Submit Campaign with UTR, Phone/UPI and Receipt
  const handleCampaignSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      openAuthModal();
      return;
    }

    // Normal creators must provide 15-second teaser, sender UPI/Phone, valid 12-digit UTR, and payment screenshot
    if (!isSuperAdminUser) {
      if (!teaserUrl) {
        setCampaignError('Please upload your 15-second teaser video to preview your content hook');
        return;
      }

      if (!senderUpiOrPhone || senderUpiOrPhone.trim().length < 3) {
        setCampaignError('Please enter the UPI ID or mobile number you used to make the payment');
        return;
      }

      if (!utrNumber || utrNumber.trim().length < 8) {
        setCampaignError('Please enter a valid 12-digit UPI UTR transaction reference number');
        return;
      }

      if (!receiptImage) {
        setCampaignError('Please attach a screenshot of your successful UPI transfer receipt');
        return;
      }
    }

    setCampaignSubmitting(true);
    setCampaignError(null);

    const defaultTeaser = 'https://assets.mixkit.co/videos/preview/mixkit-software-developer-working-on-code-screen-close-up-1728-large.mp4';
    const finalTeaserUrl = teaserUrl || (isSuperAdminUser ? defaultTeaser : '');

    try {
      await createCampaign({
        creator_uid: currentUser.uid,
        creator_email: currentUser.email || (isSuperAdminUser ? SUPER_ADMIN_EMAIL : ''),
        creator_name: userProfile?.displayName || currentUser.email?.split('@')[0] || (isSuperAdminUser ? 'Super Admin' : 'Creator'),
        title: isSuperAdminUser
          ? (campaignTitle ? (campaignTitle.startsWith('[Test]') ? campaignTitle : `[Test] ${campaignTitle}`) : `[Test Video] ${youtubeUrl}`)
          : (campaignTitle || `Campaign: ${youtubeUrl}`),
        youtube_url: youtubeUrl,
        budget: isSuperAdminUser ? 0 : budget,
        target_views: targetViews,
        views_count: 0,
        sender_upi_or_phone: isSuperAdminUser ? (senderUpiOrPhone.trim() || 'SUPER_ADMIN_TEST_BYPASS') : senderUpiOrPhone.trim(),
        utr_number: isSuperAdminUser ? (utrNumber.trim() || 'SUPER_ADMIN_TEST_BYPASS') : utrNumber.trim(),
        receipt_url: isSuperAdminUser ? (receiptImage || 'SUPER_ADMIN_TEST_BYPASS') : receiptImage,
        reward_coins: isSuperAdminUser ? 0 : 50,
        is_test: isSuperAdminUser,
        teaser_url: finalTeaserUrl,
        teaser_duration: teaserDuration || 15,
        quiz_type: quizType,
        has_quiz: quizType !== 'none',
        ai_quiz_fee: aiQuizFee,
        custom_questions: quizType !== 'none' ? customQuestions : [],
        super_admin_accepted: isSuperAdminUser ? true : false,
        status: isSuperAdminUser ? 'active' : 'pending_verification'
      });

      setCampaignSuccess(true);
      loadCreatorCampaigns();
    } catch (err: unknown) {
      setCampaignError(err instanceof Error ? err.message : 'Campaign submission failed');
    } finally {
      setCampaignSubmitting(false);
    }
  };

  const resetCampaignForm = () => {
    setYoutubeUrl('');
    setCampaignTitle('');
    setTargetViews(1000);
    setSenderUpiOrPhone('');
    setUtrNumber('');
    setReceiptImage('');
    setReceiptFileName('');
    setTeaserUrl('');
    setTeaserFileName('');
    setTeaserDuration(null);
    setTeaserNotice(null);
    setTeaserExternalUrl('');
    setQuizType('ai_generated');
    setCustomQuestions(DEFAULT_QUESTIONS_TEMPLATE);
    setQuizGenSuccess(false);
    setQuizGenError(null);
    setActiveQuestionIndex(0);
    setCampaignStep(1);
    setCampaignSuccess(false);
    setCampaignError(null);
  };

  if (!currentUser) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center">
        <div className="w-16 h-16 rounded-3xl bg-amber-500/10 text-amber-400 flex items-center justify-center mx-auto mb-4 border border-amber-500/20">
          <Video className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-bold text-white mb-2">Creator Transformation Portal</h2>
        <p className="text-sm text-slate-400 mb-6">
          Everyone starts with a regular user account. Sign in to send your YouTube channel link and request to transform into a creator!
        </p>
        <button
          onClick={openAuthModal}
          className="px-6 py-3 bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-white font-bold text-sm rounded-xl shadow-lg transition-all"
        >
          Sign In / Join VidQuest
        </button>
      </div>
    );
  }

  // View A: Regular user needs to apply first (Transform User to Creator Flow)
  if (role === 'user' && !appSuccess) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-10">
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl relative overflow-hidden">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-12 h-12 rounded-2xl bg-purple-500/15 text-purple-400 flex items-center justify-center border border-purple-500/30">
              <Youtube className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-mono uppercase text-purple-400 tracking-wider">
                User → Creator Transformation
              </span>
              <h2 className="text-2xl font-bold text-white">Transform Into a Verified Creator</h2>
            </div>
          </div>

          <div className="bg-slate-950/80 border border-slate-800/80 rounded-2xl p-4 text-xs text-slate-300 mb-6 space-y-2">
            <div className="flex items-center gap-2 font-semibold text-purple-300">
              <Sparkles className="w-4 h-4" />
              <span>How Creator Transformation Works:</span>
            </div>
            <p className="text-slate-400 leading-relaxed">
              Everyone starts with a standard user account. To become a creator, submit your YouTube channel link below. Your request will be transmitted directly to the Super Admin. Once the Super Admin reviews and accepts your request, your account is upgraded to an <strong className="text-purple-300">Approved Creator</strong> who can launch video campaigns with escrow.
            </p>
          </div>

          {appError && (
            <div className="mb-6 p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{appError}</span>
            </div>
          )}

          <form onSubmit={handleApplicationSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center gap-1.5">
                <Youtube className="w-3.5 h-3.5 text-rose-500" />
                <span>YouTube Channel Link <span className="text-rose-400">*</span></span>
              </label>
              <input
                id="channel-link-input"
                type="url"
                value={channelLink}
                onChange={(e) => setChannelLink(e.target.value)}
                placeholder="https://www.youtube.com/@YourChannel or https://youtube.com/channel/..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                required
              />
              <p className="text-[11px] text-slate-500 mt-1">
                The Super Admin will visit this link to verify your content and approve your creator privileges.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Channel Name
                </label>
                <input
                  id="channel-name-input"
                  type="text"
                  value={channelName}
                  onChange={(e) => setChannelName(e.target.value)}
                  placeholder="e.g. Code & Tech with Alex"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Subscriber Count
                </label>
                <input
                  id="subscriber-count-input"
                  type="text"
                  value={subscriberCount}
                  onChange={(e) => setSubscriberCount(e.target.value)}
                  placeholder="e.g. 15.2K"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                Content Description & Campaign Goals
              </label>
              <textarea
                id="app-description-input"
                value={appDescription}
                onChange={(e) => setAppDescription(e.target.value)}
                rows={3}
                placeholder="Tell the Super Admin about your channel, target audience, and video promotion plans..."
                className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
              />
            </div>

            <button
              id="submit-creator-application-btn"
              type="submit"
              disabled={appSubmitting}
              className="w-full py-3.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-sm rounded-xl transition-all shadow-lg shadow-purple-950/40 flex items-center justify-center gap-2 mt-4 disabled:opacity-50"
            >
              {appSubmitting ? (
                <span>Transmitting Request to Super Admin...</span>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  <span>Send Creator Request to Super Admin</span>
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    );
  }

  // View B: Pending review status
  if (role === 'pending_creator' || appSuccess) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16">
        <div className="bg-slate-900 border border-amber-500/30 rounded-3xl p-8 text-center shadow-2xl">
          <div className="w-16 h-16 rounded-3xl bg-amber-500/15 text-amber-400 flex items-center justify-center mx-auto mb-4 border border-amber-500/30">
            <Clock className="w-8 h-8" />
          </div>
          <span className="text-xs font-mono uppercase text-amber-400 tracking-wider font-semibold">
            Request Sent to Super Admin
          </span>
          <h2 className="text-2xl font-bold text-white mt-1 mb-3">
            Creator Application Under Review
          </h2>
          <p className="text-sm text-slate-400 max-w-md mx-auto mb-6 leading-relaxed">
            Your YouTube channel link has been logged in Firestore and is waiting on the Super Admin Desk.
            Once Super Admin Mrinal Kanti Singha Roy accepts your application, you will be able to launch video campaigns and deposit escrow.
          </p>

          <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-5 text-left text-xs text-slate-400 space-y-2.5">
            <div className="flex items-center gap-2 text-slate-200 font-semibold">
              <ShieldCheck className="w-4 h-4 text-amber-400" />
              <span>Next Steps:</span>
            </div>
            <p>1. Super Admin inspects your channel link in the Admin Desk (Tab 1).</p>
            <p>2. If accepted, your role automatically upgrades to <strong className="text-purple-300">Approved Creator</strong>.</p>
            <p>3. The Campaign Setup and Escrow Checkout will unlock on this page.</p>
          </div>
        </div>
      </div>
    );
  }

  // View C: Approved Creator or Super Admin Studio
  return (
    <div className="max-w-5xl mx-auto px-4 py-8">
      {/* Top Section Navigation: Video Campaigns vs Freelance Jobs */}
      <div className="flex items-center gap-2 mb-6 border-b border-slate-800 pb-4">
        <button
          onClick={() => setStudioSection('campaigns')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all ${
            studioSection === 'campaigns'
              ? 'bg-purple-600 text-white shadow-lg shadow-purple-950/50'
              : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          <Video className="w-4 h-4" />
          <span>Video Campaigns (Feed & Quiz)</span>
        </button>

        <button
          onClick={() => setStudioSection('freelance')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all ${
            studioSection === 'freelance'
              ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-950/50'
              : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          <Briefcase className="w-4 h-4" />
          <span>Freelance Jobs (Hire Editors & Designers)</span>
        </button>
      </div>

      {studioSection === 'freelance' ? (
        <CreatorFreelanceDesk escrowSettings={escrowSettings} />
      ) : (
        <>
          {/* Studio Header & Tab Switching */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 bg-slate-900 border border-slate-800 p-6 rounded-3xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-purple-500/20 text-purple-300 border border-purple-500/30">
              Verified Creator
            </span>
            <span className="text-xs text-slate-400">• Creator Studio</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight mt-1">
            Campaign Escrow & Promotion Launcher
          </h1>
        </div>

        <div className="flex items-center gap-2 bg-slate-950 p-1 rounded-xl border border-slate-800 self-start sm:self-auto">
          <button
            id="tab-new-campaign-btn"
            onClick={() => {
              setActiveTab('create');
              if (campaignSuccess) resetCampaignForm();
            }}
            className={`px-4 py-2 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'create'
                ? 'bg-purple-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Launch Campaign
          </button>
          <button
            id="tab-my-campaigns-btn"
            onClick={() => setActiveTab('list')}
            className={`px-4 py-2 rounded-lg text-xs font-semibold transition-colors ${
              activeTab === 'list'
                ? 'bg-purple-600 text-white shadow'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            My Campaigns ({creatorCampaigns.length})
          </button>
        </div>
      </div>

      {activeTab === 'create' ? (
        /* Create Campaign Flow */
        campaignSuccess ? (
          <div className="bg-slate-900 border border-emerald-500/30 rounded-3xl p-8 text-center max-w-xl mx-auto shadow-2xl space-y-4">
            <div className="w-16 h-16 rounded-3xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/30">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <h2 className="text-2xl font-bold text-white">Campaign Submitted to Escrow Desk!</h2>
            <p className="text-sm text-slate-400">
              Your campaign status is now <strong className="text-amber-400">pending_verification</strong>.
              Super Admin will verify your UTR number (
              <span className="font-mono text-slate-300">{utrNumber}</span>) and activate your campaign on the feed.
            </p>
            <div className="pt-4 flex justify-center gap-3">
              <button
                onClick={() => setActiveTab('list')}
                className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-medium text-xs rounded-xl transition-colors"
              >
                View My Campaigns
              </button>
              <button
                onClick={resetCampaignForm}
                className="px-5 py-2.5 bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs rounded-xl transition-colors"
              >
                Create Another Campaign
              </button>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Left Column: Form & Step Control */}
            <div className="lg:col-span-7 space-y-6">
              {/* Stepper Progress */}
              <div className="flex items-center gap-3 bg-slate-900 border border-slate-800 p-3 rounded-2xl">
                <div
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-semibold ${
                    campaignStep === 1
                      ? 'bg-purple-600 text-white'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  <span>1. Campaign Setup</span>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-600" />
                <div
                  className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-semibold ${
                    campaignStep === 2
                      ? 'bg-purple-600 text-white'
                      : 'bg-slate-800 text-slate-400'
                  }`}
                >
                  <span>2. UPI Escrow Checkout & UTR</span>
                </div>
              </div>

              {campaignError && (
                <div className="p-4 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
                  <span>{campaignError}</span>
                </div>
              )}

              {campaignStep === 1 ? (
                /* Step 1: URL & Budget Setup */
                <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-2">
                      YouTube Video URL <span className="text-rose-400">*</span>
                    </label>
                    <input
                      id="campaign-youtube-url-input"
                      type="url"
                      value={youtubeUrl}
                      onChange={(e) => setYoutubeUrl(e.target.value)}
                      placeholder="https://www.youtube.com/watch?v=dQw4w9WgXcQ"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                      required
                    />
                    <p className="text-[11px] text-slate-500 mt-1">
                      Paste any public YouTube video link. We will embed it in the feed with a 5-question quiz.
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-2">
                      Campaign Title
                    </label>
                    <input
                      id="campaign-title-input"
                      type="text"
                      value={campaignTitle}
                      onChange={(e) => setCampaignTitle(e.target.value)}
                      placeholder="e.g. Learn React 19 in 15 Minutes"
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                    />
                  </div>

                  {/* 15-Second Teaser Upload Section */}
                  <div className="bg-slate-950/70 border border-purple-500/30 rounded-2xl p-5 space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-xl bg-purple-500/20 text-purple-300 flex items-center justify-center border border-purple-500/30 shrink-0">
                          <Film className="w-4 h-4" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-sm font-bold text-white">15-Second Video Teaser Hook</span>
                            {!isSuperAdminUser ? (
                              <span className="text-rose-400 font-bold text-xs">*Required</span>
                            ) : (
                              <span className="text-emerald-400 font-medium text-xs">(Admin Test Ready)</span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-400">
                            Upload your 15-second teaser clip. This teaser is showcased in the feed to hook viewers before they watch the full video and complete the quiz.
                          </p>
                        </div>
                      </div>

                      {/* Source Type Toggle */}
                      <div className="flex items-center bg-slate-900 border border-slate-800 rounded-lg p-0.5 text-xs self-start sm:self-auto shrink-0">
                        <button
                          type="button"
                          onClick={() => setTeaserSourceType('upload')}
                          className={`px-2.5 py-1 rounded-md font-medium transition-all ${
                            teaserSourceType === 'upload'
                              ? 'bg-purple-600 text-white shadow'
                              : 'text-slate-400 hover:text-white'
                          }`}
                        >
                          Upload File
                        </button>
                        <button
                          type="button"
                          onClick={() => setTeaserSourceType('url')}
                          className={`px-2.5 py-1 rounded-md font-medium transition-all ${
                            teaserSourceType === 'url'
                              ? 'bg-purple-600 text-white shadow'
                              : 'text-slate-400 hover:text-white'
                          }`}
                        >
                          Teaser URL
                        </button>
                      </div>
                    </div>

                    {teaserUrl ? (
                      /* Live Video Preview Player */
                      <div className="space-y-3">
                        <div className="relative rounded-xl overflow-hidden bg-black border border-purple-500/30 aspect-video max-h-56 flex items-center justify-center">
                          <video
                            src={teaserUrl}
                            controls
                            playsInline
                            className="w-full h-full object-contain"
                            onLoadedMetadata={(e) => {
                              const dur = Math.round(e.currentTarget.duration * 10) / 10;
                              setTeaserDuration(dur);
                              if (dur <= 16) {
                                setTeaserNotice(`Optimal duration: ${dur}s (Perfect 15-second hook)`);
                              } else {
                                setTeaserNotice(`Duration: ${dur}s. The first 15 seconds will serve as the feed preview.`);
                              }
                            }}
                          />
                          <div className="absolute top-2 left-2 px-2.5 py-1 rounded-md bg-black/80 backdrop-blur-md text-[11px] font-semibold text-purple-300 border border-purple-500/30 flex items-center gap-1.5 pointer-events-none">
                            <Clock className="w-3.5 h-3.5 text-purple-400" />
                            <span>{teaserDuration ? `${teaserDuration}s` : '15-Sec Preview'}</span>
                          </div>
                        </div>

                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 bg-slate-900/80 p-3 rounded-xl border border-slate-800 text-xs">
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-2 text-white font-medium">
                              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                              <span className="truncate max-w-[240px] sm:max-w-xs">{teaserFileName || '15-Second Teaser Video'}</span>
                              {teaserDuration && (
                                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                  teaserDuration <= 16
                                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                    : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                                }`}>
                                  {teaserDuration <= 16 ? '15s Hook Verified' : `${teaserDuration}s Clip`}
                                </span>
                              )}
                            </div>
                            {teaserNotice && (
                              <p className="text-[11px] text-slate-400 pl-6">{teaserNotice}</p>
                            )}
                          </div>

                          <div className="flex items-center gap-2 self-end sm:self-center">
                            <button
                              type="button"
                              onClick={() => {
                                setTeaserUrl('');
                                setTeaserFileName('');
                                setTeaserDuration(null);
                                setTeaserNotice(null);
                              }}
                              className="px-3 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              <span>Remove</span>
                            </button>
                          </div>
                        </div>
                      </div>
                    ) : teaserSourceType === 'upload' ? (
                      /* Drag & Drop Upload Zone */
                      <div className="space-y-2">
                        <div
                          onDragOver={(e) => {
                            e.preventDefault();
                            setIsDraggingTeaser(true);
                          }}
                          onDragLeave={(e) => {
                            e.preventDefault();
                            setIsDraggingTeaser(false);
                          }}
                          onDrop={(e) => {
                            e.preventDefault();
                            setIsDraggingTeaser(false);
                            if (e.dataTransfer.files?.[0]) {
                              handleTeaserFileSelect(e.dataTransfer.files[0]);
                            }
                          }}
                          className={`relative border-2 border-dashed rounded-2xl p-6 text-center transition-all cursor-pointer ${
                            isDraggingTeaser
                              ? 'border-purple-400 bg-purple-950/30 scale-[1.01]'
                              : 'border-slate-800 hover:border-purple-500/50 bg-slate-900/40 hover:bg-slate-900/70'
                          }`}
                          onClick={() => document.getElementById('teaser-file-input')?.click()}
                        >
                          <input
                            id="teaser-file-input"
                            type="file"
                            accept="video/mp4,video/webm,video/ogg,video/quicktime,video/*"
                            className="hidden"
                            onChange={(e) => {
                              if (e.target.files?.[0]) {
                                handleTeaserFileSelect(e.target.files[0]);
                              }
                            }}
                          />
                          <div className="space-y-2">
                            <div className="w-12 h-12 rounded-2xl bg-purple-500/10 text-purple-400 flex items-center justify-center mx-auto border border-purple-500/20">
                              <UploadCloud className="w-6 h-6" />
                            </div>
                            <div className="text-xs font-semibold text-white">
                              Drag & drop your 15-second teaser clip here, or <span className="text-purple-400 underline">browse</span>
                            </div>
                            <p className="text-[11px] text-slate-400">
                              Accepts MP4, WebM, MOV (recommended duration ~15s, max 35MB)
                            </p>
                          </div>
                        </div>

                        {/* Quick Presets / Test Buttons */}
                        <div className="flex items-center justify-between pt-1">
                          <span className="text-[11px] text-slate-400">Need a sample 15-sec hook?</span>
                          <button
                            type="button"
                            onClick={() =>
                              handleUseSampleTeaser(
                                'https://assets.mixkit.co/videos/preview/mixkit-software-developer-working-on-code-screen-close-up-1728-large.mp4',
                                '15s_code_developer_teaser.mp4'
                              )
                            }
                            className="text-[11px] text-purple-400 hover:text-purple-300 font-semibold underline flex items-center gap-1"
                          >
                            <Sparkles className="w-3 h-3" />
                            <span>Attach 15s Sample Teaser</span>
                          </button>
                        </div>
                      </div>
                    ) : (
                      /* URL Input Mode */
                      <div className="space-y-3">
                        <div>
                          <label className="block text-[11px] font-medium text-slate-400 mb-1">
                            15-Second Teaser Video URL / Direct Clip Link
                          </label>
                          <div className="flex gap-2">
                            <input
                              type="url"
                              value={teaserExternalUrl}
                              onChange={(e) => setTeaserExternalUrl(e.target.value)}
                              placeholder="https://example.com/teaser-15s.mp4 or YouTube Short"
                              className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                            />
                            <button
                              type="button"
                              onClick={() => {
                                if (!teaserExternalUrl.trim()) return;
                                setTeaserUrl(teaserExternalUrl.trim());
                                setTeaserFileName('External Teaser Clip');
                                setTeaserDuration(15);
                                setTeaserNotice('External 15-second teaser attached.');
                              }}
                              className="px-3 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-semibold"
                            >
                              Attach
                            </button>
                          </div>
                        </div>

                        <div className="flex items-center justify-between pt-1">
                          <span className="text-[11px] text-slate-400">Quick 15s test clip:</span>
                          <button
                            type="button"
                            onClick={() =>
                              handleUseSampleTeaser(
                                'https://assets.mixkit.co/videos/preview/mixkit-software-developer-working-on-code-screen-close-up-1728-large.mp4',
                                '15s_sample_hook.mp4'
                              )
                            }
                            className="text-[11px] text-purple-400 hover:text-purple-300 font-semibold underline flex items-center gap-1"
                          >
                            <Sparkles className="w-3 h-3" />
                            <span>Attach 15s Sample Clip</span>
                          </button>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Target Audience Size with Volume Discount */}
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-xs font-semibold text-slate-300">
                        Target Audience Size
                      </label>
                      <span className="text-[11px] text-emerald-400 font-semibold bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                        Volume Discount Active
                      </span>
                    </div>

                    {/* Presets Grid with 6 Specified Tiers */}
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 mb-3">
                      {VIEW_TIERS.map((tier) => (
                        <button
                          key={tier.views}
                          type="button"
                          onClick={() => setTargetViews(tier.views)}
                          className={`p-2.5 rounded-xl border text-xs font-semibold transition-all relative ${
                            targetViews === tier.views
                              ? 'bg-purple-600/20 border-purple-500 text-purple-300 ring-1 ring-purple-500/50 shadow-md'
                              : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                          }`}
                        >
                          {tier.badge && (
                            <span className="absolute -top-2 right-1.5 px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-emerald-400 text-slate-950 shadow">
                              {tier.badge}
                            </span>
                          )}
                          <div>{tier.views.toLocaleString()} Views</div>
                          <div className="text-[12px] font-mono text-purple-400 font-bold mt-0.5">
                            ₹{tier.price.toLocaleString('en-IN')}
                          </div>
                        </button>
                      ))}
                    </div>

                    <input
                      id="custom-views-slider"
                      type="range"
                      min={200}
                      max={10000}
                      step={100}
                      value={targetViews}
                      onChange={(e) => setTargetViews(Number(e.target.value))}
                      className="w-full accent-purple-500"
                    />
                    <div className="flex justify-between text-xs text-slate-500 mt-1">
                      <span>200 Views (₹100)</span>
                      <span className="text-slate-300 font-medium">
                        Selected: {targetViews.toLocaleString()} Views (₹{budget.toLocaleString('en-IN')})
                      </span>
                      <span>10,000 Views (₹4,400)</span>
                    </div>
                  </div>

                  {/* Video Comprehension Quiz Configuration (AI vs Manual) */}
                  <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-5 space-y-4">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800/80 pb-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <HelpCircle className="w-4 h-4 text-purple-400" />
                          <h4 className="text-sm font-bold text-white">
                            Video Comprehension Quiz (5 Questions)
                          </h4>
                        </div>
                        <p className="text-xs text-slate-400 mt-0.5">
                          Viewers must answer these 5 questions based on your video to earn rewards and verify retention.
                        </p>
                      </div>

                      {/* Pricing Notice */}
                      <div className="text-right">
                        {isAiFree ? (
                          <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                            🎉 AI Quiz FREE (Campaign ≥ ₹500)
                          </span>
                        ) : (
                          <span className="px-2.5 py-1 rounded-full text-[11px] font-bold bg-purple-500/15 text-purple-300 border border-purple-500/30">
                            AI Quiz: ₹10 (Free for ₹500+)
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Mode Selection Tabs (AI Automated vs. Creator Custom Questions vs. No Quiz Direct Watch) */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <button
                        type="button"
                        onClick={() => setQuizType('ai_generated')}
                        className={`p-3.5 rounded-xl border text-left transition-all ${
                          quizType === 'ai_generated'
                            ? 'bg-purple-950/40 border-purple-500 ring-1 ring-purple-500/40 text-purple-200 shadow-md'
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5 font-bold text-white text-xs">
                            <Bot className="w-4 h-4 text-purple-400 shrink-0" />
                            <span>AI-Automated Quiz</span>
                          </div>
                          {isAiFree ? (
                            <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
                              FREE
                            </span>
                          ) : (
                            <span className="text-[10px] font-bold text-purple-300 bg-purple-500/20 px-1.5 py-0.5 rounded border border-purple-500/30 font-mono">
                              +₹10
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-400 mt-1.5 leading-relaxed">
                          Gemini AI generates 5 multiple-choice questions automatically from your video.
                        </p>
                      </button>

                      <button
                        type="button"
                        onClick={() => setQuizType('manual')}
                        className={`p-3.5 rounded-xl border text-left transition-all ${
                          quizType === 'manual'
                            ? 'bg-indigo-950/40 border-indigo-500 ring-1 ring-indigo-500/40 text-indigo-200 shadow-md'
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5 font-bold text-white text-xs">
                            <Edit3 className="w-4 h-4 text-indigo-400 shrink-0" />
                            <span>Custom Questions</span>
                          </div>
                          <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
                            FREE
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-1.5 leading-relaxed">
                          Provide your own 5 custom questions to test specific product or tutorial details.
                        </p>
                      </button>

                      <button
                        type="button"
                        onClick={() => setQuizType('none')}
                        className={`p-3.5 rounded-xl border text-left transition-all ${
                          quizType === 'none'
                            ? 'bg-emerald-950/40 border-emerald-500 ring-1 ring-emerald-500/40 text-emerald-200 shadow-md'
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-1.5 font-bold text-white text-xs">
                            <PlayCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                            <span>No Quiz (Direct)</span>
                          </div>
                          <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
                            FREE
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-1.5 leading-relaxed">
                          Viewers earn coins simply by watching your video. Instant reward claim without a test.
                        </p>
                      </button>
                    </div>

                    {/* No Quiz Notice */}
                    {quizType === 'none' && (
                      <div className="bg-emerald-950/30 border border-emerald-500/30 rounded-xl p-3.5 flex items-center gap-3 text-xs text-emerald-300">
                        <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                        <div>
                          <div className="font-semibold text-emerald-200">Direct Watch & Earn Mode Active</div>
                          <div className="text-[11px] text-emerald-300/80 mt-0.5">
                            Users will watch your full video with verified retention and claim reward coins directly without answering quiz questions.
                          </div>
                        </div>
                      </div>
                    )}

                    {/* AI Generation Trigger Bar if AI mode selected */}
                    {quizType === 'ai_generated' && (
                      <div className="bg-purple-950/20 border border-purple-800/40 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="text-xs text-purple-200">
                          <div className="font-semibold flex items-center gap-1.5">
                            <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                            <span>Automate Quiz with Video Analysis</span>
                          </div>
                          <div className="text-[11px] text-purple-300/70">
                            Click below to let AI watch the video and synthesize 5 multiple-choice questions.
                          </div>
                        </div>

                        <button
                          type="button"
                          onClick={handleGenerateAiQuiz}
                          disabled={isGeneratingQuiz || !youtubeUrl}
                          className="px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs rounded-xl transition-all shadow disabled:opacity-50 flex items-center justify-center gap-2 shrink-0"
                        >
                          {isGeneratingQuiz ? (
                            <>
                              <Loader2 className="w-3.5 h-3.5 animate-spin" />
                              <span>AI Analyzing Video...</span>
                            </>
                          ) : (
                            <>
                              <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                              <span>{quizGenSuccess ? 'Regenerate Questions with AI' : 'Generate Quiz with AI'}</span>
                            </>
                          )}
                        </button>
                      </div>
                    )}

                    {quizType === 'ai_generated' && quizGenSuccess && (
                      <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
                        <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>AI generated 5 verified questions successfully! You can review or tweak them below.</span>
                      </div>
                    )}

                    {quizType === 'ai_generated' && quizGenError && (
                      <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                        <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                        <span>{quizGenError}</span>
                      </div>
                    )}

                    {/* Question Inspector / Customizer (Q1-Q5) - Shown only if quizType is ai_generated or manual */}
                    {quizType !== 'none' && (
                    <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-semibold text-slate-300">
                          {quizType === 'ai_generated' ? 'Review & Edit AI Questions' : 'Customize Your 5 Questions'}:
                        </span>
                        <div className="flex gap-1">
                          {customQuestions.map((_, idx) => (
                            <button
                              key={idx}
                              type="button"
                              onClick={() => setActiveQuestionIndex(idx)}
                              className={`w-7 h-7 rounded-lg text-xs font-bold transition-all ${
                                activeQuestionIndex === idx
                                  ? 'bg-purple-600 text-white shadow'
                                  : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                              }`}
                            >
                              Q{idx + 1}
                            </button>
                          ))}
                        </div>
                      </div>

                      {/* Question Text Input */}
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                          Question {activeQuestionIndex + 1} Prompt:
                        </label>
                        <input
                          type="text"
                          value={customQuestions[activeQuestionIndex]?.question || ''}
                          onChange={(e) => handleUpdateQuestionText(activeQuestionIndex, e.target.value)}
                          placeholder="e.g. What is the key method shown in the demonstration?"
                          className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
                        />
                      </div>

                      {/* 4 Options with Correct Answer Selector */}
                      <div className="space-y-2 pt-1">
                        <label className="block text-[11px] font-semibold text-slate-400">
                          Options (Select the radio icon on the correct answer):
                        </label>
                        {customQuestions[activeQuestionIndex]?.options.map((opt, optIdx) => {
                          const isCorrect = customQuestions[activeQuestionIndex]?.correctAnswerIndex === optIdx;
                          return (
                            <div
                              key={optIdx}
                              className={`flex items-center gap-2 p-2 rounded-xl border transition-all ${
                                isCorrect
                                  ? 'bg-emerald-950/30 border-emerald-500/40 text-emerald-200'
                                  : 'bg-slate-950 border-slate-800 text-slate-300'
                              }`}
                            >
                              <button
                                type="button"
                                onClick={() => handleSetCorrectAnswer(activeQuestionIndex, optIdx)}
                                title={isCorrect ? 'Correct answer key' : 'Click to set as correct answer'}
                                className={`w-5 h-5 rounded-full flex items-center justify-center shrink-0 text-[10px] font-bold transition-all ${
                                  isCorrect
                                    ? 'bg-emerald-500 text-slate-950 ring-2 ring-emerald-400/40'
                                    : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                                }`}
                              >
                                {isCorrect ? '✓' : String.fromCharCode(65 + optIdx)}
                              </button>
                              <input
                                type="text"
                                value={opt}
                                onChange={(e) => handleUpdateOption(activeQuestionIndex, optIdx, e.target.value)}
                                placeholder={`Option ${String.fromCharCode(65 + optIdx)}`}
                                className="flex-1 bg-transparent border-0 text-xs text-white placeholder-slate-500 focus:outline-none"
                              />
                              {isCorrect && (
                                <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
                                  Correct Key
                                </span>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                    )}
                  </div>

                  {/* Summary Box with Volume Discount & Quiz Fee Line Item */}
                  <div className="bg-slate-950/80 border border-slate-800/80 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="space-y-1">
                      <div className="text-xs text-slate-400">Total Campaign Escrow:</div>
                      <div className="flex items-baseline gap-2">
                        {isSuperAdminUser ? (
                          <>
                            <span className="text-2xl font-black text-emerald-400 font-mono">₹0</span>
                            <span className="text-xs font-mono text-slate-500 line-through">
                              ₹{totalCampaignAmount.toLocaleString('en-IN')}
                            </span>
                            <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold">
                              Super Admin Test: ₹0 Free
                            </span>
                          </>
                        ) : (
                          <>
                            <span className="text-2xl font-black text-emerald-400 font-mono">
                              ₹{totalCampaignAmount.toLocaleString('en-IN')}
                            </span>
                            {savings > 0 && (
                              <span className="text-xs font-mono text-slate-500 line-through">
                                ₹{(basePrice + aiQuizFee).toLocaleString('en-IN')}
                              </span>
                            )}
                          </>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-400 flex items-center gap-2">
                        <span>Views: ₹{budget.toLocaleString('en-IN')}</span>
                        <span>•</span>
                        <span>
                          Quiz:{' '}
                          {quizType === 'ai_generated' ? (
                            isAiFree ? (
                              <strong className="text-emerald-400 font-semibold">AI (FREE ≥₹500)</strong>
                            ) : (
                              <strong className="text-purple-300 font-mono">AI (+₹10)</strong>
                            )
                          ) : (
                            <strong className="text-emerald-400 font-semibold">Custom (FREE)</strong>
                          )}
                        </span>
                      </div>
                    </div>
                    <div className="text-left sm:text-right text-xs">
                      {isSuperAdminUser ? (
                        <div>
                          <span className="text-emerald-400 font-bold">Payment Exempt (Test Mode)</span>
                          <div className="text-slate-400 text-[11px]">Free posting for Super Admin</div>
                        </div>
                      ) : (
                        <>
                          <div className="text-slate-300 font-medium">
                            Rate: <span className="text-emerald-400 font-mono font-semibold">₹{effectiveRate}</span> / View
                          </div>
                          {savings > 0 ? (
                            <div className="text-emerald-400 font-semibold text-[11px] flex items-center sm:justify-end gap-1">
                              <span>Volume Discount: Save ₹{savings.toLocaleString('en-IN')}!</span>
                            </div>
                          ) : (
                            <div className="text-slate-500 text-[11px]">Includes reward escrow</div>
                          )}
                        </>
                      )}
                    </div>
                  </div>

                  {isSuperAdminUser ? (
                    <div className="space-y-3">
                      <div className="bg-emerald-950/40 border border-emerald-500/30 rounded-2xl p-4 text-xs text-emerald-200 space-y-1">
                        <div className="flex items-center gap-2 font-bold text-emerald-300 text-sm">
                          <Sparkles className="w-4 h-4 text-emerald-400" />
                          <span>Super Admin Testing Mode — Free Post</span>
                        </div>
                        <p className="text-slate-300 text-xs">
                          For testing only: As Super Admin, no money is required. This video feed will be posted with an <strong className="text-amber-300">"Only for Test Purposes"</strong> badge, and users will see that no money/coins are given for it.
                        </p>
                      </div>

                      <button
                        id="super-admin-direct-post-btn"
                        type="button"
                        onClick={handleSuperAdminDirectPost}
                        disabled={campaignSubmitting}
                        className="w-full py-3.5 bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-sm rounded-xl transition-all shadow-xl shadow-emerald-950/50 flex items-center justify-center gap-2 disabled:opacity-50"
                      >
                        {campaignSubmitting ? (
                          <span>Publishing Test Campaign...</span>
                        ) : (
                          <>
                            <Sparkles className="w-4 h-4 text-slate-950" />
                            <span>Post Campaign (Super Admin — ₹0 / No Money Needed)</span>
                          </>
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          if (!youtubeUrl) {
                            setCampaignError('Please enter a YouTube video URL first');
                            return;
                          }
                          setCampaignError(null);
                          setCampaignStep(2);
                        }}
                        className="w-full py-2 text-xs text-slate-400 hover:text-slate-200 transition-colors"
                      >
                        Or preview verification step →
                      </button>
                    </div>
                  ) : (
                    <button
                      id="proceed-to-checkout-btn"
                      type="button"
                      onClick={() => {
                        if (!youtubeUrl) {
                          setCampaignError('Please enter a YouTube video URL');
                          return;
                        }
                        if (!teaserUrl && !isSuperAdminUser) {
                          setCampaignError('Please upload your 15-second teaser video before proceeding to checkout');
                          return;
                        }
                        setCampaignError(null);
                        setCampaignStep(2);
                      }}
                      className="w-full py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold text-sm rounded-xl transition-all shadow-lg flex items-center justify-center gap-2"
                    >
                      <span>Proceed to UPI Escrow Checkout</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ) : (
                /* Step 2: Checkout & Verification Submission */
                <form
                  onSubmit={handleCampaignSubmit}
                  className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6"
                >
                  <div className="flex items-center justify-between border-b border-slate-800 pb-4">
                    <div>
                      <h3 className="font-bold text-white text-lg">
                        {isSuperAdminUser ? 'Launch Campaign (Super Admin Test)' : 'Verify UPI Payment'}
                      </h3>
                      <p className="text-xs text-slate-400">
                        {isSuperAdminUser ? (
                          <span className="text-emerald-400 font-semibold">
                            Super Admin Test Mode: Amount ₹0 (No payment or receipts needed)
                          </span>
                        ) : (
                          `Scan the official QR, send exact total ₹${totalCampaignAmount}, and enter transaction details`
                        )}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setCampaignStep(1)}
                      className="text-xs text-purple-400 hover:underline"
                    >
                      ← Edit Details
                    </button>
                  </div>

                  {/* Itemized Checkout Breakdown */}
                  {!isSuperAdminUser && (
                    <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800 text-xs space-y-2">
                      <div className="flex items-center justify-between text-slate-400">
                        <span>Campaign Audience ({targetViews.toLocaleString()} views):</span>
                        <span className="font-mono text-white font-semibold">₹{budget.toLocaleString('en-IN')}</span>
                      </div>
                      <div className="flex items-center justify-between text-slate-400">
                        <span className="flex items-center gap-1.5">
                          <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                          <span>Quiz Mode ({quizType === 'ai_generated' ? 'AI Automated Video Quiz' : 'Creator Custom Written'}):</span>
                        </span>
                        <span className="font-mono font-semibold">
                          {quizType === 'ai_generated' ? (
                            aiQuizFee > 0 ? (
                              <span className="text-purple-400">+₹10</span>
                            ) : (
                              <span className="text-emerald-400">FREE {budget >= 500 ? '(Spend ≥ ₹500)' : ''}</span>
                            )
                          ) : (
                            <span className="text-emerald-400">FREE</span>
                          )}
                        </span>
                      </div>
                      <div className="border-t border-slate-800 pt-2 flex items-center justify-between text-sm">
                        <span className="font-bold text-white">Total Amount to Transfer:</span>
                        <span className="font-mono font-black text-emerald-400 text-base">
                          ₹{totalCampaignAmount.toLocaleString('en-IN')}
                        </span>
                      </div>
                    </div>
                  )}

                  {isSuperAdminUser && (
                    <div className="bg-emerald-950/40 border border-emerald-500/30 rounded-xl p-3 text-xs text-emerald-200 flex items-center gap-2">
                      <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
                      <span>
                        Testing bypass active: UTR and receipt screenshot are optional. Click the button below to post.
                      </span>
                    </div>
                  )}

                  {/* 12-Digit UTR Number */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-2">
                      12-Digit UPI UTR / Transaction Reference Number{' '}
                      {isSuperAdminUser ? (
                        <span className="text-amber-400 font-normal text-[11px]">(Optional for Super Admin Test)</span>
                      ) : (
                        <span className="text-rose-400">*</span>
                      )}
                    </label>
                    <input
                      id="utr-number-input"
                      type="text"
                      maxLength={16}
                      value={utrNumber}
                      onChange={(e) => setUtrNumber(e.target.value.replace(/\s+/g, ''))}
                      placeholder={isSuperAdminUser ? 'Optional (defaults to SUPER_ADMIN_TEST_BYPASS)' : 'e.g. 425981039482'}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm font-mono tracking-wider text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                      required={!isSuperAdminUser}
                    />
                    <p className="text-[11px] text-slate-500 mt-1">
                      {isSuperAdminUser
                        ? 'Super Admin test mode active — no payment required.'
                        : 'You will find the 12-digit UTR on your GPay / PhonePe / Paytm payment receipt.'}
                    </p>
                  </div>

                  {/* Receipt Screenshot Upload */}
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-2">
                      Upload Payment Screenshot Receipt{' '}
                      {isSuperAdminUser ? (
                        <span className="text-amber-400 font-normal text-[11px]">(Optional for Super Admin Test)</span>
                      ) : (
                        <span className="text-rose-400">*</span>
                      )}
                    </label>

                    <div className="border-2 border-dashed border-slate-800 hover:border-slate-700 bg-slate-950 rounded-2xl p-6 text-center transition-colors">
                      {receiptImage ? (
                        <div className="space-y-3">
                          <img
                            src={receiptImage}
                            alt="Receipt Preview"
                            className="max-h-48 rounded-xl mx-auto border border-slate-800 object-contain"
                          />
                          <div className="text-xs text-emerald-400 flex items-center justify-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Receipt Attached: {receiptFileName || 'receipt.png'}</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              setReceiptImage('');
                              setReceiptFileName('');
                            }}
                            className="text-xs text-rose-400 hover:underline"
                          >
                            Remove and select different image
                          </button>
                        </div>
                      ) : (
                        <label className="cursor-pointer block space-y-2">
                          <Upload className="w-8 h-8 mx-auto text-slate-500" />
                          <div className="text-xs text-slate-300 font-medium">
                            {isSuperAdminUser
                              ? 'Optional for Super Admin: Click to attach test screenshot if desired'
                              : 'Click to upload or drag and drop receipt screenshot'}
                          </div>
                          <div className="text-[11px] text-slate-500">
                            PNG, JPG, or WEBP up to 5MB
                          </div>
                          <input
                            id="receipt-file-input"
                            type="file"
                            accept="image/*"
                            onChange={handleImageFileChange}
                            className="hidden"
                          />
                        </label>
                      )}
                    </div>
                  </div>

                  <button
                    id="submit-campaign-verification-btn"
                    type="submit"
                    disabled={campaignSubmitting}
                    className="w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-bold text-sm rounded-xl transition-all shadow-lg shadow-emerald-950/40 flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {campaignSubmitting ? (
                      <span>Verifying & Logging Campaign...</span>
                    ) : isSuperAdminUser ? (
                      <>
                        <Sparkles className="w-4 h-4 text-slate-950" />
                        <span>Post Campaign Directly (Super Admin — ₹0 / Free)</span>
                      </>
                    ) : (
                      <>
                        <ShieldCheck className="w-4 h-4 text-slate-950" />
                        <span>Submit Campaign for Admin Verification</span>
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>

            {/* Right Column: Live QR Code & Campaign Preview */}
            <div className="lg:col-span-5 space-y-6">
              {/* Official UPI QR Code Card with dynamic Super Admin settings */}
              <UPIQRCode
                amount={isSuperAdminUser ? 0 : totalCampaignAmount}
                upiId={escrowSettings.upi_id}
                payeeName={escrowSettings.payee_name}
                qrImageUrl={escrowSettings.qr_image_url}
                isSuperAdmin={isSuperAdminUser}
              />

              {/* Video Thumbnail Preview */}
              {videoId && (
                <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-3">
                  <div className="text-xs font-semibold text-slate-400">Target Video Preview:</div>
                  <div className="aspect-video w-full rounded-xl overflow-hidden bg-slate-950 relative">
                    <img
                      src={`https://img.youtube.com/vi/${videoId}/hqdefault.jpg`}
                      alt="Thumbnail preview"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="text-xs text-slate-300 font-medium truncate">
                    {campaignTitle || 'YouTube Video'}
                  </div>
                </div>
              )}

              {/* 15-Second Teaser Video Hook Preview in Right Column */}
              {teaserUrl && (
                <div className="bg-slate-900 border border-purple-500/30 rounded-2xl p-4 space-y-3">
                  <div className="flex items-center justify-between text-xs font-semibold">
                    <span className="text-purple-300 flex items-center gap-1.5">
                      <Film className="w-3.5 h-3.5 text-purple-400" />
                      <span>15s Teaser Hook Preview:</span>
                    </span>
                    {teaserDuration && (
                      <span className="text-[10px] font-mono text-purple-300 bg-purple-500/20 px-2 py-0.5 rounded-full border border-purple-500/30 font-bold">
                        {teaserDuration}s Clip
                      </span>
                    )}
                  </div>
                  <div className="aspect-video w-full rounded-xl overflow-hidden bg-black relative flex items-center justify-center">
                    <video
                      src={teaserUrl}
                      controls
                      playsInline
                      className="w-full h-full object-contain"
                    />
                  </div>
                  <div className="text-[11px] text-slate-400 truncate">
                    {teaserFileName || '15-second teaser clip ready'}
                  </div>
                </div>
              )}
            </div>
          </div>
        )
      ) : (
        /* Creator's Campaign List */
        <div className="space-y-4">
          {/* Toast Notification */}
          {deleteToast && (
            <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center justify-between shadow-lg">
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="font-medium">{deleteToast}</span>
              </div>
              <button
                type="button"
                onClick={() => setDeleteToast(null)}
                className="text-emerald-400 hover:text-white"
              >
                ✕
              </button>
            </div>
          )}

          {loadingCampaigns ? (
            <div className="bg-slate-900 border border-slate-800 p-8 rounded-2xl animate-pulse text-center text-slate-500">
              Loading your campaigns...
            </div>
          ) : creatorCampaigns.length === 0 ? (
            <div className="bg-slate-900 border border-slate-800 p-12 rounded-3xl text-center text-slate-400 space-y-3">
              <Video className="w-10 h-10 mx-auto text-slate-600" />
              <h3 className="text-base font-bold text-white">No campaigns created yet</h3>
              <p className="text-xs text-slate-500">
                You haven't launched any campaigns yet. Launch one now to drive verified quiz views!
              </p>
              <button
                onClick={() => setActiveTab('create')}
                className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-semibold text-xs rounded-xl"
              >
                Launch First Campaign
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {creatorCampaigns.map((camp) => {
                const isTargetReached = (camp.views_count || 0) >= (camp.target_views || 1000);
                const percentReached = Math.min(100, Math.round(((camp.views_count || 0) / (camp.target_views || 1000)) * 100));

                return (
                  <div
                    key={camp.id}
                    className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3 relative group"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="space-y-1">
                        <h3 className="font-bold text-sm text-white line-clamp-1">{camp.title}</h3>
                        {isTargetReached && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold">
                            🎯 Target Audience Reached
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-1.5 shrink-0">
                        <span
                          className={`text-[10px] font-mono px-2 py-0.5 rounded-full uppercase tracking-wider font-bold ${
                            camp.status === 'active'
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                              : camp.status === 'completed'
                              ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                              : camp.status === 'pending_verification'
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                              : 'bg-slate-800 text-slate-400'
                          }`}
                        >
                          {camp.status.replace('_', ' ')}
                        </span>
                        <button
                          type="button"
                          id={`creator-delete-btn-${camp.id}`}
                          onClick={() => setDeleteModalCampaign(camp)}
                          className="p-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/20 hover:border-rose-500/40 transition-colors"
                          title="Delete this campaign"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {camp.teaser_url && (
                      <div className="bg-purple-950/30 border border-purple-500/30 rounded-xl px-3 py-1.5 flex items-center justify-between text-xs">
                        <span className="text-purple-300 font-medium flex items-center gap-1.5">
                          <Film className="w-3.5 h-3.5 text-purple-400" />
                          <span>15s Teaser Attached</span>
                        </span>
                        <a
                          href={camp.teaser_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-purple-400 hover:underline flex items-center gap-1 font-semibold text-[11px]"
                        >
                          <span>View Clip</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    )}

                    {/* Views & Audience Reach Progress */}
                    <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3 space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-400">Audience Views:</span>
                        <span className="font-semibold text-slate-200">
                          {camp.views_count || 0} / {camp.target_views || 1000} ({percentReached}%)
                        </span>
                      </div>
                      <div className="w-full bg-slate-800 rounded-full h-1.5 overflow-hidden">
                        <div
                          className={`h-full transition-all duration-500 ${
                            isTargetReached ? 'bg-emerald-400' : 'bg-purple-500'
                          }`}
                          style={{ width: `${percentReached}%` }}
                        />
                      </div>
                    </div>

                    <div className="text-xs text-slate-400 space-y-1">
                      <div className="flex justify-between">
                        <span>Escrow Budget:</span>
                        <strong className="text-emerald-400">₹{camp.budget}</strong>
                      </div>
                      <div className="flex justify-between">
                        <span>UTR Number:</span>
                        <span className="font-mono text-slate-300">{camp.utr_number}</span>
                      </div>
                    </div>

                    <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs">
                      <span className="text-[11px] text-slate-500">
                        {new Date(camp.createdAt).toLocaleDateString()}
                      </span>
                      <div className="flex items-center gap-3">
                        <button
                          type="button"
                          onClick={() => setDeleteModalCampaign(camp)}
                          className="text-rose-400 hover:text-rose-300 font-medium text-[11px] flex items-center gap-1"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>Delete</span>
                        </button>
                        <a
                          href={camp.youtube_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-purple-400 hover:underline flex items-center gap-1"
                        >
                          <span>Watch Full Video</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* Creator Delete Confirmation Modal */}
      {deleteModalCampaign && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-rose-500/20 border border-rose-500/30 text-rose-400 flex items-center justify-center shrink-0">
                <Trash2 className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h3 className="text-lg font-bold text-white">Delete Video Campaign?</h3>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30">
                  Creator Authorization
                </span>
              </div>
            </div>

            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-2 text-xs">
              <p className="font-semibold text-slate-200 line-clamp-2">
                {deleteModalCampaign.title || 'Video Campaign'}
              </p>
              <div className="flex items-center gap-3 text-slate-400 text-[11px] pt-1 border-t border-slate-900">
                <span>
                  Views: <strong>{deleteModalCampaign.views_count || 0} / {deleteModalCampaign.target_views || 1000}</strong>
                </span>
                {(deleteModalCampaign.views_count || 0) >= (deleteModalCampaign.target_views || 1000) && (
                  <span className="text-emerald-400 font-semibold">• Target Audience Reached</span>
                )}
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              As the creator of this video, you have the authority to delete your campaign. This will permanently remove the video, attached 15-second teaser, and quiz questions from the platform.
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDeleteModalCampaign(null)}
                disabled={isDeletingCampaign}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                id="confirm-delete-creator-camp-btn"
                onClick={() => handleDeleteCampaign(deleteModalCampaign)}
                disabled={isDeletingCampaign}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-rose-950/50 disabled:opacity-50 transition-colors"
              >
                {isDeletingCampaign ? (
                  <span>Deleting...</span>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Confirm Delete</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
        </>
      )}
    </div>
  );
};
