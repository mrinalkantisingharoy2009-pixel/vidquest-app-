import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  X,
  Mail,
  Lock,
  Smartphone,
  ShieldCheck,
  Sparkles,
  ArrowRight,
  AlertCircle
} from 'lucide-react';
import { SUPER_ADMIN_EMAIL } from '../lib/firebase';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose }) => {
  const {
    signInWithGoogle,
    signInWithEmail,
    signUpWithEmail,
    quickLoginAsAdmin,
    quickLoginAsUser
  } = useAuth();

  const [mode, setMode] = useState<'signin' | 'signup' | 'phone'>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleGoogleSignIn = async () => {
    setError(null);
    setLoading(true);
    try {
      await signInWithGoogle();
      onClose();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Google sign in failed');
    } finally {
      setLoading(false);
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password) {
      setError('Please provide email and password');
      return;
    }
    setError(null);
    setLoading(true);
    try {
      if (mode === 'signup') {
        await signUpWithEmail(email, password);
      } else {
        await signInWithEmail(email, password);
      }
      onClose();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  const handlePhoneSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!otpSent) {
      if (phoneNumber.length < 10) {
        setError('Please enter a valid 10-digit mobile number');
        return;
      }
      setError(null);
      setOtpSent(true);
    } else {
      if (otpCode.length < 4) {
        setError('Please enter the 6-digit OTP');
        return;
      }
      // Phone OTP session login
      setLoading(true);
      quickLoginAsUser(`user_${phoneNumber.slice(-4)}@vidquest.io`)
        .then(() => onClose())
        .catch((err) => setError(err.message))
        .finally(() => setLoading(false));
    }
  };

  const handleQuickAdmin = async () => {
    setError(null);
    setLoading(true);
    try {
      await quickLoginAsAdmin();
      onClose();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Admin login failed');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickUser = async () => {
    setError(null);
    setLoading(true);
    try {
      await quickLoginAsUser();
      onClose();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'User login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div
        id="auth-modal-card"
        className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md p-6 sm:p-8 text-white relative shadow-2xl overflow-hidden"
      >
        {/* Background glow */}
        <div className="absolute -top-24 -right-24 w-48 h-48 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          id="close-auth-modal-btn"
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Title */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 text-xs font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>VidQuest Authentication</span>
          </div>
          <h2 className="text-2xl font-bold tracking-tight text-white">
            {mode === 'signup'
              ? 'Create VidQuest Account'
              : mode === 'phone'
              ? 'Phone / OTP Login'
              : 'Sign In to VidQuest'}
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Access creator campaigns, take quizzes, and manage escrow
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
            <span>{error}</span>
          </div>
        )}

        {/* Primary Google Login Button */}
        <button
          id="google-signin-btn"
          type="button"
          onClick={handleGoogleSignIn}
          disabled={loading}
          className="w-full py-3 px-4 bg-white hover:bg-slate-100 text-slate-900 font-semibold rounded-xl text-sm flex items-center justify-center gap-3 transition-colors shadow-sm disabled:opacity-50"
        >
          <svg className="w-5 h-5" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
            />
            <path
              fill="#34A853"
              d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.36 24 12 24z"
            />
            <path
              fill="#FBBC05"
              d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
            />
            <path
              fill="#EA4335"
              d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.36 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
            />
          </svg>
          <span>Continue with Google OAuth</span>
        </button>

        {/* Mode Tabs */}
        <div className="flex items-center justify-center gap-4 my-4">
          <div className="h-px bg-slate-800 flex-1" />
          <span className="text-xs uppercase text-slate-500 font-mono">or continue with</span>
          <div className="h-px bg-slate-800 flex-1" />
        </div>

        {/* Tab Selector */}
        <div className="grid grid-cols-2 gap-2 p-1 bg-slate-950 rounded-xl mb-4 text-xs font-medium">
          <button
            type="button"
            onClick={() => setMode('signin')}
            className={`py-2 rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
              mode !== 'phone' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Mail className="w-3.5 h-3.5" />
            <span>Email</span>
          </button>
          <button
            type="button"
            onClick={() => setMode('phone')}
            className={`py-2 rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
              mode === 'phone' ? 'bg-slate-800 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Phone OTP</span>
          </button>
        </div>

        {/* Email Form */}
        {mode !== 'phone' ? (
          <form onSubmit={handleEmailAuth} className="space-y-3">
            <div>
              <label className="block text-xs text-slate-400 mb-1">Email Address</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                <input
                  id="auth-email-input"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1">Password</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
                <input
                  id="auth-password-input"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  required
                />
              </div>
            </div>

            <button
              id="auth-submit-btn"
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-white font-medium text-sm rounded-xl transition-all shadow-md flex items-center justify-center gap-2 mt-4 disabled:opacity-50"
            >
              <span>{mode === 'signup' ? 'Create Account' : 'Sign In'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <div className="text-center text-xs text-slate-400 mt-2">
              {mode === 'signin' ? (
                <>
                  Don't have an account?{' '}
                  <button
                    type="button"
                    onClick={() => setMode('signup')}
                    className="text-amber-400 hover:underline"
                  >
                    Sign Up
                  </button>
                </>
              ) : (
                <>
                  Already have an account?{' '}
                  <button
                    type="button"
                    onClick={() => setMode('signin')}
                    className="text-amber-400 hover:underline"
                  >
                    Sign In
                  </button>
                </>
              )}
            </div>
          </form>
        ) : (
          /* Phone OTP Form */
          <form onSubmit={handlePhoneSubmit} className="space-y-3">
            <div>
              <label className="block text-xs text-slate-400 mb-1">Phone Number (+91 India)</label>
              <div className="flex gap-2">
                <span className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-slate-400 flex items-center">
                  +91
                </span>
                <input
                  id="auth-phone-input"
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  placeholder="9876543210"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  required
                />
              </div>
            </div>

            {otpSent && (
              <div>
                <label className="block text-xs text-slate-400 mb-1">6-Digit OTP</label>
                <input
                  id="auth-otp-input"
                  type="text"
                  maxLength={6}
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value)}
                  placeholder="123456"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-sm text-center tracking-widest font-mono text-white placeholder-slate-500 focus:outline-none focus:border-amber-500"
                  required
                />
                <p className="text-[11px] text-emerald-400 mt-1">OTP sent to +91 {phoneNumber} (Demo code: 123456)</p>
              </div>
            )}

            <button
              id="auth-phone-submit-btn"
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-white font-medium text-sm rounded-xl transition-all shadow-md flex items-center justify-center gap-2 mt-4 disabled:opacity-50"
            >
              <span>{otpSent ? 'Verify OTP & Log In' : 'Send One-Time Password'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        )}

        {/* Quick Testing Login section */}
        <div className="mt-6 pt-5 border-t border-slate-800">
          <div className="text-[11px] uppercase tracking-wider text-slate-500 font-mono mb-2 text-center">
            Instant Test Login Presets
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button
              id="quick-admin-login-btn"
              type="button"
              onClick={handleQuickAdmin}
              disabled={loading}
              className="p-2.5 bg-rose-950/40 hover:bg-rose-950/70 border border-rose-500/30 rounded-xl text-xs text-rose-300 flex items-center justify-center gap-1.5 transition-colors disabled:opacity-50"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-rose-400" />
              <span>Super Admin Desk</span>
            </button>

            <button
              id="quick-user-login-btn"
              type="button"
              onClick={handleQuickUser}
              disabled={loading}
              className="p-2.5 bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 rounded-xl text-xs text-slate-300 flex items-center justify-center gap-1.5 transition-colors disabled:opacity-50"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>Creator / User</span>
            </button>
          </div>
          <div className="text-[10px] text-slate-500 text-center mt-2">
            Super Admin Email: <span className="font-mono text-slate-400">{SUPER_ADMIN_EMAIL}</span>
          </div>
        </div>
      </div>
    </div>
  );
};
