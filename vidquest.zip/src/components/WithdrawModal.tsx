import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  X,
  Coins,
  Lock,
  ArrowRight,
  CheckCircle2,
  AlertCircle,
  History,
  Smartphone,
  Play,
  QrCode,
  Upload,
  Trash2,
  Eye,
  CreditCard,
  Sparkles
} from 'lucide-react';
import { Withdrawal, WithdrawalCategory } from '../types';
import { requestWithdrawal, getUserWithdrawals } from '../services/withdrawalService';
import { compressImageFile } from '../lib/imageUtils';

interface WithdrawModalProps {
  isOpen: boolean;
  onClose: () => void;
  openAuthModal: () => void;
}

const OPERATORS = ['Jio', 'Airtel', 'Vi (Vodafone Idea)', 'BSNL'];

export const WithdrawModal: React.FC<WithdrawModalProps> = ({
  isOpen,
  onClose,
  openAuthModal
}) => {
  const { currentUser, userProfile } = useAuth();

  // Tier 40, 50, or 100+
  const [selectedTier, setSelectedTier] = useState<40 | 50 | 100>(40);

  // ₹40 & ₹50 Mobile Recharge fields
  const [simNumber, setSimNumber] = useState('');
  const [simOperator, setSimOperator] = useState('Jio');

  // ₹50 Selection: 'recharge' or 'google_play'
  const [tier50Option, setTier50Option] = useState<'recharge' | 'google_play'>('recharge');
  const [googlePlayEmail, setGooglePlayEmail] = useState('');

  // ₹100+ Custom Amount & UPI fields
  const [customAmount, setCustomAmount] = useState<number>(100);
  const [upiId, setUpiId] = useState('');
  const [qrScreenshot, setQrScreenshot] = useState<string | null>(null);
  const [isCompressingQR, setIsCompressingQR] = useState(false);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [submitting, setSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [history, setHistory] = useState<Withdrawal[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);

  const walletBalance = userProfile?.wallet_balance || 0;
  const escrowLocked = userProfile?.escrow_locked || 0;

  const loadHistory = async () => {
    if (!currentUser) return;
    setLoadingHistory(true);
    try {
      const data = await getUserWithdrawals(currentUser.uid);
      setHistory(data);
    } catch (e) {
      console.error('Error loading withdrawals:', e);
    } finally {
      setLoadingHistory(false);
    }
  };

  useEffect(() => {
    if (isOpen && currentUser) {
      loadHistory();
      setSuccessMsg(null);
      setErrorMsg(null);
      if (currentUser.email && !googlePlayEmail) {
        setGooglePlayEmail(currentUser.email);
      }
    }
  }, [isOpen, currentUser]);

  if (!isOpen) return null;

  // Handle QR screenshot file attachment
  const handleQRFile = async (file: File) => {
    if (!file.type.startsWith('image/')) {
      setErrorMsg('Please select a valid image file (PNG, JPG, WEBP) for your payment QR code.');
      return;
    }

    setIsCompressingQR(true);
    setErrorMsg(null);
    try {
      const compressedDataUrl = await compressImageFile(file, 800, 0.85);
      setQrScreenshot(compressedDataUrl);
    } catch {
      setErrorMsg('Could not process QR screenshot. Please try a different image.');
    } finally {
      setIsCompressingQR(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) {
      openAuthModal();
      return;
    }

    setErrorMsg(null);
    setSuccessMsg(null);

    let payoutAmount = 40;
    let category: WithdrawalCategory = 'recharge';
    let method = 'Mobile Recharge';
    let paymentDetails = '';
    const metadata: {
      category: WithdrawalCategory;
      sim_number?: string;
      sim_operator?: string;
      google_play_email?: string;
      upi_id?: string;
      screenshot_url?: string;
    } = { category: 'recharge' };

    // 1. Tier ₹40: Mobile Recharge
    if (selectedTier === 40) {
      payoutAmount = 40;
      category = 'recharge';
      if (walletBalance < 40) {
        setErrorMsg(`Insufficient balance. You have ₹${walletBalance}, but ₹40 is required for a mobile recharge.`);
        return;
      }
      const cleanPhone = simNumber.replace(/\D/g, '');
      if (cleanPhone.length !== 10) {
        setErrorMsg('Please enter a valid 10-digit Indian SIM number (e.g. 9876543210).');
        return;
      }
      method = `Mobile Recharge (₹40)`;
      paymentDetails = `${cleanPhone} (${simOperator})`;
      metadata.category = 'recharge';
      metadata.sim_number = cleanPhone;
      metadata.sim_operator = simOperator;
    }

    // 2. Tier ₹50: Mobile Recharge or Google Play Redeem Code
    else if (selectedTier === 50) {
      payoutAmount = 50;
      if (walletBalance < 50) {
        setErrorMsg(`Insufficient balance. You have ₹${walletBalance}, but ₹50 is required for this payout.`);
        return;
      }

      if (tier50Option === 'recharge') {
        category = 'recharge';
        const cleanPhone = simNumber.replace(/\D/g, '');
        if (cleanPhone.length !== 10) {
          setErrorMsg('Please enter a valid 10-digit Indian SIM number (e.g. 9876543210).');
          return;
        }
        method = `Mobile Recharge (₹50)`;
        paymentDetails = `${cleanPhone} (${simOperator})`;
        metadata.category = 'recharge';
        metadata.sim_number = cleanPhone;
        metadata.sim_operator = simOperator;
      } else {
        category = 'google_play';
        const target = googlePlayEmail.trim();
        if (!target || (!target.includes('@') && target.length < 10)) {
          setErrorMsg('Please provide a valid email or phone number to receive the Google Play Redeem code.');
          return;
        }
        method = `Google Play Redeem Code (₹50)`;
        paymentDetails = `Delivery to: ${target}`;
        metadata.category = 'google_play';
        metadata.google_play_email = target;
      }
    }

    // 3. Tier ₹100+: Custom amount UPI transfer
    else if (selectedTier === 100) {
      payoutAmount = Number(customAmount);
      category = 'upi';

      if (isNaN(payoutAmount) || payoutAmount < 100) {
        setErrorMsg('Minimum payout amount for UPI transfer is ₹100.');
        return;
      }

      // "If the balance is equal to that amount, then only they can take their amount"
      if (walletBalance < payoutAmount) {
        setErrorMsg(`Insufficient balance. You requested ₹${payoutAmount}, but your current balance is ₹${walletBalance}. You can only take up to your exact balance.`);
        return;
      }

      const trimmedUpi = upiId.trim();
      if (!trimmedUpi && !qrScreenshot) {
        setErrorMsg('Please provide your UPI ID OR attach a screenshot of your personal payment QR code.');
        return;
      }

      if (trimmedUpi && !trimmedUpi.includes('@')) {
        setErrorMsg('Please enter a valid UPI address (e.g. name@okhdfcbank or 9876543210@paytm).');
        return;
      }

      method = `UPI Direct Transfer (₹${payoutAmount})`;
      paymentDetails = trimmedUpi
        ? (qrScreenshot ? `${trimmedUpi} + QR Screenshot Attached` : trimmedUpi)
        : 'Personal UPI QR Screenshot Attached';

      metadata.category = 'upi';
      if (trimmedUpi) metadata.upi_id = trimmedUpi;
      if (qrScreenshot) metadata.screenshot_url = qrScreenshot;
    }

    setSubmitting(true);
    try {
      await requestWithdrawal(
        currentUser.uid,
        currentUser.email || '',
        payoutAmount,
        method,
        paymentDetails,
        metadata
      );

      setSuccessMsg(
        `Payout request for ₹${payoutAmount} submitted successfully! Funds are now securely locked in escrow. The Super Admin will manually review and fulfill it directly without automation.`
      );

      // Reset fields
      setSimNumber('');
      setUpiId('');
      setQrScreenshot(null);
      loadHistory();
    } catch (err: unknown) {
      setErrorMsg(err instanceof Error ? err.message : 'Withdrawal request failed');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-fade-in">
      <div
        id="withdraw-modal-container"
        className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-xl text-white relative shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
      >
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30 shrink-0">
              <CreditCard className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-mono text-amber-400 tracking-wider font-semibold">
                Earnings Payout Desk
              </span>
              <h3 className="font-bold text-base sm:text-lg text-white">Withdraw Coins & Rewards</h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-6">
          {/* Balance Cards */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
              <div className="text-xs text-slate-400 flex items-center gap-1.5 mb-1">
                <Coins className="w-3.5 h-3.5 text-amber-400" />
                <span>Available Balance</span>
              </div>
              <div className="text-2xl font-black text-amber-400 font-mono">
                ₹{walletBalance.toLocaleString('en-IN')}
              </div>
            </div>

            <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800">
              <div className="text-xs text-slate-400 flex items-center gap-1.5 mb-1">
                <Lock className="w-3.5 h-3.5 text-slate-400" />
                <span>Locked in Escrow</span>
              </div>
              <div className="text-2xl font-black text-slate-300 font-mono">
                ₹{escrowLocked.toLocaleString('en-IN')}
              </div>
            </div>
          </div>

          {errorMsg && (
            <div className="p-3.5 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2.5">
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
              <span>{successMsg}</span>
            </div>
          )}

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Tier Selector */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2">
                Choose Payout Option:
              </label>

              <div className="grid grid-cols-3 gap-2.5">
                {/* Tier 1: ₹40 */}
                <button
                  type="button"
                  id="tier-40-btn"
                  onClick={() => setSelectedTier(40)}
                  className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center justify-between ${
                    selectedTier === 40
                      ? 'bg-amber-500/15 border-amber-500 text-white shadow-lg ring-1 ring-amber-500/50'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="text-[10px] font-mono text-slate-500 uppercase flex items-center gap-1">
                    <Smartphone className="w-3 h-3 text-amber-400" />
                    <span>Tier 1</span>
                  </div>
                  <div className="text-lg font-bold text-amber-400 font-mono my-0.5">₹40</div>
                  <div className="text-[10px] text-slate-300 font-medium">SIM Recharge</div>
                  <div className="text-[9px] mt-1">
                    {walletBalance >= 40 ? (
                      <span className="text-emerald-400 font-semibold">Available</span>
                    ) : (
                      <span className="text-rose-400 font-medium">Need ₹{40 - walletBalance}</span>
                    )}
                  </div>
                </button>

                {/* Tier 2: ₹50 */}
                <button
                  type="button"
                  id="tier-50-btn"
                  onClick={() => setSelectedTier(50)}
                  className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center justify-between ${
                    selectedTier === 50
                      ? 'bg-amber-500/15 border-amber-500 text-white shadow-lg ring-1 ring-amber-500/50'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="text-[10px] font-mono text-slate-500 uppercase flex items-center gap-1">
                    <Play className="w-3 h-3 text-emerald-400" />
                    <span>Tier 2</span>
                  </div>
                  <div className="text-lg font-bold text-amber-400 font-mono my-0.5">₹50</div>
                  <div className="text-[10px] text-slate-300 font-medium">Recharge / Play</div>
                  <div className="text-[9px] mt-1">
                    {walletBalance >= 50 ? (
                      <span className="text-emerald-400 font-semibold">Available</span>
                    ) : (
                      <span className="text-rose-400 font-medium">Need ₹{50 - walletBalance}</span>
                    )}
                  </div>
                </button>

                {/* Tier 3: ₹100+ */}
                <button
                  type="button"
                  id="tier-100-btn"
                  onClick={() => setSelectedTier(100)}
                  className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center justify-between ${
                    selectedTier === 100
                      ? 'bg-amber-500/15 border-amber-500 text-white shadow-lg ring-1 ring-amber-500/50'
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                  }`}
                >
                  <div className="text-[10px] font-mono text-slate-500 uppercase flex items-center gap-1">
                    <QrCode className="w-3 h-3 text-cyan-400" />
                    <span>Tier 3</span>
                  </div>
                  <div className="text-lg font-bold text-amber-400 font-mono my-0.5">₹100+</div>
                  <div className="text-[10px] text-slate-300 font-medium">UPI / Custom</div>
                  <div className="text-[9px] mt-1">
                    {walletBalance >= 100 ? (
                      <span className="text-emerald-400 font-semibold">Available</span>
                    ) : (
                      <span className="text-rose-400 font-medium">Need ₹{100 - walletBalance}</span>
                    )}
                  </div>
                </button>
              </div>
            </div>

            {/* TIER 1 (₹40): Mobile SIM Recharge Inputs */}
            {selectedTier === 40 && (
              <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-4 space-y-3.5 animate-in fade-in">
                <div className="flex items-center gap-2 text-xs font-semibold text-amber-300">
                  <Smartphone className="w-4 h-4 text-amber-400" />
                  <span>₹40 Mobile SIM Recharge Details</span>
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">
                    10-Digit Mobile / SIM Number <span className="text-rose-400">*</span>
                  </label>
                  <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl overflow-hidden focus-within:border-amber-500">
                    <span className="px-3 py-2.5 bg-slate-850 text-slate-400 text-xs font-mono border-r border-slate-800">
                      +91
                    </span>
                    <input
                      id="sim-number-input"
                      type="tel"
                      maxLength={10}
                      value={simNumber}
                      onChange={(e) => setSimNumber(e.target.value.replace(/\D/g, ''))}
                      placeholder="e.g. 9876543210"
                      className="w-full bg-transparent px-3 py-2.5 text-sm font-mono text-white placeholder-slate-500 focus:outline-none"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1.5">
                    Select SIM Operator <span className="text-rose-400">*</span>
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {OPERATORS.map((op) => (
                      <button
                        key={op}
                        type="button"
                        onClick={() => setSimOperator(op)}
                        className={`py-2 px-2.5 rounded-xl border text-xs font-semibold text-center transition-all ${
                          simOperator === op
                            ? 'bg-amber-500/20 border-amber-500 text-white'
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                        }`}
                      >
                        {op}
                      </button>
                    ))}
                  </div>
                </div>

                <p className="text-[11px] text-slate-500 leading-relaxed">
                  The Super Admin will directly perform the ₹40 mobile recharge for this SIM number without automated delay.
                </p>
              </div>
            )}

            {/* TIER 2 (₹50): Choice between Mobile Recharge & Google Play Redeem */}
            {selectedTier === 50 && (
              <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-4 space-y-4 animate-in fade-in">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-2">
                    Choose ₹50 Redemption Method:
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      id="tier50-recharge-opt"
                      onClick={() => setTier50Option('recharge')}
                      className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
                        tier50Option === 'recharge'
                          ? 'bg-amber-500/20 border-amber-500 text-amber-300 shadow'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      <Smartphone className="w-3.5 h-3.5" />
                      <span>Mobile Recharge</span>
                    </button>

                    <button
                      type="button"
                      id="tier50-play-opt"
                      onClick={() => setTier50Option('google_play')}
                      className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
                        tier50Option === 'google_play'
                          ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 shadow'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                      }`}
                    >
                      <Play className="w-3.5 h-3.5" />
                      <span>Google Play Code</span>
                    </button>
                  </div>
                </div>

                {tier50Option === 'recharge' ? (
                  <div className="space-y-3 pt-2 border-t border-slate-900">
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">
                        10-Digit Mobile / SIM Number <span className="text-rose-400">*</span>
                      </label>
                      <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl overflow-hidden focus-within:border-amber-500">
                        <span className="px-3 py-2.5 bg-slate-850 text-slate-400 text-xs font-mono border-r border-slate-800">
                          +91
                        </span>
                        <input
                          id="sim-number-input-50"
                          type="tel"
                          maxLength={10}
                          value={simNumber}
                          onChange={(e) => setSimNumber(e.target.value.replace(/\D/g, ''))}
                          placeholder="e.g. 9876543210"
                          className="w-full bg-transparent px-3 py-2.5 text-sm font-mono text-white placeholder-slate-500 focus:outline-none"
                          required
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs text-slate-400 mb-1.5">
                        Select SIM Operator <span className="text-rose-400">*</span>
                      </label>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                        {OPERATORS.map((op) => (
                          <button
                            key={op}
                            type="button"
                            onClick={() => setSimOperator(op)}
                            className={`py-2 px-2.5 rounded-xl border text-xs font-semibold text-center transition-all ${
                              simOperator === op
                                ? 'bg-amber-500/20 border-amber-500 text-white'
                                : 'bg-slate-900 border-slate-800 text-slate-400 hover:border-slate-700'
                            }`}
                          >
                            {op}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-3 pt-2 border-t border-slate-900">
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">
                        Delivery Email or Phone for Google Play Code <span className="text-rose-400">*</span>
                      </label>
                      <input
                        id="google-play-email-input"
                        type="text"
                        value={googlePlayEmail}
                        onChange={(e) => setGooglePlayEmail(e.target.value)}
                        placeholder="yourname@gmail.com or 9876543210"
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5 text-sm font-mono text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
                        required
                      />
                    </div>
                    <p className="text-[11px] text-slate-500 leading-relaxed">
                      Super Admin will directly deliver a ₹50 Google Play redeem gift code to your email or WhatsApp without any automation.
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* TIER 3 (₹100+): Custom Amount & UPI ID or Attached QR Screenshot */}
            {selectedTier === 100 && (
              <div className="bg-slate-950 border border-slate-800/80 rounded-2xl p-4 space-y-4 animate-in fade-in">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-xs font-semibold text-cyan-300">
                    <QrCode className="w-4 h-4 text-cyan-400" />
                    <span>₹100+ Custom Amount UPI Withdrawal</span>
                  </div>
                  <span className="text-[11px] text-slate-400 font-mono">
                    Max: ₹{walletBalance}
                  </span>
                </div>

                {/* Amount input with Max button */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs text-slate-400">
                      Enter Amount (₹100 or above) <span className="text-rose-400">*</span>
                    </label>
                    <button
                      type="button"
                      onClick={() => setCustomAmount(Math.max(100, walletBalance))}
                      className="text-[11px] text-amber-400 hover:underline font-semibold"
                    >
                      Use Max Balance (₹{walletBalance})
                    </button>
                  </div>

                  <div className="flex items-center bg-slate-900 border border-slate-800 rounded-xl overflow-hidden focus-within:border-cyan-500">
                    <span className="px-3.5 py-2.5 bg-slate-850 text-slate-400 text-sm font-bold font-mono border-r border-slate-800">
                      ₹
                    </span>
                    <input
                      id="custom-amount-input"
                      type="number"
                      min={100}
                      max={walletBalance || 100}
                      value={customAmount}
                      onChange={(e) => setCustomAmount(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-full bg-transparent px-3 py-2.5 text-base font-mono font-bold text-white placeholder-slate-500 focus:outline-none"
                      required
                    />
                  </div>

                  {customAmount > walletBalance && (
                    <p className="text-[11px] text-rose-400 mt-1 font-medium">
                      Amount exceeds your available balance of ₹{walletBalance}.
                    </p>
                  )}
                </div>

                {/* Quick Presets */}
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-[11px] text-slate-500">Quick:</span>
                  {[100, 200, 500].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setCustomAmount(preset)}
                      className={`px-3 py-1 rounded-lg text-xs font-mono font-semibold border transition-colors ${
                        customAmount === preset
                          ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      ₹{preset}
                    </button>
                  ))}
                </div>

                {/* Option 1: Enter UPI ID */}
                <div className="pt-2 border-t border-slate-900 space-y-1.5">
                  <label className="block text-xs text-slate-300 font-semibold">
                    1. Enter UPI ID (VPA)
                  </label>
                  <input
                    id="withdraw-upi-input"
                    type="text"
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                    placeholder="e.g. name@okhdfcbank or 9876543210@paytm"
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-4 py-2.5 text-sm font-mono text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                  />
                  <p className="text-[11px] text-slate-500">
                    Super Admin will pay directly to this UPI address from bank account.
                  </p>
                </div>

                {/* Option 2: Attach QR Code Screenshot */}
                <div className="pt-2 border-t border-slate-900 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-xs text-slate-300 font-semibold">
                      2. OR Attach UPI Payment QR Screenshot
                    </label>
                    <span className="text-[10px] text-slate-500 font-mono">PhonePe / GPay / Paytm</span>
                  </div>

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleQRFile(file);
                    }}
                    className="hidden"
                  />

                  {qrScreenshot ? (
                    <div className="bg-slate-900 border border-slate-800 rounded-xl p-3 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <button
                          type="button"
                          onClick={() => setPreviewImage(qrScreenshot)}
                          className="w-14 h-14 rounded-lg bg-black border border-slate-700 overflow-hidden relative group shrink-0"
                          title="Click to view QR preview"
                        >
                          <img
                            src={qrScreenshot}
                            alt="Attached QR Screenshot"
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                          />
                          <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity text-white text-[10px]">
                            <Eye className="w-3.5 h-3.5" />
                          </div>
                        </button>
                        <div>
                          <div className="text-xs font-semibold text-emerald-400 flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Payment QR Attached</span>
                          </div>
                          <div className="text-[10px] text-slate-400 mt-0.5">
                            Super Admin will scan this QR to pay you directly.
                          </div>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          setQrScreenshot(null);
                          if (fileInputRef.current) fileInputRef.current.value = '';
                        }}
                        className="p-2 text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 rounded-lg transition-colors"
                        title="Remove attached QR screenshot"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <button
                      type="button"
                      onClick={() => fileInputRef.current?.click()}
                      disabled={isCompressingQR}
                      className="w-full border-2 border-dashed border-slate-800 hover:border-cyan-500/50 rounded-2xl p-4 text-center bg-slate-900/50 hover:bg-slate-900 transition-all flex flex-col items-center justify-center gap-1.5 group cursor-pointer disabled:opacity-50"
                    >
                      <div className="w-9 h-9 rounded-xl bg-slate-800 group-hover:bg-cyan-500/20 text-slate-400 group-hover:text-cyan-400 flex items-center justify-center transition-colors">
                        <Upload className="w-4 h-4" />
                      </div>
                      <span className="text-xs font-semibold text-slate-300 group-hover:text-white">
                        {isCompressingQR ? 'Processing Screenshot...' : 'Upload UPI QR Code Screenshot'}
                      </span>
                      <span className="text-[10px] text-slate-500">
                        Supports PNG, JPG, or WEBP screenshot from any UPI app
                      </span>
                    </button>
                  )}
                </div>

                <div className="p-3 bg-cyan-950/30 border border-cyan-800/40 rounded-xl text-[11px] text-cyan-300 flex items-start gap-2">
                  <Sparkles className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                  <span>
                    <strong>Manual Direct Payment:</strong> Super Admin will open their banking app and pay you manually via your UPI ID or by scanning your attached QR screenshot. No bot or automated deduction.
                  </span>
                </div>
              </div>
            )}

            {/* Submit Button */}
            <button
              id="submit-withdrawal-btn"
              type="submit"
              disabled={
                submitting ||
                (selectedTier === 40 && walletBalance < 40) ||
                (selectedTier === 50 && walletBalance < 50) ||
                (selectedTier === 100 && (walletBalance < customAmount || customAmount < 100))
              }
              className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-white font-bold text-sm rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 disabled:opacity-40"
            >
              {submitting ? (
                <span>Locking Escrow & Submitting...</span>
              ) : (
                <>
                  <span>
                    Request{' '}
                    {selectedTier === 40
                      ? '₹40 Mobile Recharge'
                      : selectedTier === 50
                      ? `₹50 ${tier50Option === 'recharge' ? 'Recharge' : 'Google Play Code'}`
                      : `₹${customAmount} UPI Transfer`}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* History */}
          <div className="pt-4 border-t border-slate-800 space-y-3">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-400">
              <History className="w-3.5 h-3.5" />
              <span>Your Withdrawal & Redemption History</span>
            </div>

            {loadingHistory ? (
              <div className="text-xs text-slate-500 text-center py-4">Loading history...</div>
            ) : history.length === 0 ? (
              <div className="text-xs text-slate-500 text-center py-3 bg-slate-950 rounded-xl border border-slate-800">
                No past withdrawals. Complete quizzes to earn coins!
              </div>
            ) : (
              <div className="space-y-2">
                {history.map((w) => (
                  <div
                    key={w.id}
                    className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 flex items-center justify-between text-xs gap-3"
                  >
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-amber-400 font-mono text-sm">
                          ₹{w.amount}
                        </span>
                        <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-md bg-slate-900 text-slate-300 border border-slate-800">
                          {w.method}
                        </span>
                        <span
                          className={`text-[10px] font-mono px-2 py-0.5 rounded-full font-bold uppercase ${
                            w.status === 'paid'
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                              : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          }`}
                        >
                          {w.status === 'paid' ? 'Paid by Admin' : 'Pending in Escrow'}
                        </span>
                      </div>
                      <div className="text-slate-400 text-[11px] truncate max-w-xs">
                        {w.payment_details}
                      </div>
                      <div className="text-[10px] text-slate-500">
                        Requested: {new Date(w.createdAt).toLocaleDateString()}
                      </div>
                    </div>

                    {w.screenshot_url && (
                      <button
                        type="button"
                        onClick={() => setPreviewImage(w.screenshot_url || null)}
                        className="shrink-0 p-1.5 bg-slate-900 border border-slate-800 rounded-lg text-slate-400 hover:text-white flex items-center gap-1 text-[10px]"
                        title="View uploaded QR screenshot"
                      >
                        <Eye className="w-3.5 h-3.5 text-cyan-400" />
                        <span>QR</span>
                      </button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Lightbox Modal for QR Code Screenshot preview */}
      {previewImage && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fade-in">
          <div className="relative max-w-md w-full bg-slate-900 border border-slate-800 rounded-3xl p-5 overflow-hidden">
            <button
              onClick={() => setPreviewImage(null)}
              className="absolute top-4 right-4 p-2 bg-slate-800 rounded-full text-slate-300 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="text-xs text-slate-400 font-mono mb-3">
              UPI Payment QR Screenshot
            </div>
            <img
              src={previewImage}
              alt="UPI QR Code"
              className="w-full max-h-[70vh] object-contain rounded-2xl bg-black border border-slate-800"
            />
          </div>
        </div>
      )}
    </div>
  );
};
