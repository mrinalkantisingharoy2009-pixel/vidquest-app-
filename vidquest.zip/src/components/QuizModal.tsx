import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  X,
  CheckCircle2,
  XCircle,
  Coins,
  Award,
  ChevronRight,
  ChevronLeft,
  AlertCircle,
  HelpCircle,
  Sparkles
} from 'lucide-react';
import { Campaign, QuizQuestion } from '../types';
import { evaluateAndCreditQuiz, getQuizForCampaign, QuizEvaluationResult } from '../services/quizService';
import { SUPER_ADMIN_EMAIL } from '../lib/firebase';

interface QuizModalProps {
  campaign: Campaign | null;
  isOpen: boolean;
  onClose: () => void;
  onQuizCompleted: () => void;
}

export const QuizModal: React.FC<QuizModalProps> = ({
  campaign,
  isOpen,
  onClose,
  onQuizCompleted
}) => {
  const { currentUser, userProfile } = useAuth();
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([-1, -1, -1, -1, -1]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [result, setResult] = useState<QuizEvaluationResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen || !campaign) return null;

  const videoId = campaign.video_id || 'sample_vid';
  const questions: QuizQuestion[] = getQuizForCampaign(videoId, campaign.custom_questions);
  const isAlreadyCompleted = userProfile?.completed_quizzes?.includes(videoId);
  const isTest = Boolean(
    campaign.is_test ||
    (campaign.creator_email && campaign.creator_email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase()) ||
    campaign.utr_number === 'SUPER_ADMIN_TEST_BYPASS' ||
    (campaign.reward_coins === 0 && campaign.budget === 0)
  );

  const handleSelectOption = (optionIndex: number) => {
    if (result) return;
    const newAnswers = [...selectedAnswers];
    newAnswers[currentQuestionIndex] = optionIndex;
    setSelectedAnswers(newAnswers);
  };

  const handleNext = () => {
    if (currentQuestionIndex < 4) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  const handlePrev = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  const handleSubmitQuiz = async () => {
    if (!currentUser) {
      setError('Please log in to submit your quiz');
      return;
    }

    if (selectedAnswers.includes(-1)) {
      setError('Please answer all 5 questions before submitting');
      return;
    }

    setError(null);
    setIsSubmitting(true);

    try {
      const evaluation = await evaluateAndCreditQuiz(
        currentUser.uid,
        videoId,
        selectedAnswers,
        questions,
        isTest ? 0 : (campaign.reward_coins || 50)
      );

      if (evaluation) {
        setResult(evaluation);
        if (evaluation.passed) {
          onQuizCompleted();
        }
      }
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Evaluation failed');
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetQuiz = () => {
    setSelectedAnswers([-1, -1, -1, -1, -1]);
    setCurrentQuestionIndex(0);
    setResult(null);
    setError(null);
  };

  const currentQ = questions[currentQuestionIndex];
  const allAnswered = !selectedAnswers.includes(-1);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-fade-in">
      <div
        id="quiz-modal-container"
        className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-xl text-white relative shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-950/40">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center border border-amber-500/30">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs uppercase font-mono text-amber-400 tracking-wider">
                  {isTest ? 'Test Practice Quiz' : 'Campaign Quiz Verification'}
                </span>
                {isTest ? (
                  <span className="text-xs px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                    🧪 Only for Test Purposes (₹0)
                  </span>
                ) : (
                  <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-semibold">
                    +₹{campaign.reward_coins || 50} Coins
                  </span>
                )}
              </div>
              <h3 className="font-bold text-base text-slate-100 truncate max-w-[280px] sm:max-w-md">
                {campaign.title || 'Video Content Evaluation'}
              </h3>
            </div>
          </div>

          <button
            id="close-quiz-btn"
            onClick={onClose}
            className="p-2 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Test Notice Banner */}
          {isTest && (
            <div className="p-3.5 rounded-2xl bg-amber-950/40 border border-amber-500/30 flex items-start gap-2.5 text-amber-200 text-xs">
              <Sparkles className="w-4 h-4 shrink-0 text-amber-400 mt-0.5" />
              <div>
                <span className="font-bold text-amber-300">Only for Test Purposes:</span> This video feed is provided strictly for testing. No money or coins will be given in that.
              </div>
            </div>
          )}

          {/* Already completed banner */}
          {isAlreadyCompleted && !result && (
            <div className="p-4 rounded-2xl bg-slate-800 border border-slate-700 flex items-center gap-3 text-slate-300 text-sm">
              <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-400" />
              <div>
                <p className="font-semibold text-white">
                  {isTest ? 'Test Quiz Already Completed' : 'Reward Already Claimed'}
                </p>
                <p className="text-xs text-slate-400">
                  {isTest
                    ? 'You have already completed this practice quiz (test mode — no money awarded).'
                    : `You have already passed this video's quiz and claimed your ₹${campaign.reward_coins || 50} coins.`}
                </p>
              </div>
            </div>
          )}

          {error && (
            <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{error}</span>
            </div>
          )}

          {/* Result Screen */}
          {result ? (
            <div className="py-8 text-center space-y-4">
              <div className="inline-flex p-4 rounded-3xl bg-slate-800 border border-slate-700 shadow-xl">
                {result.passed ? (
                  <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                    <CheckCircle2 className="w-10 h-10" />
                  </div>
                ) : (
                  <div className="w-16 h-16 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center">
                    <XCircle className="w-10 h-10" />
                  </div>
                )}
              </div>

              <div>
                <div className="text-3xl font-extrabold text-white">
                  Score: {result.score} / {result.totalQuestions}
                </div>
                <div className="text-sm font-semibold mt-1">
                  {result.passed ? (
                    <span className="text-emerald-400 flex items-center justify-center gap-1.5">
                      <Sparkles className="w-4 h-4" />
                      Passed! Target Score ≥ 4 Met
                    </span>
                  ) : (
                    <span className="text-rose-400">Score below required threshold (4/5)</span>
                  )}
                </div>
                <p className="text-xs text-slate-400 max-w-sm mx-auto mt-2">{result.message}</p>
              </div>

              {result.passed ? (
                isTest ? (
                  <div className="bg-slate-800 border border-amber-500/30 rounded-2xl p-4 max-w-xs mx-auto text-amber-300 flex items-center justify-center gap-3">
                    <Sparkles className="w-6 h-6 text-amber-400" />
                    <div className="text-left">
                      <div className="text-xs text-amber-400/80">Evaluation Mode</div>
                      <div className="text-base font-bold text-white">₹0 Coins (Test Mode)</div>
                    </div>
                  </div>
                ) : (
                  <div className="bg-amber-500/10 border border-amber-500/30 rounded-2xl p-4 max-w-xs mx-auto text-amber-300 flex items-center justify-center gap-3">
                    <Coins className="w-6 h-6 text-amber-400" />
                    <div className="text-left">
                      <div className="text-xs text-amber-400/80">Credited to Balance</div>
                      <div className="text-lg font-bold text-white">+₹{result.coinsAwarded} Coins</div>
                    </div>
                  </div>
                )
              ) : (
                <button
                  type="button"
                  onClick={resetQuiz}
                  className="px-6 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-medium text-xs rounded-xl transition-colors"
                >
                  Try Again
                </button>
              )}
            </div>
          ) : (
            /* Active Quiz Interface */
            <div className="space-y-6">
              {/* Stepper bar */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  {questions.map((_, idx) => (
                    <button
                      key={idx}
                      onClick={() => setCurrentQuestionIndex(idx)}
                      className={`w-8 h-8 rounded-lg text-xs font-bold transition-all flex items-center justify-center ${
                        currentQuestionIndex === idx
                          ? 'bg-amber-500 text-slate-950 scale-105 shadow-md shadow-amber-500/20'
                          : selectedAnswers[idx] !== -1
                          ? 'bg-slate-800 text-emerald-400 border border-emerald-500/40'
                          : 'bg-slate-950 text-slate-500 border border-slate-800'
                      }`}
                    >
                      {idx + 1}
                    </button>
                  ))}
                </div>
                <div className="text-xs text-slate-400 font-mono">
                  Question {currentQuestionIndex + 1} of 5
                </div>
              </div>

              {/* Question Card */}
              <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-5 space-y-4">
                <div className="flex items-start gap-2.5">
                  <span className="p-1 rounded-md bg-amber-500/10 text-amber-400 mt-0.5">
                    <HelpCircle className="w-4 h-4" />
                  </span>
                  <h4 className="text-sm sm:text-base font-semibold text-slate-100 leading-snug">
                    {currentQ.question}
                  </h4>
                </div>

                {/* Options */}
                <div className="space-y-2.5 pt-2">
                  {currentQ.options.map((option, optIdx) => {
                    const isSelected = selectedAnswers[currentQuestionIndex] === optIdx;
                    return (
                      <button
                        key={optIdx}
                        type="button"
                        onClick={() => handleSelectOption(optIdx)}
                        className={`w-full p-3.5 rounded-xl border text-left text-xs sm:text-sm transition-all flex items-center justify-between ${
                          isSelected
                            ? 'bg-amber-500/15 border-amber-500 text-white font-medium shadow-sm'
                            : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:bg-slate-800/80 hover:border-slate-700'
                        }`}
                      >
                        <div className="flex items-center gap-3">
                          <span
                            className={`w-6 h-6 rounded-lg text-xs font-mono flex items-center justify-center border ${
                              isSelected
                                ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold'
                                : 'bg-slate-800 border-slate-700 text-slate-400'
                            }`}
                          >
                            {String.fromCharCode(65 + optIdx)}
                          </span>
                          <span>{option}</span>
                        </div>
                        {isSelected && <CheckCircle2 className="w-4 h-4 text-amber-400 shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Navigation controls */}
              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={handlePrev}
                  disabled={currentQuestionIndex === 0}
                  className="px-4 py-2 rounded-xl text-xs font-medium text-slate-300 bg-slate-800 hover:bg-slate-700 disabled:opacity-30 disabled:pointer-events-none flex items-center gap-1.5 transition-colors"
                >
                  <ChevronLeft className="w-4 h-4" />
                  <span>Previous</span>
                </button>

                {currentQuestionIndex < 4 ? (
                  <button
                    type="button"
                    onClick={handleNext}
                    className="px-4 py-2 rounded-xl text-xs font-medium text-white bg-slate-800 hover:bg-slate-700 flex items-center gap-1.5 transition-colors"
                  >
                    <span>Next Question</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                ) : (
                  <button
                    id="submit-quiz-answers-btn"
                    type="button"
                    onClick={handleSubmitQuiz}
                    disabled={isSubmitting || !allAnswered || Boolean(isAlreadyCompleted)}
                    className="px-6 py-2.5 rounded-xl text-xs font-semibold text-slate-950 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 transition-all shadow-lg shadow-amber-500/20 disabled:opacity-40 disabled:pointer-events-none flex items-center gap-2"
                  >
                    {isSubmitting ? (
                      <span>Evaluating Server Score...</span>
                    ) : (
                      <>
                        <span>Submit for Atomic Verification</span>
                        <Award className="w-4 h-4" />
                      </>
                    )}
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
