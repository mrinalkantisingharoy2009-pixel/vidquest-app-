import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Copy,
  Check,
  ExternalLink,
  Eye,
  X,
  CreditCard,
  Video,
  Users,
  Clock,
  Sparkles,
  QrCode,
  Upload,
  Save,
  AlertCircle,
  Image as ImageIcon,
  RefreshCw,
  Trash2,
  Film,
  Smartphone,
  Play,
  PlayCircle,
  Bell,
  HelpCircle,
  ChevronDown,
  ChevronUp,
  Bot,
  FileQuestion,
  Briefcase
} from 'lucide-react';
import { SUPER_ADMIN_EMAIL } from '../lib/firebase';
import { AdminFreelanceDesk } from './AdminFreelanceDesk';
import { deleteCampaign } from '../services/campaignService';
import {
  getAllCreatorApplications,
  approveCreatorApplication,
  rejectCreatorApplication,
  getAllCampaigns,
  setCampaignActive,
  acceptCampaign,
  rejectCampaign,
  getAllWithdrawals,
  markWithdrawalPaid,
  deleteWithdrawal,
  getEscrowSettings,
  saveEscrowSettings,
  DEFAULT_ESCROW_SETTINGS
} from '../services/adminService';
import { CreatorApplication, Campaign, Withdrawal, EscrowSettings } from '../types';

/**
 * Resizes and compresses an uploaded image to prevent Firestore 1MB document limit issues
 * while keeping QR codes crisp and scan-ready.
 */
function compressImageFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_DIM = 700;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_DIM) {
            height = Math.round((height * MAX_DIM) / width);
            width = MAX_DIM;
          }
        } else {
          if (height > MAX_DIM) {
            width = Math.round((width * MAX_DIM) / height);
            height = MAX_DIM;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(e.target?.result as string);
          return;
        }

        // Draw with high quality
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, width, height);
        ctx.drawImage(img, 0, 0, width, height);

        // Export as JPEG at 88% quality (typically ~40KB - 80KB)
        const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.88);
        resolve(compressedDataUrl);
      };
      img.onerror = () => reject(new Error('Failed to parse image file'));
      img.src = e.target?.result as string;
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}

export const AdminDashboard: React.FC = () => {
  const { currentUser, isSuperAdmin } = useAuth();

  const [activeTab, setActiveTab] = useState<'creators' | 'campaigns' | 'freelance' | 'payouts' | 'escrow_settings'>('creators');
  const [loading, setLoading] = useState(true);
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);

  // Data states
  const [applications, setApplications] = useState<CreatorApplication[]>([]);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);

  // Escrow & UPI QR Settings state
  const [escrowSettings, setEscrowSettings] = useState<EscrowSettings>(DEFAULT_ESCROW_SETTINGS);
  const [savingSettings, setSavingSettings] = useState(false);
  const [settingsSuccess, setSettingsSuccess] = useState<string | null>(null);
  const [settingsError, setSettingsError] = useState<string | null>(null);

  // File upload state for Top Direct QR Uploader
  const [stagedQRImage, setStagedQRImage] = useState<string | null>(null);
  const [stagedFileName, setStagedFileName] = useState<string | null>(null);
  const [isUploadingQR, setIsUploadingQR] = useState(false);
  const topFileInputRef = useRef<HTMLInputElement>(null);

  // Receipt Lightbox
  const [previewImage, setPreviewImage] = useState<string | null>(null);

  // Copied feedback
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Super Admin Delete Campaign State
  const [deleteModalCampaign, setDeleteModalCampaign] = useState<Campaign | null>(null);
  const [isDeletingCampaign, setIsDeletingCampaign] = useState(false);
  const [adminDeleteToast, setAdminDeleteToast] = useState<string | null>(null);

  // Video Acceptance & Filter State
  const [campaignFilter, setCampaignFilter] = useState<'all' | 'pending' | 'accepted' | 'rejected'>('all');
  const [inspectQuizCampaignId, setInspectQuizCampaignId] = useState<string | null>(null);
  const [campaignActionToast, setCampaignActionToast] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const loadAllData = async () => {
    setLoading(true);
    try {
      const [apps, camps, wths, settings] = await Promise.all([
        getAllCreatorApplications(),
        getAllCampaigns(),
        getAllWithdrawals(),
        getEscrowSettings()
      ]);
      setApplications(apps);
      setCampaigns(camps);
      setWithdrawals(wths);
      setEscrowSettings(settings);
    } catch (e) {
      console.error('Error fetching admin data:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isSuperAdmin) {
      loadAllData();
    }
  }, [isSuperAdmin]);

  // Tab 1 Actions: Creator Approvals
  const handleApproveCreator = async (app: CreatorApplication) => {
    if (!app.id) return;
    setActionLoadingId(app.id);
    try {
      await approveCreatorApplication(app.id, app.uid);
      await loadAllData();
    } catch (e) {
      alert('Error approving creator: ' + (e instanceof Error ? e.message : String(e)));
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleRejectCreator = async (app: CreatorApplication) => {
    if (!app.id) return;
    setActionLoadingId(app.id);
    try {
      await rejectCreatorApplication(app.id, app.uid);
      await loadAllData();
    } catch (e) {
      alert('Error rejecting creator: ' + (e instanceof Error ? e.message : String(e)));
    } finally {
      setActionLoadingId(null);
    }
  };

  // Tab 2 Actions: Campaign Acceptance & Verification
  const handleAcceptVideoCampaign = async (campaignId: string) => {
    setActionLoadingId(campaignId);
    try {
      await acceptCampaign(campaignId);
      setCampaignActionToast('Video campaign accepted! It is now live and streaming on the user feed.');
      setTimeout(() => setCampaignActionToast(null), 5000);
      await loadAllData();
    } catch (e) {
      alert('Error accepting video campaign: ' + (e instanceof Error ? e.message : String(e)));
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleRejectVideoCampaign = async (campaignId: string) => {
    if (!window.confirm('Super Admin: Are you sure you want to reject this campaign? It will be blocked from the user feed.')) {
      return;
    }
    setActionLoadingId(campaignId);
    try {
      await rejectCampaign(campaignId);
      setCampaignActionToast('Campaign rejected. This video is blocked from appearing on the user feed.');
      setTimeout(() => setCampaignActionToast(null), 5000);
      await loadAllData();
    } catch (e) {
      alert('Error rejecting video campaign: ' + (e instanceof Error ? e.message : String(e)));
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleSetActiveCampaign = async (campaignId: string) => {
    await handleAcceptVideoCampaign(campaignId);
  };

  const handleDeleteCampaign = async (campaign: Campaign) => {
    if (!campaign.id) return;
    setIsDeletingCampaign(true);
    try {
      await deleteCampaign(campaign.id);
      setDeleteModalCampaign(null);
      setAdminDeleteToast(`Campaign "${campaign.title || 'Campaign'}" deleted permanently.`);
      setTimeout(() => setAdminDeleteToast(null), 4000);
      await loadAllData();
    } catch (e) {
      alert('Error deleting campaign: ' + (e instanceof Error ? e.message : String(e)));
    } finally {
      setIsDeletingCampaign(false);
    }
  };

  // Tab 3 Actions: Payout Fulfillment
  const handleMarkPaid = async (withdrawal: Withdrawal) => {
    if (!withdrawal.id) return;
    setActionLoadingId(withdrawal.id);
    try {
      await markWithdrawalPaid(withdrawal.id, withdrawal.uid, withdrawal.amount);
      await loadAllData();
    } catch (e) {
      alert('Error marking payout as paid: ' + (e instanceof Error ? e.message : String(e)));
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleDeleteWithdrawal = async (wthId: string) => {
    if (!window.confirm('Super Admin: Are you sure you want to permanently delete this withdrawal record?')) {
      return;
    }
    setActionLoadingId(wthId);
    try {
      await deleteWithdrawal(wthId);
      setWithdrawals((prev) => prev.filter((w) => w.id !== wthId));
    } catch (err: unknown) {
      alert('Failed to delete withdrawal: ' + (err instanceof Error ? err.message : String(err)));
    } finally {
      setActionLoadingId(null);
    }
  };

  // Direct QR File Selection handler (used both in the Top Banner and in Tab 4)
  const handleFileSelect = async (file: File) => {
    if (!file.type.startsWith('image/')) {
      setSettingsError('Please select a valid image file (PNG, JPG, or WEBP)');
      return;
    }

    setIsUploadingQR(true);
    setSettingsError(null);
    try {
      const compressedDataUrl = await compressImageFile(file);
      setStagedQRImage(compressedDataUrl);
      setStagedFileName(file.name);
      setEscrowSettings((prev) => ({
        ...prev,
        qr_image_url: compressedDataUrl
      }));
    } catch (err) {
      setSettingsError('Could not process image. Please try a different screenshot.');
    } finally {
      setIsUploadingQR(false);
    }
  };

  // Quick Save for Top QR Attacher
  const handleQuickSaveQR = async () => {
    if (!currentUser) return;
    setSavingSettings(true);
    setSettingsError(null);
    setSettingsSuccess(null);

    try {
      const updatedSettings = {
        ...escrowSettings,
        qr_image_url: stagedQRImage || escrowSettings.qr_image_url
      };
      await saveEscrowSettings(updatedSettings, currentUser.email || SUPER_ADMIN_EMAIL);
      setEscrowSettings(updatedSettings);
      setStagedQRImage(null);
      setStagedFileName(null);
      setSettingsSuccess('QR Code successfully attached and published to all creator checkouts!');
      setTimeout(() => setSettingsSuccess(null), 5000);
    } catch (err: unknown) {
      setSettingsError(err instanceof Error ? err.message : 'Failed to save QR code');
    } finally {
      setSavingSettings(false);
    }
  };

  // Remove QR Code
  const handleRemoveQR = async () => {
    if (!window.confirm('Are you sure you want to remove the custom QR screenshot and revert to the default system QR?')) {
      return;
    }
    if (!currentUser) return;

    setSavingSettings(true);
    try {
      const updatedSettings = {
        ...escrowSettings,
        qr_image_url: ''
      };
      await saveEscrowSettings(updatedSettings, currentUser.email || SUPER_ADMIN_EMAIL);
      setEscrowSettings(updatedSettings);
      setStagedQRImage(null);
      setStagedFileName(null);
      setSettingsSuccess('Custom QR screenshot removed. Reverted to default system QR.');
      setTimeout(() => setSettingsSuccess(null), 4000);
    } catch (err: unknown) {
      setSettingsError(err instanceof Error ? err.message : 'Failed to remove QR code');
    } finally {
      setSavingSettings(false);
    }
  };

  // Full Form Save in Tab 4
  const handleSaveEscrowSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    setSavingSettings(true);
    setSettingsError(null);
    setSettingsSuccess(null);

    try {
      await saveEscrowSettings(escrowSettings, currentUser.email || SUPER_ADMIN_EMAIL);
      setSettingsSuccess('Escrow UPI QR code and payment numbers updated successfully!');
      setTimeout(() => setSettingsSuccess(null), 4000);
    } catch (err: unknown) {
      setSettingsError(err instanceof Error ? err.message : 'Failed to save escrow settings');
    } finally {
      setSavingSettings(false);
    }
  };

  // Strict Super Admin Access Lock
  if (!isSuperAdmin) {
    return (
      <div className="max-w-xl mx-auto px-4 py-20 text-center">
        <div className="w-16 h-16 rounded-3xl bg-rose-500/10 text-rose-400 flex items-center justify-center mx-auto mb-4 border border-rose-500/30">
          <ShieldAlert className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-bold text-white mb-2">Access Denied: Super Admin Only</h2>
        <p className="text-sm text-slate-400 mb-6 leading-relaxed">
          The <span className="font-mono text-rose-400">/admin</span> dashboard is strictly restricted to the hardcoded Super Admin email address:{' '}
          <strong className="text-white font-mono">{SUPER_ADMIN_EMAIL}</strong>.
        </p>
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-xs text-slate-400">
          Current logged in account:{' '}
          <span className="text-slate-200 font-mono">{currentUser?.email || 'Not Authenticated'}</span>
        </div>
      </div>
    );
  }

  const pendingCreators = applications.filter((a) => a.status === 'pending');
  const pendingCampaigns = campaigns.filter((c) => c.status === 'pending_verification' || !c.super_admin_accepted);
  const acceptedCampaigns = campaigns.filter((c) => c.super_admin_accepted && c.status === 'active');
  const rejectedCampaigns = campaigns.filter((c) => c.status === 'rejected');
  const pendingPayouts = withdrawals.filter((w) => w.status === 'pending');

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      {/* Super Admin Top Header */}
      <div className="bg-rose-950/20 border border-rose-500/30 p-6 rounded-3xl backdrop-blur-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-rose-500/20 text-rose-400 flex items-center justify-center border border-rose-500/40">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase font-mono text-rose-400 tracking-wider font-semibold">
                Super Admin Desk
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-mono">
                Hardcoded Lock Active
              </span>
            </div>
            <h1 className="text-2xl font-bold text-white tracking-tight">
              Escrow Operations & Verifications
            </h1>
            <p className="text-xs text-slate-400 font-mono mt-0.5">{SUPER_ADMIN_EMAIL}</p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start md:self-auto">
          <button
            onClick={() => setActiveTab('escrow_settings')}
            className="px-4 py-2 bg-sky-600/20 hover:bg-sky-600/30 border border-sky-500/40 text-sky-300 text-xs font-semibold rounded-xl transition-colors flex items-center gap-1.5"
          >
            <QrCode className="w-3.5 h-3.5" />
            <span>Manage UPI QR</span>
          </button>

          <button
            onClick={loadAllData}
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 text-xs font-semibold rounded-xl transition-colors flex items-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Refresh</span>
          </button>
        </div>
      </div>

      {/* Global Success Banner */}
      {settingsSuccess && (
        <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-sm flex items-center gap-3 shadow-lg animate-fade-in">
          <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-400" />
          <span className="font-medium">{settingsSuccess}</span>
        </div>
      )}

      {/* Global Error Banner */}
      {settingsError && (
        <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-sm flex items-center gap-3 shadow-lg animate-fade-in">
          <AlertCircle className="w-5 h-5 shrink-0 text-rose-400" />
          <span className="font-medium">{settingsError}</span>
        </div>
      )}

      {/* High-Priority Super Admin Notification: New Videos Awaiting Acceptance */}
      {pendingCampaigns.length > 0 && (
        <div
          id="new-video-pending-notification"
          className="p-5 sm:p-6 rounded-3xl bg-gradient-to-r from-amber-950/80 via-slate-900 to-amber-950/80 border-2 border-amber-500/50 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-4 animate-fade-in relative overflow-hidden"
        >
          <div className="flex items-start sm:items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0 border border-amber-500/40 animate-pulse">
              <Bell className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-slate-950 uppercase tracking-wider">
                  Action Required
                </span>
                <span className="text-xs text-amber-300 font-mono">Feed Gatekeeper Active</span>
              </div>
              <h3 className="text-base sm:text-lg font-bold text-white mt-1">
                {pendingCampaigns.length} New Video Campaign{pendingCampaigns.length > 1 ? 's' : ''} Awaiting Acceptance
              </h3>
              <p className="text-xs text-slate-300 max-w-2xl mt-0.5 leading-relaxed">
                Creators have submitted new videos with escrow payments. As requested, these videos are <strong className="text-rose-400">completely blocked</strong> from the public user feed until you inspect them and click <strong className="text-emerald-400 font-bold">'Accept Video'</strong>.
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => {
              setActiveTab('campaigns');
              setCampaignFilter('pending');
            }}
            className="px-5 py-3 bg-gradient-to-r from-amber-500 via-amber-400 to-amber-500 hover:from-amber-400 hover:to-amber-300 text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-amber-950/50 flex items-center justify-center gap-2 shrink-0 transition-transform active:scale-95"
          >
            <span>Review & Accept Videos ({pendingCampaigns.length})</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* ========================================================================= */}
      {/* PROMINENT DIRECT QR ATTACHMENT CARD (Always Visible at Top of Admin Desk) */}
      {/* ========================================================================= */}
      <div
        id="super-admin-qr-attach-box"
        className="bg-gradient-to-br from-slate-900 via-slate-900 to-sky-950/40 border-2 border-sky-500/40 rounded-3xl p-6 sm:p-7 shadow-2xl relative overflow-hidden"
      >
        <div className="absolute top-0 right-0 w-80 h-80 bg-sky-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6">
          {/* Left: Info & Description */}
          <div className="space-y-2 max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/20 text-sky-300 text-xs font-bold border border-sky-500/30">
              <Upload className="w-3.5 h-3.5 text-sky-400" />
              <span>Attach Super Admin UPI QR Code</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Attach Official UPI QR Screenshot File
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Attach the screenshot file of your GPay, PhonePe, Paytm, or BHIM QR code here.
              As soon as you attach and save, this exact QR code will immediately be displayed to creators on their campaign checkout screen!
            </p>

            <div className="flex flex-wrap items-center gap-4 pt-1 text-xs text-slate-400 font-mono">
              <span className="flex items-center gap-1.5 text-slate-300">
                <span className="text-slate-500">UPI ID:</span>
                <strong className="text-emerald-400 font-semibold">{escrowSettings.upi_id}</strong>
              </span>
              <span className="flex items-center gap-1.5 text-slate-300">
                <span className="text-slate-500">Payee:</span>
                <strong className="text-slate-200">{escrowSettings.payee_name}</strong>
              </span>
            </div>
          </div>

          {/* Center / Right: Attached QR Preview & Instant Upload Box */}
          <div className="flex flex-col sm:flex-row items-center gap-5 bg-slate-950/80 p-4 sm:p-5 rounded-2xl border border-slate-800 shrink-0">
            {/* Display Currently Live or Staged QR Image */}
            <div className="relative group shrink-0">
              <div className="w-32 h-32 sm:w-36 sm:h-36 bg-white rounded-xl p-2.5 flex items-center justify-center border-2 border-slate-700 shadow-inner overflow-hidden">
                {stagedQRImage ? (
                  <img
                    src={stagedQRImage}
                    alt="Newly Attached QR Preview"
                    className="w-full h-full object-contain"
                  />
                ) : escrowSettings.qr_image_url ? (
                  <img
                    src={escrowSettings.qr_image_url}
                    alt="Current Live QR Code"
                    className="w-full h-full object-contain"
                  />
                ) : (
                  <div className="text-center p-2">
                    <QrCode className="w-12 h-12 mx-auto text-slate-400 mb-1" />
                    <span className="text-[10px] text-slate-500 font-semibold block leading-tight">
                      Default SVG QR
                    </span>
                    <span className="text-[9px] text-slate-400">
                      (No custom file)
                    </span>
                  </div>
                )}
              </div>

              {/* Status Label on image */}
              <div className="text-center mt-1.5">
                {stagedQRImage ? (
                  <span className="text-[10px] font-bold text-amber-400 font-mono bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
                    Staged (Click Save)
                  </span>
                ) : escrowSettings.qr_image_url ? (
                  <span className="text-[10px] font-bold text-emerald-400 font-mono bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    Live On Checkouts
                  </span>
                ) : (
                  <span className="text-[10px] text-slate-400 font-mono">
                    System Default
                  </span>
                )}
              </div>
            </div>

            {/* Upload Buttons & Actions */}
            <div className="space-y-3 w-full sm:w-56 text-center sm:text-left">
              {/* Hidden File Input */}
              <input
                ref={topFileInputRef}
                type="file"
                accept="image/*"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) handleFileSelect(file);
                }}
                className="hidden"
                id="top-qr-file-input"
              />

              {/* Attach File Button */}
              <button
                type="button"
                id="choose-qr-file-btn"
                onClick={() => topFileInputRef.current?.click()}
                disabled={isUploadingQR}
                className="w-full py-2.5 px-4 bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs rounded-xl shadow transition-colors flex items-center justify-center gap-2 disabled:opacity-50"
              >
                <Upload className="w-4 h-4" />
                <span>
                  {stagedQRImage ? 'Change Selected File' : 'Attach QR Screenshot File'}
                </span>
              </button>

              {/* Save Button (when staged) */}
              {stagedQRImage && (
                <button
                  type="button"
                  id="save-attached-qr-btn"
                  onClick={handleQuickSaveQR}
                  disabled={savingSettings}
                  className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 animate-bounce-short disabled:opacity-50"
                >
                  <Save className="w-4 h-4" />
                  <span>{savingSettings ? 'Saving...' : 'Save & Publish QR Now'}</span>
                </button>
              )}

              {/* Remove QR button (if currently set) */}
              {escrowSettings.qr_image_url && !stagedQRImage && (
                <button
                  type="button"
                  id="remove-qr-btn"
                  onClick={handleRemoveQR}
                  disabled={savingSettings}
                  className="w-full py-2 px-3 bg-slate-900 hover:bg-rose-950/60 border border-slate-800 hover:border-rose-500/40 text-slate-400 hover:text-rose-300 text-[11px] font-medium rounded-xl transition-colors flex items-center justify-center gap-1.5"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Remove Custom QR</span>
                </button>
              )}

              <p className="text-[11px] text-slate-400 leading-tight">
                Supports PNG, JPG, WEBP. High-res screenshots are automatically optimized for crisp scanning.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 5-Tab Selector with notification badges */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
        <button
          id="admin-tab-creators"
          onClick={() => setActiveTab('creators')}
          className={`p-4 rounded-2xl border text-left transition-all relative ${
            activeTab === 'creators'
              ? 'bg-purple-950/40 border-purple-500/60 text-white shadow-lg'
              : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-900 hover:text-white'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-mono uppercase tracking-wider">Tab 1</span>
            {pendingCreators.length > 0 && (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500 text-slate-950">
                {pendingCreators.length} Pending
              </span>
            )}
          </div>
          <div className="text-base font-bold flex items-center gap-2">
            <Users className="w-4 h-4 text-purple-400" />
            <span>Creator Approvals</span>
          </div>
          <div className="text-xs text-slate-400 mt-1">Review channel links & grant creator status</div>
        </button>

        <button
          id="admin-tab-campaigns"
          onClick={() => setActiveTab('campaigns')}
          className={`p-4 rounded-2xl border text-left transition-all relative ${
            activeTab === 'campaigns'
              ? 'bg-emerald-950/40 border-emerald-500/60 text-white shadow-lg'
              : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-900 hover:text-white'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-mono uppercase tracking-wider">Tab 2</span>
            {pendingCampaigns.length > 0 && (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-400 text-slate-950 animate-pulse">
                {pendingCampaigns.length} For Verification
              </span>
            )}
          </div>
          <div className="text-base font-bold flex items-center gap-2">
            <Video className="w-4 h-4 text-emerald-400" />
            <span>Campaign Desk</span>
          </div>
          <div className="text-xs text-slate-400 mt-1">Match UTRs, verify receipts & activate</div>
        </button>

        <button
          id="admin-tab-freelance"
          onClick={() => setActiveTab('freelance')}
          className={`p-4 rounded-2xl border text-left transition-all relative ${
            activeTab === 'freelance'
              ? 'bg-indigo-950/40 border-indigo-500/60 text-white shadow-lg'
              : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-900 hover:text-white'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-mono uppercase tracking-wider text-indigo-400">Tab 3</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
              Escrow Jobs
            </span>
          </div>
          <div className="text-base font-bold flex items-center gap-2">
            <Briefcase className="w-4 h-4 text-indigo-400" />
            <span>Freelance Desk</span>
          </div>
          <div className="text-xs text-slate-400 mt-1">Verify editing jobs & disburse to editors</div>
        </button>

        <button
          id="admin-tab-payouts"
          onClick={() => setActiveTab('payouts')}
          className={`p-4 rounded-2xl border text-left transition-all relative ${
            activeTab === 'payouts'
              ? 'bg-amber-950/40 border-amber-500/60 text-white shadow-lg'
              : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-900 hover:text-white'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-mono uppercase tracking-wider">Tab 4</span>
            {pendingPayouts.length > 0 && (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-400 text-slate-950">
                {pendingPayouts.length} Pending Payouts
              </span>
            )}
          </div>
          <div className="text-base font-bold flex items-center gap-2">
            <CreditCard className="w-4 h-4 text-amber-400" />
            <span>Payout Desk</span>
          </div>
          <div className="text-xs text-slate-400 mt-1">Fulfill ₹40, ₹50, ₹100 user withdrawals</div>
        </button>

        {/* Tab 5: Escrow & UPI QR Configuration */}
        <button
          id="admin-tab-escrow-settings"
          onClick={() => setActiveTab('escrow_settings')}
          className={`p-4 rounded-2xl border text-left transition-all relative ${
            activeTab === 'escrow_settings'
              ? 'bg-sky-950/40 border-sky-500/60 text-white shadow-lg'
              : 'bg-slate-900/60 border-slate-800 text-slate-400 hover:bg-slate-900 hover:text-white'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-mono uppercase tracking-wider text-sky-400">Tab 5</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-sky-500/20 text-sky-300 border border-sky-500/30">
              Escrow Config
            </span>
          </div>
          <div className="text-base font-bold flex items-center gap-2">
            <QrCode className="w-4 h-4 text-sky-400" />
            <span>UPI QR & VPA</span>
          </div>
          <div className="text-xs text-slate-400 mt-1">Configure UPI ID, payee, and QR screenshot</div>
        </button>
      </div>

      {/* Main Tab Contents */}
      {loading ? (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center text-slate-400 animate-pulse">
          Loading Firestore collections...
        </div>
      ) : activeTab === 'creators' ? (
        /* TAB 1: CREATOR APPROVALS */
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6">
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div>
              <h2 className="text-lg font-bold text-white">Creator Applications</h2>
              <p className="text-xs text-slate-400">
                Approve or reject creator requests. Approving toggles role to{' '}
                <span className="text-purple-300 font-mono">approved_creator</span>.
              </p>
            </div>
            <span className="text-xs font-mono text-slate-400">Total: {applications.length}</span>
          </div>

          {applications.length === 0 ? (
            <div className="p-8 text-center text-slate-500 text-sm">
              No creator applications in Firestore yet.
            </div>
          ) : (
            <div className="space-y-4">
              {applications.map((app) => (
                <div
                  key={app.id}
                  id={`app-card-${app.id}`}
                  className="bg-slate-950 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="space-y-2 max-w-xl">
                    <div className="flex items-center gap-2">
                      <span
                        className={`text-[10px] uppercase font-mono px-2 py-0.5 rounded-full font-bold ${
                          app.status === 'approved'
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            : app.status === 'rejected'
                            ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                            : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        }`}
                      >
                        {app.status}
                      </span>
                      <span className="text-xs text-slate-400">
                        {app.email || `UID: ${app.uid.slice(0, 8)}...`}
                      </span>
                      <span className="text-xs text-slate-600">•</span>
                      <span className="text-xs text-slate-500">
                        {new Date(app.createdAt).toLocaleDateString()}
                      </span>
                    </div>

                    <div className="text-sm font-semibold text-white">
                      {app.channel_name || 'Creator Channel'}
                      {app.subscriber_count && (
                        <span className="text-xs text-purple-400 font-normal ml-2">
                          ({app.subscriber_count} subs)
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <a
                        href={app.channel_link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-xs text-purple-400 hover:underline flex items-center gap-1 font-mono break-all"
                      >
                        <span>{app.channel_link}</span>
                        <ExternalLink className="w-3 h-3 shrink-0" />
                      </a>
                    </div>

                    {app.description && (
                      <p className="text-xs text-slate-400 italic">"{app.description}"</p>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 self-start md:self-auto">
                    {app.status === 'pending' ? (
                      <>
                        <button
                          id={`approve-creator-btn-${app.id}`}
                          onClick={() => handleApproveCreator(app)}
                          disabled={actionLoadingId === app.id}
                          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded-xl shadow transition-colors flex items-center gap-1.5 disabled:opacity-50"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Approve</span>
                        </button>
                        <button
                          id={`reject-creator-btn-${app.id}`}
                          onClick={() => handleRejectCreator(app)}
                          disabled={actionLoadingId === app.id}
                          className="px-4 py-2 bg-slate-800 hover:bg-rose-950 hover:text-rose-400 text-slate-300 font-semibold text-xs rounded-xl transition-colors flex items-center gap-1.5 disabled:opacity-50"
                        >
                          <XCircle className="w-4 h-4" />
                          <span>Reject</span>
                        </button>
                      </>
                    ) : (
                      <span className="text-xs text-slate-500 capitalize">
                        Status: <strong className="text-slate-300">{app.status}</strong>
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : activeTab === 'campaigns' ? (
        /* TAB 2: CAMPAIGN DESK */
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6">
          {/* Admin Delete Toast */}
          {adminDeleteToast && (
            <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center justify-between shadow-lg">
              <div className="flex items-center gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="font-medium">{adminDeleteToast}</span>
              </div>
              <button
                type="button"
                onClick={() => setAdminDeleteToast(null)}
                className="text-emerald-400 hover:text-white"
              >
                ✕
              </button>
            </div>
          )}

          {/* Action Feedback Toast */}
          {campaignActionToast && (
            <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-sm flex items-center justify-between gap-3 shadow-lg animate-fade-in">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-400" />
                <span className="font-semibold">{campaignActionToast}</span>
              </div>
              <button
                type="button"
                onClick={() => setCampaignActionToast(null)}
                className="text-emerald-400 hover:text-white text-xs font-bold"
              >
                ✕
              </button>
            </div>
          )}

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-4">
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white">Video Campaign Acceptance & Verification Desk</h2>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold">
                  Feed Gatekeeper Active
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                As Super Admin, only campaigns you explicitly <strong className="text-emerald-400">ACCEPT</strong> will stream on the user feed. Pending or rejected videos are strictly withheld from viewers.
              </p>
            </div>
            <span className="text-xs font-mono text-slate-400">Total: {campaigns.length}</span>
          </div>

          {/* Sub-Filter Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
            <button
              type="button"
              onClick={() => setCampaignFilter('all')}
              className={`px-3.5 py-1.5 rounded-xl font-semibold transition-all ${
                campaignFilter === 'all'
                  ? 'bg-slate-700 text-white shadow'
                  : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              All Campaigns ({campaigns.length})
            </button>

            <button
              type="button"
              onClick={() => setCampaignFilter('pending')}
              className={`px-3.5 py-1.5 rounded-xl font-semibold transition-all flex items-center gap-1.5 ${
                campaignFilter === 'pending'
                  ? 'bg-amber-500 text-slate-950 shadow font-bold'
                  : 'bg-slate-900 border border-slate-800 text-amber-300 hover:text-amber-200'
              }`}
            >
              <Bell className="w-3.5 h-3.5" />
              <span>Awaiting Acceptance ({pendingCampaigns.length})</span>
            </button>

            <button
              type="button"
              onClick={() => setCampaignFilter('accepted')}
              className={`px-3.5 py-1.5 rounded-xl font-semibold transition-all flex items-center gap-1.5 ${
                campaignFilter === 'accepted'
                  ? 'bg-emerald-500 text-slate-950 shadow font-bold'
                  : 'bg-slate-900 border border-slate-800 text-emerald-400 hover:text-emerald-300'
              }`}
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Accepted & Live on Feed ({acceptedCampaigns.length})</span>
            </button>

            <button
              type="button"
              onClick={() => setCampaignFilter('rejected')}
              className={`px-3.5 py-1.5 rounded-xl font-semibold transition-all flex items-center gap-1.5 ${
                campaignFilter === 'rejected'
                  ? 'bg-rose-500 text-white shadow font-bold'
                  : 'bg-slate-900 border border-slate-800 text-rose-400 hover:text-rose-300'
              }`}
            >
              <XCircle className="w-3.5 h-3.5" />
              <span>Rejected ({rejectedCampaigns.length})</span>
            </button>
          </div>

          {(() => {
            const filteredList = campaigns.filter((c) => {
              if (campaignFilter === 'pending') return c.status === 'pending_verification' || !c.super_admin_accepted;
              if (campaignFilter === 'accepted') return c.super_admin_accepted && c.status === 'active';
              if (campaignFilter === 'rejected') return c.status === 'rejected';
              return true;
            });

            if (filteredList.length === 0) {
              return (
                <div className="p-12 text-center text-slate-500 text-sm bg-slate-950/60 rounded-2xl border border-slate-800/80">
                  {campaignFilter === 'pending'
                    ? '🎉 No video campaigns awaiting acceptance! All submissions have been reviewed.'
                    : campaignFilter === 'accepted'
                    ? 'No campaigns have been accepted yet.'
                    : campaignFilter === 'rejected'
                    ? 'No rejected campaigns.'
                    : 'No campaigns submitted yet.'}
                </div>
              );
            }

            return (
              <div className="space-y-6">
                {filteredList.map((camp) => {
                  const isTargetReached = (camp.views_count || 0) >= (camp.target_views || 1000);
                  const percentReached = Math.min(100, Math.round(((camp.views_count || 0) / (camp.target_views || 1000)) * 100));
                  const isAccepted = camp.super_admin_accepted && camp.status === 'active';
                  const isRejected = camp.status === 'rejected';
                  const isPending = !isAccepted && !isRejected;

                  return (
                    <div
                      key={camp.id}
                      id={`camp-row-${camp.id}`}
                      className={`bg-slate-950 border rounded-2xl p-5 sm:p-6 space-y-4 transition-all ${
                        isAccepted
                          ? 'border-emerald-500/40 shadow-lg shadow-emerald-950/20'
                          : isRejected
                          ? 'border-rose-500/40 opacity-75'
                          : 'border-amber-500/50 shadow-lg shadow-amber-950/30'
                      }`}
                    >
                      <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-6">
                        {/* Left: Info & Metadata */}
                        <div className="space-y-3 max-w-2xl flex-1">
                          {/* Super Admin Status Banner */}
                          <div className="flex items-center gap-2 flex-wrap">
                            {isAccepted ? (
                              <span className="text-[11px] font-bold px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1.5">
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                                <span>ACCEPTED BY SUPER ADMIN — LIVE ON FEED</span>
                              </span>
                            ) : isRejected ? (
                              <span className="text-[11px] font-bold px-3 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 flex items-center gap-1.5">
                                <XCircle className="w-3.5 h-3.5 text-rose-400" />
                                <span>REJECTED — BLOCKED FROM FEED</span>
                              </span>
                            ) : (
                              <span className="text-[11px] font-bold px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1.5 animate-pulse">
                                <Clock className="w-3.5 h-3.5 text-amber-400" />
                                <span>AWAITING SUPER ADMIN ACCEPTANCE — HIDDEN FROM FEED</span>
                              </span>
                            )}

                            {camp.is_test_mode && (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                                🧪 Super Admin Test (₹0 Free)
                              </span>
                            )}

                            {isTargetReached && (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30">
                                🎯 Target Reached
                              </span>
                            )}

                            <span className="text-xs text-slate-400">{camp.creator_email}</span>
                            <span className="text-xs text-slate-600">•</span>
                            <span className="text-xs text-slate-500">
                              {new Date(camp.createdAt).toLocaleDateString()}
                            </span>
                          </div>

                          <h3 className="text-base sm:text-lg font-bold text-white">{camp.title}</h3>

                          {/* Stats & Financial Escrow Details */}
                          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 bg-slate-900/60 p-3 rounded-xl border border-slate-800/80 text-xs">
                            <div>
                              <div className="text-slate-500">Escrow Amount:</div>
                              <div className="font-bold text-emerald-400 font-mono text-sm">
                                ₹{camp.budget}
                              </div>
                            </div>
                            <div>
                              <div className="text-slate-500">Audience Views:</div>
                              <div className="font-semibold text-slate-200">
                                {camp.views_count || 0} / {camp.target_views || 1000} ({percentReached}%)
                              </div>
                            </div>
                            <div>
                              <div className="text-slate-500">Target Views:</div>
                              <div className="font-semibold text-slate-200">
                                {camp.target_views || 1000}
                              </div>
                            </div>
                            <div className="col-span-2 sm:col-span-1">
                              <div className="text-slate-500">Sender UPI / Mobile:</div>
                              <div className="flex items-center gap-1.5 font-mono text-emerald-300 font-bold">
                                <span className="truncate max-w-[130px]" title={camp.sender_upi_or_phone}>
                                  {camp.sender_upi_or_phone || 'Not provided'}
                                </span>
                                {camp.sender_upi_or_phone && (
                                  <button
                                    type="button"
                                    onClick={() => handleCopy(camp.sender_upi_or_phone!, `sender-${camp.id}`)}
                                    className="text-slate-400 hover:text-white shrink-0"
                                    title="Copy sender UPI / phone"
                                  >
                                    {copiedId === `sender-${camp.id}` ? (
                                      <Check className="w-3 h-3 text-emerald-400" />
                                    ) : (
                                      <Copy className="w-3 h-3" />
                                    )}
                                  </button>
                                )}
                              </div>
                            </div>
                            <div className="col-span-2 sm:col-span-1">
                              <div className="text-slate-500">12-Digit UPI UTR:</div>
                              <div className="flex items-center gap-1.5 font-mono text-slate-200 font-bold">
                                <span className="truncate max-w-[120px]">{camp.utr_number}</span>
                                <button
                                  type="button"
                                  onClick={() => handleCopy(camp.utr_number, `utr-${camp.id}`)}
                                  className="text-slate-400 hover:text-white shrink-0"
                                  title="Copy UTR to clipboard"
                                >
                                  {copiedId === `utr-${camp.id}` ? (
                                    <Check className="w-3 h-3 text-emerald-400" />
                                  ) : (
                                    <Copy className="w-3 h-3" />
                                  )}
                                </button>
                              </div>
                            </div>
                          </div>

                          {/* Quiz Mode Details & Inspector Trigger */}
                          <div className="flex items-center justify-between flex-wrap gap-2 bg-slate-900/40 p-2.5 rounded-xl border border-slate-800/60 text-xs">
                            <div className="flex items-center gap-2">
                              {camp.quiz_type === 'ai_generated' ? (
                                <span className="inline-flex items-center gap-1.5 font-semibold text-purple-300">
                                  <Bot className="w-3.5 h-3.5 text-purple-400" />
                                  <span>AI-Automated Video Quiz</span>
                                  {camp.ai_quiz_fee && camp.ai_quiz_fee > 0 ? (
                                    <span className="text-[10px] font-mono text-amber-300 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">
                                      +₹10 AI Fee Paid
                                    </span>
                                  ) : (
                                    <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
                                      Free AI (≥₹500)
                                    </span>
                                  )}
                                </span>
                              ) : camp.quiz_type === 'none' ? (
                                <span className="inline-flex items-center gap-1.5 font-semibold text-emerald-300">
                                  <PlayCircle className="w-3.5 h-3.5 text-emerald-400" />
                                  <span>No Quiz (Direct Watch & Earn - Free)</span>
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1.5 font-semibold text-slate-300">
                                  <FileQuestion className="w-3.5 h-3.5 text-indigo-400" />
                                  <span>Creator Written Custom Quiz</span>
                                </span>
                              )}
                            </div>

                            {camp.custom_questions && camp.custom_questions.length > 0 && (
                              <button
                                type="button"
                                onClick={() =>
                                  setInspectQuizCampaignId(
                                    inspectQuizCampaignId === camp.id ? null : camp.id || null
                                  )
                                }
                                className="text-purple-400 hover:text-purple-300 font-semibold flex items-center gap-1 text-xs"
                              >
                                <span>
                                  {inspectQuizCampaignId === camp.id
                                    ? 'Hide Quiz Questions'
                                    : 'Inspect 5 Quiz Questions'}
                                </span>
                                {inspectQuizCampaignId === camp.id ? (
                                  <ChevronUp className="w-3.5 h-3.5" />
                                ) : (
                                  <ChevronDown className="w-3.5 h-3.5" />
                                )}
                              </button>
                            )}
                          </div>

                          <div className="flex items-center gap-4 text-xs flex-wrap">
                            <a
                              href={camp.youtube_url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-amber-400 hover:underline flex items-center gap-1 font-semibold"
                            >
                              <span>Watch Video on YouTube</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                            {camp.teaser_url && (
                              <a
                                href={camp.teaser_url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-purple-400 hover:underline flex items-center gap-1 font-semibold bg-purple-950/40 px-2.5 py-1 rounded-lg border border-purple-500/30"
                              >
                                <Film className="w-3 h-3 text-purple-400" />
                                <span>Review 15s Teaser Video</span>
                                <ExternalLink className="w-3 h-3" />
                              </a>
                            )}
                          </div>
                        </div>

                        {/* Right: Receipt Screenshot Thumbnail & Super Admin Acceptance Controls */}
                        <div className="flex flex-col sm:flex-row items-center gap-4 shrink-0">
                          {camp.receipt_url && (
                            <button
                              type="button"
                              onClick={() => setPreviewImage(camp.receipt_url)}
                              className="relative group rounded-xl overflow-hidden border border-slate-800 bg-black w-24 h-24 sm:w-28 sm:h-28 flex items-center justify-center shadow"
                              title="Click to view payment receipt screenshot"
                            >
                              <img
                                src={camp.receipt_url}
                                alt="Receipt"
                                className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                              />
                              <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity text-white text-[10px] font-semibold flex-col gap-1">
                                <Eye className="w-4 h-4" />
                                <span>View Receipt</span>
                              </div>
                            </button>
                          )}

                          <div className="flex flex-col gap-2 w-full sm:w-44">
                            {/* Super Admin Acceptance Button */}
                            {!isAccepted ? (
                              <button
                                id={`admin-accept-video-${camp.id}`}
                                onClick={() => camp.id && handleAcceptVideoCampaign(camp.id)}
                                disabled={actionLoadingId === camp.id}
                                className="w-full px-4 py-2.5 bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-emerald-950/40 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                              >
                                <CheckCircle2 className="w-4 h-4 text-slate-950 shrink-0" />
                                <span>{isRejected ? 'Re-Accept Video' : 'Accept Video & Post'}</span>
                              </button>
                            ) : (
                              <div className="px-3 py-2 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-semibold flex items-center justify-center gap-1.5 text-center">
                                <CheckCircle2 className="w-4 h-4 shrink-0" />
                                <span>Streaming to Users</span>
                              </div>
                            )}

                            {/* Reject Video Button */}
                            {!isRejected ? (
                              <button
                                type="button"
                                id={`admin-reject-video-${camp.id}`}
                                onClick={() => camp.id && handleRejectVideoCampaign(camp.id)}
                                disabled={actionLoadingId === camp.id}
                                className="w-full px-3 py-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors disabled:opacity-50"
                              >
                                <XCircle className="w-3.5 h-3.5 text-rose-400" />
                                <span>{isAccepted ? 'Revoke / Reject' : 'Reject Video'}</span>
                              </button>
                            ) : (
                              <div className="px-3 py-1.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs font-medium text-center">
                                Video Blocked
                              </div>
                            )}

                            {/* Delete Campaign Button */}
                            <button
                              type="button"
                              id={`admin-delete-camp-${camp.id}`}
                              onClick={() => setDeleteModalCampaign(camp)}
                              className="w-full px-3 py-2 bg-slate-900 hover:bg-rose-950/40 text-slate-400 hover:text-rose-300 border border-slate-800 rounded-xl text-xs font-medium flex items-center justify-center gap-1.5 transition-colors"
                              title="Super Admin: Permanently delete this campaign"
                            >
                              <Trash2 className="w-3.5 h-3.5 text-slate-400" />
                              <span>{isTargetReached ? 'Delete (Target Met)' : 'Delete Record'}</span>
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Expandable Quiz Questions Inspector */}
                      {inspectQuizCampaignId === camp.id && camp.custom_questions && (
                        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 mt-3 space-y-3 animate-fade-in">
                          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                            <span className="text-xs font-bold text-white flex items-center gap-1.5">
                              <HelpCircle className="w-4 h-4 text-purple-400" />
                              <span>5 Comprehension Questions & Answer Keys</span>
                            </span>
                            <span className="text-[11px] text-slate-400 font-mono">
                              Required for Viewer Verification
                            </span>
                          </div>

                          <div className="space-y-3">
                            {camp.custom_questions.map((q, qIndex) => (
                              <div
                                key={qIndex}
                                className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-xs space-y-2"
                              >
                                <div className="font-semibold text-white flex items-start gap-2">
                                  <span className="px-2 py-0.5 rounded-md bg-purple-500/20 text-purple-300 font-mono text-[10px] font-bold">
                                    Q{qIndex + 1}
                                  </span>
                                  <span>{q.question}</span>
                                </div>

                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pl-6">
                                  {q.options.map((opt, optIndex) => {
                                    const isCorrect = q.correctAnswerIndex === optIndex;
                                    return (
                                      <div
                                        key={optIndex}
                                        className={`p-2 rounded-lg border text-[11px] flex items-center justify-between gap-2 ${
                                          isCorrect
                                            ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-200 font-semibold'
                                            : 'bg-slate-900/60 border-slate-800/80 text-slate-300'
                                        }`}
                                      >
                                        <span>
                                          <strong className="text-slate-400 mr-1.5 font-mono">
                                            {String.fromCharCode(65 + optIndex)}.
                                          </strong>
                                          {opt}
                                        </span>
                                        {isCorrect && (
                                          <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20 shrink-0">
                                            ✓ Correct Key
                                          </span>
                                        )}
                                      </div>
                                    );
                                  })}
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            );
          })()}
        </div>
      ) : activeTab === 'freelance' ? (
        /* TAB 3: FREELANCE ESCROW & JOBS DESK */
        <AdminFreelanceDesk />
      ) : activeTab === 'payouts' ? (
        /* TAB 4: PAYOUT DESK */
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-4">
            <div>
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <span>Payout Fulfillment Desk</span>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  Manual Super Admin Only
                </span>
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                Fulfill user payout requests manually via your banking/UPI app or telecom recharge portal without automation, then click 'Mark Paid & Deduct Escrow'.
              </p>
            </div>
            <span className="text-xs font-mono text-slate-400">Total: {withdrawals.length}</span>
          </div>

          {/* Super Admin Manual Fulfillment Notice */}
          <div className="p-4 bg-sky-950/20 border border-sky-500/30 rounded-2xl flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
            <div className="text-xs text-sky-200 leading-relaxed">
              <strong className="text-white">Manual Direct Fulfillment Workflow:</strong>
              <ul className="list-disc list-inside mt-1 space-y-0.5 text-slate-300">
                <li><strong className="text-amber-400">₹40 / ₹50 SIM Recharge:</strong> Use Jio/Airtel/Vi app to recharge the user's mobile number.</li>
                <li><strong className="text-emerald-400">₹50 Google Play Redeem:</strong> Purchase a ₹50 gift code and send it to the user's provided email or phone.</li>
                <li><strong className="text-cyan-400">₹100+ UPI Direct Transfer:</strong> Pay directly to their UPI ID or click <strong className="text-cyan-300">'Scan User QR'</strong> to scan their attached payment screenshot using GPay / PhonePe / Paytm.</li>
              </ul>
            </div>
          </div>

          {withdrawals.length === 0 ? (
            <div className="p-8 text-center text-slate-500 text-sm">
              No withdrawal requests submitted yet.
            </div>
          ) : (
            <div className="space-y-4">
              {withdrawals.map((wth) => {
                const isRecharge = wth.category === 'recharge' || wth.method.includes('Recharge');
                const isGooglePlay = wth.category === 'google_play' || wth.method.includes('Google Play');
                const isUPI = !isRecharge && !isGooglePlay;

                return (
                  <div
                    key={wth.id}
                    id={`withdrawal-row-${wth.id}`}
                    className="bg-slate-950 border border-slate-800 rounded-2xl p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-5"
                  >
                    <div className="space-y-2.5 flex-1">
                      {/* Status and Timestamp */}
                      <div className="flex items-center gap-2 flex-wrap">
                        <span
                          className={`text-[10px] uppercase font-mono px-2 py-0.5 rounded-full font-bold ${
                            wth.status === 'paid'
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                              : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          }`}
                        >
                          {wth.status === 'paid' ? 'Paid & Deducted' : 'Pending Manual Payment'}
                        </span>

                        {isRecharge && (
                          <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center gap-1">
                            <Smartphone className="w-3 h-3" />
                            <span>Mobile Recharge</span>
                          </span>
                        )}

                        {isGooglePlay && (
                          <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
                            <Play className="w-3 h-3" />
                            <span>Google Play</span>
                          </span>
                        )}

                        {isUPI && (
                          <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 flex items-center gap-1">
                            <QrCode className="w-3 h-3" />
                            <span>UPI Transfer</span>
                          </span>
                        )}

                        <span className="text-xs text-slate-400">
                          {wth.email || `UID: ${wth.uid.slice(0, 8)}...`}
                        </span>
                        <span className="text-xs text-slate-600">•</span>
                        <span className="text-xs text-slate-500">
                          {new Date(wth.createdAt).toLocaleDateString()}
                        </span>
                      </div>

                      {/* Amount and Method */}
                      <div className="flex items-baseline gap-3">
                        <span className="text-3xl font-black text-amber-400 font-mono">
                          ₹{wth.amount}
                        </span>
                        <span className="text-xs text-slate-300 font-medium">
                          {wth.method}
                        </span>
                      </div>

                      {/* Detailed Destination Info based on Type */}
                      <div className="bg-slate-900 px-4 py-3 rounded-xl border border-slate-800 space-y-2 text-xs">
                        {isRecharge ? (
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-slate-400 font-medium">SIM Number:</span>
                              <span className="font-mono text-white font-bold select-all bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800">
                                {wth.sim_number || wth.payment_details}
                              </span>
                              {wth.sim_operator && (
                                <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px] font-semibold">
                                  {wth.sim_operator}
                                </span>
                              )}
                            </div>
                            <button
                              type="button"
                              onClick={() => handleCopy(wth.sim_number || wth.payment_details, `sim-${wth.id}`)}
                              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg flex items-center gap-1 text-[11px] w-fit"
                            >
                              {copiedId === `sim-${wth.id}` ? (
                                <>
                                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                                  <span className="text-emerald-400">Copied</span>
                                </>
                              ) : (
                                <>
                                  <Copy className="w-3.5 h-3.5" />
                                  <span>Copy Number</span>
                                </>
                              )}
                            </button>
                          </div>
                        ) : isGooglePlay ? (
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="text-slate-400 font-medium">Deliver Code To:</span>
                              <span className="font-mono text-white font-bold select-all bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800">
                                {wth.google_play_email || wth.payment_details}
                              </span>
                            </div>
                            <button
                              type="button"
                              onClick={() => handleCopy(wth.google_play_email || wth.payment_details, `gp-${wth.id}`)}
                              className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg flex items-center gap-1 text-[11px] w-fit"
                            >
                              {copiedId === `gp-${wth.id}` ? (
                                <>
                                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                                  <span className="text-emerald-400">Copied</span>
                                </>
                              ) : (
                                <>
                                  <Copy className="w-3.5 h-3.5" />
                                  <span>Copy Destination</span>
                                </>
                              )}
                            </button>
                          </div>
                        ) : (
                          /* UPI Transfer */
                          <div className="space-y-2">
                            {wth.upi_id && (
                              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <span className="text-slate-400 font-medium">UPI VPA:</span>
                                  <span className="font-mono text-cyan-300 font-bold select-all bg-slate-950 px-2.5 py-1 rounded-lg border border-slate-800">
                                    {wth.upi_id}
                                  </span>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => handleCopy(wth.upi_id || '', `upi-${wth.id}`)}
                                  className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg flex items-center gap-1 text-[11px] w-fit"
                                >
                                  {copiedId === `upi-${wth.id}` ? (
                                    <>
                                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                                      <span className="text-emerald-400">Copied</span>
                                    </>
                                  ) : (
                                    <>
                                      <Copy className="w-3.5 h-3.5" />
                                      <span>Copy UPI</span>
                                    </>
                                  )}
                                </button>
                              </div>
                            )}

                            {wth.screenshot_url && (
                              <div className="flex items-center justify-between pt-1 border-t border-slate-800/80">
                                <div className="flex items-center gap-2 text-cyan-400 text-xs">
                                  <QrCode className="w-4 h-4" />
                                  <span>User Attached Payment QR Screenshot:</span>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => setPreviewImage(wth.screenshot_url || null)}
                                  className="px-3 py-1.5 bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 rounded-lg flex items-center gap-1.5 text-xs font-semibold transition-colors"
                                >
                                  <Eye className="w-3.5 h-3.5" />
                                  <span>View & Scan QR</span>
                                </button>
                              </div>
                            )}

                            {!wth.upi_id && !wth.screenshot_url && (
                              <div className="font-mono text-slate-200 select-all">
                                {wth.payment_details}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Fulfill Action & Super Admin Delete */}
                    <div className="flex flex-col gap-2 shrink-0">
                      {wth.status === 'pending' ? (
                        <button
                          id={`mark-paid-btn-${wth.id}`}
                          onClick={() => handleMarkPaid(wth)}
                          disabled={actionLoadingId === wth.id}
                          className="px-5 py-3 bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 font-bold text-xs rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Mark Paid & Deduct Escrow</span>
                        </button>
                      ) : (
                        <div className="p-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl text-center">
                          <div className="text-xs font-semibold text-emerald-400 flex items-center gap-1 justify-center">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Paid & Deducted</span>
                          </div>
                          {wth.paidAt && (
                            <div className="text-[10px] text-slate-500 mt-0.5">
                              {new Date(wth.paidAt).toLocaleString()}
                            </div>
                          )}
                        </div>
                      )}

                      {/* Super Admin Delete Option */}
                      <button
                        type="button"
                        id={`delete-wth-btn-${wth.id}`}
                        onClick={() => wth.id && handleDeleteWithdrawal(wth.id)}
                        disabled={actionLoadingId === wth.id}
                        className="px-3 py-1.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/20 rounded-xl text-xs flex items-center justify-center gap-1.5 transition-colors"
                        title="Delete withdrawal record"
                      >
                        <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                        <span>Delete Record</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      ) : (
        /* TAB 4: ESCROW & UPI QR CONFIGURATION */
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-4">
            <div>
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-sky-500/10 text-sky-400 text-xs font-semibold mb-1 border border-sky-500/20">
                <QrCode className="w-3.5 h-3.5" />
                <span>Super Admin Escrow Configuration</span>
              </div>
              <h2 className="text-xl font-bold text-white">Full Escrow Settings & UPI Configuration</h2>
              <p className="text-xs text-slate-400 mt-1">
                Configure your official UPI ID, payee name, and attach official QR screenshot.
              </p>
            </div>
          </div>

          <form onSubmit={handleSaveEscrowSettings} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Left: Inputs */}
            <div className="lg:col-span-7 space-y-5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">
                  Super Admin UPI ID (VPA) <span className="text-rose-400">*</span>
                </label>
                <input
                  id="admin-upi-id-input"
                  type="text"
                  value={escrowSettings.upi_id}
                  onChange={(e) => setEscrowSettings({ ...escrowSettings, upi_id: e.target.value.trim() })}
                  placeholder="mrinalkantisingharoy2009@okhdfcbank or yourname@upi"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm font-mono text-white placeholder-slate-500 focus:outline-none focus:border-sky-500"
                  required
                />
                <p className="text-[11px] text-slate-500 mt-1">
                  Creators copy this UPI ID to send payment via GPay, PhonePe, Paytm, or BHIM.
                </p>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2">
                  Official Payee Name <span className="text-rose-400">*</span>
                </label>
                <input
                  id="admin-payee-name-input"
                  type="text"
                  value={escrowSettings.payee_name}
                  onChange={(e) => setEscrowSettings({ ...escrowSettings, payee_name: e.target.value })}
                  placeholder="Mrinal Kanti Singha Roy"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-sky-500"
                  required
                />
              </div>

              {/* Upload QR Screenshot */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-2 flex items-center justify-between">
                  <span>Attach Official UPI QR Code Screenshot</span>
                  {escrowSettings.qr_image_url && (
                    <button
                      type="button"
                      onClick={handleRemoveQR}
                      className="text-rose-400 text-[11px] hover:underline"
                    >
                      Remove Screenshot (Revert to SVG)
                    </button>
                  )}
                </label>

                <div className="border-2 border-dashed border-slate-800 hover:border-slate-700 bg-slate-950 rounded-2xl p-6 text-center transition-colors">
                  <label className="cursor-pointer block space-y-2">
                    <Upload className="w-8 h-8 mx-auto text-sky-400" />
                    <div className="text-xs text-slate-200 font-semibold">
                      Click to upload your UPI QR screenshot
                    </div>
                    <div className="text-[11px] text-slate-500">
                      Take a screenshot of your GPay/PhonePe QR code on your phone and attach it here (PNG, JPG, WEBP)
                    </div>
                    <input
                      id="admin-qr-screenshot-input"
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) handleFileSelect(file);
                      }}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              <button
                id="save-escrow-settings-btn"
                type="submit"
                disabled={savingSettings}
                className="w-full py-3 bg-gradient-to-r from-sky-500 to-indigo-600 hover:from-sky-400 hover:to-indigo-500 text-white font-bold text-sm rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {savingSettings ? (
                  <span>Saving Configuration to Firestore...</span>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    <span>Save All Escrow Details</span>
                  </>
                )}
              </button>
            </div>

            {/* Right: Live Preview of what creators will see */}
            <div className="lg:col-span-5 space-y-4">
              <div className="text-xs font-semibold text-slate-400">
                Live Preview of Creator Checkout QR Screen:
              </div>

              <div className="bg-slate-950 border border-slate-800 rounded-3xl p-6 text-center space-y-4 shadow-xl">
                <div className="w-52 h-52 mx-auto bg-white rounded-2xl p-3 flex items-center justify-center border border-slate-800 overflow-hidden shadow-inner">
                  {escrowSettings.qr_image_url ? (
                    <img
                      src={escrowSettings.qr_image_url}
                      alt="Super Admin QR Preview"
                      className="w-full h-full object-contain"
                    />
                  ) : (
                    <div className="text-center p-4">
                      <QrCode className="w-16 h-16 mx-auto text-slate-400 mb-2" />
                      <div className="text-[10px] text-slate-500 font-mono">
                        No QR screenshot attached yet. (Default SVG will render).
                      </div>
                    </div>
                  )}
                </div>

                <div className="space-y-1.5 text-left bg-slate-900/60 p-3.5 rounded-2xl border border-slate-800 text-xs">
                  <div className="text-slate-400 text-[11px]">UPI ID:</div>
                  <div className="font-mono text-emerald-400 font-bold break-all">
                    {escrowSettings.upi_id || 'Not configured'}
                  </div>

                  <div className="text-slate-400 text-[11px] pt-1">Payee Name:</div>
                  <div className="text-slate-200 font-semibold">
                    {escrowSettings.payee_name || 'Mrinal Kanti Singha Roy'}
                  </div>
                </div>

                <div className="text-[11px] text-slate-500 italic">
                  Changes take effect immediately across all creator campaign checkouts.
                </div>
              </div>
            </div>
          </form>
        </div>
      )}

      {/* Lightbox Modal for Receipt Screenshot */}
      {previewImage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-fade-in">
          <div className="relative max-w-2xl w-full bg-slate-900 border border-slate-800 rounded-3xl p-4 overflow-hidden">
            <button
              onClick={() => setPreviewImage(null)}
              className="absolute top-4 right-4 p-2 bg-slate-800 rounded-full text-slate-300 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="text-xs text-slate-400 font-mono mb-2">
              Payment Screenshot Verification
            </div>
            <img
              src={previewImage}
              alt="UPI Receipt High-Res"
              className="w-full max-h-[80vh] object-contain rounded-xl bg-black"
            />
          </div>
        </div>
      )}

      {/* Super Admin Delete Confirmation Modal */}
      {deleteModalCampaign && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-2xl bg-rose-500/20 border border-rose-500/30 text-rose-400 flex items-center justify-center shrink-0">
                <Trash2 className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h3 className="text-lg font-bold text-white">Permanently Delete Campaign?</h3>
                <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded-full font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                  Super Admin Authorization
                </span>
              </div>
            </div>

            <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 space-y-2 text-xs">
              <p className="font-semibold text-slate-200 line-clamp-2">
                {deleteModalCampaign.title || 'Video Campaign'}
              </p>
              <div className="flex items-center gap-3 text-slate-400 text-[11px] pt-1 border-t border-slate-900 flex-wrap">
                <span>Creator: <strong>{deleteModalCampaign.creator_email}</strong></span>
                <span>Views: <strong>{deleteModalCampaign.views_count || 0} / {deleteModalCampaign.target_views || 1000}</strong></span>
                {(deleteModalCampaign.views_count || 0) >= (deleteModalCampaign.target_views || 1000) && (
                  <span className="text-emerald-400 font-semibold">• Target Audience Reached</span>
                )}
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              As Super Admin, you are deleting this campaign. This will permanently delete the document from Firestore and remove the video and attached teaser from all user feeds.
            </p>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setDeleteModalCampaign(null)}
                disabled={isDeletingCampaign}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                id="confirm-delete-admin-camp-btn"
                onClick={() => handleDeleteCampaign(deleteModalCampaign)}
                disabled={isDeletingCampaign}
                className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-rose-950/50 disabled:opacity-50 transition-colors"
              >
                {isDeletingCampaign ? (
                  <span>Deleting...</span>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Confirm Delete</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
