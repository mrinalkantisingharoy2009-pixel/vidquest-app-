import React from 'react';
import { useAuth } from '../context/AuthContext';
import {
  Coins,
  Lock,
  Sparkles,
  ShieldCheck,
  Video,
  LogOut,
  User as UserIcon,
  ShieldAlert,
  Flame,
  ArrowUpRight,
  Briefcase
} from 'lucide-react';

interface NavbarProps {
  currentTab: 'feed' | 'creator' | 'freelance' | 'admin' | 'withdrawals';
  setCurrentTab: (tab: 'feed' | 'creator' | 'freelance' | 'admin' | 'withdrawals') => void;
  openAuthModal: () => void;
  openWithdrawModal: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  openAuthModal,
  openWithdrawModal
}) => {
  const { currentUser, userProfile, isSuperAdmin, role, logout } = useAuth();

  const getRoleBadge = () => {
    if (isSuperAdmin) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-rose-500/15 text-rose-400 border border-rose-500/30">
          <ShieldAlert className="w-3 h-3" />
          Super Admin
        </span>
      );
    }
    if (role === 'approved_creator') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-purple-500/15 text-purple-300 border border-purple-500/30">
          <Sparkles className="w-3 h-3" />
          Approved Creator
        </span>
      );
    }
    if (role === 'pending_creator') {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/15 text-amber-300 border border-amber-500/30">
          Pending Creator
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-800 text-slate-300 border border-slate-700">
        User
      </span>
    );
  };

  return (
    <header className="sticky top-0 z-40 bg-slate-950/80 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div className="flex items-center gap-8">
            <button
              id="brand-logo-btn"
              onClick={() => setCurrentTab('feed')}
              className="flex items-center gap-2.5 text-left focus:outline-none group"
            >
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-rose-600 flex items-center justify-center text-white shadow-md shadow-rose-950/50 group-hover:scale-105 transition-transform">
                <Video className="w-5 h-5" />
              </div>
              <div>
                <span className="text-xl font-bold tracking-tight text-white flex items-center gap-1">
                  Vid<span className="text-amber-400">Quest</span>
                  <span className="text-[10px] font-mono uppercase px-1.5 py-0.2 bg-amber-500/10 text-amber-300 rounded border border-amber-500/20">
                    Phase 1
                  </span>
                </span>
              </div>
            </button>

            {/* Navigation tabs */}
            <nav className="hidden md:flex items-center gap-1">
              <button
                id="nav-feed-tab"
                onClick={() => setCurrentTab('feed')}
                className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                  currentTab === 'feed'
                    ? 'bg-slate-800 text-white'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                Video Feed
              </button>
              <button
                id="nav-creator-tab"
                onClick={() => setCurrentTab('creator')}
                className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                  currentTab === 'creator'
                    ? 'bg-slate-800 text-white'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                Creator Studio
              </button>
              <button
                id="nav-freelance-tab"
                onClick={() => setCurrentTab('freelance')}
                className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-colors flex items-center gap-1.5 ${
                  currentTab === 'freelance'
                    ? 'bg-indigo-950/80 text-indigo-300 border border-indigo-500/40'
                    : 'text-slate-400 hover:text-indigo-300 hover:bg-slate-900'
                }`}
              >
                <Briefcase className="w-3.5 h-3.5 text-indigo-400" />
                <span>Freelance Hub</span>
              </button>
              <button
                id="nav-withdrawals-tab"
                onClick={() => setCurrentTab('withdrawals')}
                className={`px-3.5 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                  currentTab === 'withdrawals'
                    ? 'bg-slate-800 text-white'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
                }`}
              >
                Payouts
              </button>

              {/* Admin Desk tab - only for Super Admin */}
              {isSuperAdmin && (
                <button
                  id="nav-admin-tab"
                  onClick={() => setCurrentTab('admin')}
                  className={`px-3.5 py-1.5 rounded-lg text-sm font-semibold transition-colors flex items-center gap-1.5 ${
                    currentTab === 'admin'
                      ? 'bg-rose-950/80 text-rose-300 border border-rose-500/40'
                      : 'text-rose-400 hover:bg-rose-950/40 hover:text-rose-200'
                  }`}
                >
                  <ShieldCheck className="w-4 h-4" />
                  Admin Desk
                </button>
              )}
            </nav>
          </div>

          {/* Right action bar: Wallet Balance, Role Badge, Auth */}
          <div className="flex items-center gap-3">
            {currentUser ? (
              <>
                {/* Wallet Balance Pill */}
                <button
                  id="wallet-balance-pill"
                  onClick={openWithdrawModal}
                  className="group flex items-center gap-2 px-3 py-1.5 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 rounded-xl text-amber-300 transition-all text-sm font-medium"
                  title="Click to withdraw earned coins"
                >
                  <Coins className="w-4 h-4 text-amber-400 animate-pulse" />
                  <span className="font-semibold text-white">
                    ₹{(userProfile?.wallet_balance || 0).toLocaleString('en-IN')}
                  </span>
                  <span className="text-xs text-amber-400/80 hidden sm:inline">Coins</span>
                  <ArrowUpRight className="w-3.5 h-3.5 text-amber-400 opacity-60 group-hover:opacity-100 transition-opacity" />
                </button>

                {/* Locked Escrow Pill (if any) */}
                {(userProfile?.escrow_locked || 0) > 0 && (
                  <div
                    id="escrow-locked-pill"
                    className="flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-400"
                    title="Funds locked in active withdrawal escrow"
                  >
                    <Lock className="w-3 h-3 text-amber-400" />
                    <span>Locked:</span>
                    <span className="font-semibold text-slate-200">
                      ₹{userProfile?.escrow_locked}
                    </span>
                  </div>
                )}

                {/* Role Badge */}
                <div className="hidden sm:block">{getRoleBadge()}</div>

                {/* User Avatar & Logout */}
                <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
                  <div className="text-right hidden lg:block">
                    <div className="text-xs font-medium text-slate-200 truncate max-w-[120px]">
                      {userProfile?.displayName || currentUser.email?.split('@')[0]}
                    </div>
                    <div className="text-[10px] text-slate-400 truncate max-w-[120px]">
                      {currentUser.email}
                    </div>
                  </div>

                  <button
                    id="logout-btn"
                    onClick={logout}
                    className="p-2 text-slate-400 hover:text-rose-400 hover:bg-slate-900 rounded-lg transition-colors"
                    title="Log out"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              </>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  id="sign-in-btn"
                  onClick={openAuthModal}
                  className="px-4 py-2 bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-white font-medium text-sm rounded-xl shadow-lg shadow-rose-950/40 transition-all flex items-center gap-2"
                >
                  <UserIcon className="w-4 h-4" />
                  Sign In / Join
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="md:hidden flex items-center justify-around py-2 border-t border-slate-800/60 text-xs">
          <button
            onClick={() => setCurrentTab('feed')}
            className={`py-1 px-2 rounded ${currentTab === 'feed' ? 'text-amber-400 font-semibold' : 'text-slate-400'}`}
          >
            Feed
          </button>
          <button
            onClick={() => setCurrentTab('creator')}
            className={`py-1 px-2 rounded ${currentTab === 'creator' ? 'text-amber-400 font-semibold' : 'text-slate-400'}`}
          >
            Creator Studio
          </button>
          <button
            onClick={() => setCurrentTab('freelance')}
            className={`py-1 px-2 rounded ${currentTab === 'freelance' ? 'text-indigo-400 font-semibold' : 'text-slate-400'}`}
          >
            Freelance
          </button>
          <button
            onClick={() => setCurrentTab('withdrawals')}
            className={`py-1 px-2 rounded ${currentTab === 'withdrawals' ? 'text-amber-400 font-semibold' : 'text-slate-400'}`}
          >
            Payouts
          </button>
          {isSuperAdmin && (
            <button
              onClick={() => setCurrentTab('admin')}
              className={`py-1 px-2 rounded ${currentTab === 'admin' ? 'text-rose-400 font-semibold' : 'text-rose-400/70'}`}
            >
              Admin Desk
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
