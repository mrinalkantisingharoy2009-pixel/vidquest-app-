import React, { useState, useEffect } from 'react';
import {
  Briefcase,
  ExternalLink,
  CheckCircle2,
  XCircle,
  Copy,
  Check,
  Eye,
  X,
  Clock,
  ShieldCheck,
  DollarSign,
  AlertCircle,
  RefreshCw,
  Trash2,
  Film,
  Send,
  User,
  Filter,
  Layers,
  Sparkles
} from 'lucide-react';
import {
  FreelanceJob,
  FreelanceApplication,
  MARKET_RATE_BENCHMARKS
} from '../types';
import {
  getAllFreelanceJobs,
  approveAndLaunchFreelanceJob,
  rejectFreelanceJob,
  deleteFreelanceJob,
  markJobCompletedAndPaid,
  getJobApplications
} from '../services/freelanceService';

export const AdminFreelanceDesk: React.FC = () => {
  const [jobs, setJobs] = useState<FreelanceJob[]>([]);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState<'all' | 'pending' | 'open' | 'in_progress' | 'submitted' | 'completed'>('all');
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Lightbox for payment receipt
  const [receiptLightbox, setReceiptLightbox] = useState<string | null>(null);

  // Copied feedback
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Job Applications modal
  const [inspectingJob, setInspectingJob] = useState<FreelanceJob | null>(null);
  const [applicants, setApplicants] = useState<FreelanceApplication[]>([]);
  const [loadingApplicants, setLoadingApplicants] = useState(false);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const loadJobs = async () => {
    setLoading(true);
    try {
      const data = await getAllFreelanceJobs();
      setJobs(data);
    } catch (err) {
      console.error('Failed to load freelance jobs for admin:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadJobs();
  }, []);

  const handleApproveAndLaunch = async (jobId: string) => {
    setActionLoadingId(jobId);
    try {
      await approveAndLaunchFreelanceJob(jobId, 'Approved by Super Admin');
      setToastMsg('Freelance job verified and launched to the public Freelance Hub!');
      setTimeout(() => setToastMsg(null), 5000);
      loadJobs();
    } catch (err: unknown) {
      alert(err instanceof Error ? err.message : 'Error launching job');
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleReject = async (jobId: string) => {
    const reason = prompt('Please enter rejection reason (e.g. Invalid UTR, insufficient funds):');
    if (!reason) return;
    setActionLoadingId(jobId);
    try {
      await rejectFreelanceJob(jobId, reason);
      setToastMsg('Job marked as rejected.');
      setTimeout(() => setToastMsg(null), 4000);
      loadJobs();
    } catch (err: unknown) {
      alert(err instanceof Error ? err.message : 'Error rejecting job');
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleCompleteAndPay = async (job: FreelanceJob) => {
    if (!job.id) return;
    const confirm = window.confirm(`Confirm payment release of ₹${job.editor_net_payout} to ${job.assigned_freelancer_email}?`);
    if (!confirm) return;

    setActionLoadingId(job.id);
    try {
      await markJobCompletedAndPaid(job.id);
      setToastMsg(`Job marked completed and payout of ₹${job.editor_net_payout} released!`);
      setTimeout(() => setToastMsg(null), 5000);
      loadJobs();
    } catch (err: unknown) {
      alert(err instanceof Error ? err.message : 'Error completing job');
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleDelete = async (jobId: string) => {
    if (!window.confirm('Are you sure you want to permanently delete this freelance job?')) return;
    setActionLoadingId(jobId);
    try {
      await deleteFreelanceJob(jobId);
      setToastMsg('Job deleted.');
      setTimeout(() => setToastMsg(null), 3000);
      loadJobs();
    } catch (err: unknown) {
      alert(err instanceof Error ? err.message : 'Error deleting job');
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleViewApplicants = async (job: FreelanceJob) => {
    if (!job.id) return;
    setInspectingJob(job);
    setLoadingApplicants(true);
    try {
      const data = await getJobApplications(job.id);
      setApplicants(data);
    } catch (err) {
      console.error('Failed to load applicants:', err);
    } finally {
      setLoadingApplicants(false);
    }
  };

  const pendingJobs = jobs.filter((j) => j.status === 'pending_super_admin');
  const openCount = jobs.filter((j) => j.status === 'open').length;
  const inProgressCount = jobs.filter((j) => j.status === 'in_progress').length;
  const submittedCount = jobs.filter((j) => j.status === 'submitted').length;
  const completedCount = jobs.filter((j) => j.status === 'completed').length;

  const filteredJobs = jobs.filter((job) => {
    if (filter === 'all') return true;
    if (filter === 'pending') return job.status === 'pending_super_admin';
    if (filter === 'open') return job.status === 'open';
    if (filter === 'in_progress') return job.status === 'in_progress';
    if (filter === 'submitted') return job.status === 'submitted';
    if (filter === 'completed') return job.status === 'completed';
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Toast Notification */}
      {toastMsg && (
        <div className="p-4 rounded-2xl bg-indigo-500/15 border border-indigo-500/30 text-indigo-300 text-xs font-semibold flex items-center gap-2 shadow-lg">
          <CheckCircle2 className="w-4 h-4 text-indigo-400 shrink-0" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Action Banner for Pending Review */}
      {pendingJobs.length > 0 && (
        <div className="p-4 sm:p-5 rounded-3xl bg-amber-500/10 border border-amber-500/30 text-amber-300 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-sm shrink-0 border border-amber-500/30">
              {pendingJobs.length}
            </div>
            <div>
              <div className="font-bold text-sm text-white">
                {pendingJobs.length} Freelance Job{pendingJobs.length > 1 ? 's' : ''} Awaiting Super Admin Launch!
              </div>
              <p className="text-xs text-amber-300/80">
                Creators deposited escrow via UPI. Verify UTR and launch these jobs so student editors can apply.
              </p>
            </div>
          </div>
          <button
            onClick={() => setFilter('pending')}
            className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl shadow self-start sm:self-auto transition-all"
          >
            Review Pending Jobs
          </button>
        </div>
      )}

      {/* Header and Filter Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Briefcase className="w-5 h-5 text-indigo-400" />
            <span>Freelance Jobs Verification & Escrow Desk</span>
          </h2>
          <p className="text-xs text-slate-400">
            Control creator freelance editing jobs, verify deposit UTRs, launch to students, and disburse editor payouts.
          </p>
        </div>

        <button
          onClick={loadJobs}
          className="text-xs text-slate-400 hover:text-white flex items-center gap-1 self-start sm:self-auto"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Desk</span>
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
        <button
          onClick={() => setFilter('all')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
            filter === 'all'
              ? 'bg-indigo-600 text-white shadow'
              : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          All ({jobs.length})
        </button>
        <button
          onClick={() => setFilter('pending')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
            filter === 'pending'
              ? 'bg-amber-500 text-slate-950 font-bold shadow'
              : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          Awaiting Launch ({pendingJobs.length})
        </button>
        <button
          onClick={() => setFilter('open')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
            filter === 'open'
              ? 'bg-emerald-600 text-white shadow'
              : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          Live on Marketplace ({openCount})
        </button>
        <button
          onClick={() => setFilter('in_progress')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
            filter === 'in_progress'
              ? 'bg-purple-600 text-white shadow'
              : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          In Progress ({inProgressCount})
        </button>
        <button
          onClick={() => setFilter('submitted')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
            filter === 'submitted'
              ? 'bg-cyan-600 text-white shadow'
              : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          Deliverable Submitted ({submittedCount})
        </button>
        <button
          onClick={() => setFilter('completed')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
            filter === 'completed'
              ? 'bg-slate-700 text-white shadow'
              : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-white'
          }`}
        >
          Completed ({completedCount})
        </button>
      </div>

      {/* Jobs Cards */}
      {loading ? (
        <div className="py-16 text-center text-slate-400 text-xs flex items-center justify-center gap-2">
          <RefreshCw className="w-5 h-5 animate-spin text-indigo-400" />
          <span>Loading freelance jobs...</span>
        </div>
      ) : filteredJobs.length === 0 ? (
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-12 text-center space-y-3">
          <Briefcase className="w-10 h-10 text-slate-600 mx-auto" />
          <p className="text-sm text-slate-400">No freelance jobs found matching this filter.</p>
        </div>
      ) : (
        <div className="grid gap-4">
          {filteredJobs.map((job) => {
            const benchmark = MARKET_RATE_BENCHMARKS[job.category] || MARKET_RATE_BENCHMARKS.video_editing;
            const isPending = job.status === 'pending_super_admin';
            const isActionLoading = actionLoadingId === job.id;

            return (
              <div
                key={job.id}
                className={`bg-slate-900 border rounded-3xl p-6 space-y-4 transition-all ${
                  isPending
                    ? 'border-amber-500/40 ring-1 ring-amber-500/20'
                    : 'border-slate-800'
                }`}
              >
                {/* Header */}
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 border-b border-slate-800/80 pb-4">
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/15 text-indigo-300 border border-indigo-500/30">
                        {benchmark.name}
                      </span>
                      <span className="text-[11px] text-slate-400">
                        Turnaround: {job.turnaround_days} Days
                      </span>
                      <span className="text-[11px] text-slate-500">
                        • Posted: {new Date(job.createdAt).toLocaleString()}
                      </span>
                    </div>

                    <h3 className="text-base font-bold text-white">{job.title}</h3>
                    <p className="text-xs text-slate-400">
                      Creator: <span className="text-slate-200 font-mono">{job.creator_email}</span>
                    </p>
                  </div>

                  {/* Status Badge */}
                  <div>
                    {job.status === 'pending_super_admin' && (
                      <span className="px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse">
                        Awaiting Super Admin Launch
                      </span>
                    )}
                    {job.status === 'open' && (
                      <span className="px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                        Live on Freelance Hub ({job.applicant_count || 0} applicants)
                      </span>
                    )}
                    {job.status === 'in_progress' && (
                      <span className="px-3 py-1 rounded-full text-xs font-semibold bg-purple-500/15 text-purple-300 border border-purple-500/30">
                        In Progress: {job.assigned_freelancer_email}
                      </span>
                    )}
                    {job.status === 'submitted' && (
                      <span className="px-3 py-1 rounded-full text-xs font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                        Deliverable Submitted — Ready for Payout
                      </span>
                    )}
                    {job.status === 'completed' && (
                      <span className="px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                        Completed & Paid
                      </span>
                    )}
                    {job.status === 'rejected' && (
                      <span className="px-3 py-1 rounded-full text-xs font-semibold bg-rose-500/15 text-rose-300 border border-rose-500/30">
                        Rejected
                      </span>
                    )}
                  </div>
                </div>

                {/* Instructions & Links */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="space-y-2 bg-slate-950 p-4 rounded-2xl border border-slate-800">
                    <span className="text-slate-400 font-semibold uppercase tracking-wider text-[10px]">
                      Job Instructions & Deliverable Scope
                    </span>
                    <p className="text-slate-300 leading-relaxed">{job.description}</p>

                    <div className="pt-2 flex flex-wrap items-center gap-3">
                      <a
                        href={job.raw_footage_url}
                        target="_blank"
                        rel="noreferrer"
                        className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1 underline font-semibold"
                      >
                        <Film className="w-3.5 h-3.5" />
                        <span>Open Raw Footage / Assets Folder</span>
                      </a>

                      {job.reference_video_url && (
                        <a
                          href={job.reference_video_url}
                          target="_blank"
                          rel="noreferrer"
                          className="text-purple-400 hover:text-purple-300 flex items-center gap-1 underline"
                        >
                          <ExternalLink className="w-3.5 h-3.5" />
                          <span>Style Reference</span>
                        </a>
                      )}
                    </div>
                  </div>

                  {/* Financials & UTR Verification */}
                  <div className="space-y-3 bg-slate-950 p-4 rounded-2xl border border-slate-800">
                    <span className="text-slate-400 font-semibold uppercase tracking-wider text-[10px]">
                      Escrow Deposit & Platform Commission
                    </span>

                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800">
                        <span className="text-[10px] text-slate-500 block">Total Escrow</span>
                        <span className="text-sm font-bold font-mono text-white">₹{job.budget}</span>
                      </div>
                      <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800">
                        <span className="text-[10px] text-slate-500 block">VidQuest ({job.platform_fee_percent}%)</span>
                        <span className="text-sm font-bold font-mono text-indigo-400">₹{job.platform_fee_amount}</span>
                      </div>
                      <div className="bg-slate-900 p-2.5 rounded-xl border border-slate-800">
                        <span className="text-[10px] text-slate-500 block">Editor Payout</span>
                        <span className="text-sm font-bold font-mono text-emerald-400">₹{job.editor_net_payout}</span>
                      </div>
                    </div>

                    {/* UTR & Screenshot */}
                    <div className="flex items-center justify-between pt-1 border-t border-slate-800/80">
                      <div>
                        <span className="text-[10px] text-slate-500 block">12-Digit UTR:</span>
                        <div className="flex items-center gap-1 font-mono text-xs text-amber-300 font-bold">
                          <span>{job.utr_number}</span>
                          <button
                            onClick={() => handleCopy(job.utr_number, `utr-${job.id}`)}
                            className="p-1 hover:text-white"
                            title="Copy UTR"
                          >
                            {copiedId === `utr-${job.id}` ? (
                              <Check className="w-3 h-3 text-emerald-400" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                      </div>

                      {job.receipt_url && job.receipt_url !== 'ADMIN_TEST_BYPASS' && (
                        <button
                          onClick={() => setReceiptLightbox(job.receipt_url)}
                          className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-lg text-[11px] font-semibold flex items-center gap-1 border border-slate-700"
                        >
                          <Eye className="w-3 h-3" />
                          <span>View Receipt</span>
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Assigned Editor & Deliverable Information (if in progress or submitted) */}
                {(job.assigned_freelancer_email || job.deliverable_url) && (
                  <div className="p-4 rounded-2xl bg-indigo-950/30 border border-indigo-500/20 text-xs space-y-2">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4 text-indigo-400" />
                        <span className="text-slate-300">
                          Assigned Editor: <strong className="text-white">{job.assigned_freelancer_email}</strong>
                        </span>
                        {job.assigned_freelancer_upi && (
                          <span className="text-slate-400 font-mono text-[11px]">
                            (UPI: {job.assigned_freelancer_upi})
                          </span>
                        )}
                      </div>

                      {job.assigned_freelancer_upi && (
                        <button
                          onClick={() => handleCopy(job.assigned_freelancer_upi || '', `upi-${job.id}`)}
                          className="px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 text-[10px] font-mono flex items-center gap-1 hover:bg-indigo-500/30"
                        >
                          {copiedId === `upi-${job.id}` ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                          <span>Copy Editor UPI</span>
                        </button>
                      )}
                    </div>

                    {job.deliverable_url && (
                      <div className="pt-2 border-t border-indigo-500/20 flex flex-wrap items-center justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <Film className="w-4 h-4 text-cyan-400" />
                          <span className="text-slate-300">Deliverable Work:</span>
                          <a
                            href={job.deliverable_url}
                            target="_blank"
                            rel="noreferrer"
                            className="text-cyan-300 underline font-mono text-[11px]"
                          >
                            {job.deliverable_url}
                          </a>
                        </div>

                        {job.status === 'submitted' && (
                          <button
                            onClick={() => handleCompleteAndPay(job)}
                            disabled={isActionLoading}
                            className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center gap-1 shadow"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Verify Deliverable & Disburse ₹{job.editor_net_payout}</span>
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                )}

                {/* Action Bar */}
                <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleViewApplicants(job)}
                      className="px-3 py-1.5 rounded-xl bg-slate-950 hover:bg-slate-800 text-slate-300 text-xs font-semibold border border-slate-800 flex items-center gap-1.5"
                    >
                      <User className="w-3.5 h-3.5" />
                      <span>Applicants ({job.applicant_count || 0})</span>
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Launch Controls */}
                    {job.status === 'pending_super_admin' && (
                      <>
                        <button
                          onClick={() => handleReject(job.id!)}
                          disabled={isActionLoading}
                          className="px-3.5 py-1.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 text-xs font-semibold border border-rose-500/30 flex items-center gap-1"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          <span>Reject Job</span>
                        </button>

                        <button
                          onClick={() => handleApproveAndLaunch(job.id!)}
                          disabled={isActionLoading}
                          className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow flex items-center gap-1.5"
                        >
                          {isActionLoading ? (
                            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          ) : (
                            <ShieldCheck className="w-3.5 h-3.5" />
                          )}
                          <span>Verify UTR & Launch to Freelance Hub</span>
                        </button>
                      </>
                    )}

                    {/* Delete button */}
                    <button
                      onClick={() => handleDelete(job.id!)}
                      disabled={isActionLoading}
                      className="p-1.5 rounded-lg text-slate-500 hover:text-rose-400 hover:bg-rose-500/10"
                      title="Delete Job"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Lightbox for Payment Receipt */}
      {receiptLightbox && (
        <div className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4">
          <div className="relative max-w-xl w-full bg-slate-900 border border-slate-800 rounded-3xl p-4 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <span className="text-xs font-bold text-white">Payment Screenshot Receipt</span>
              <button
                onClick={() => setReceiptLightbox(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="max-h-[75vh] overflow-auto rounded-xl">
              <img
                src={receiptLightbox}
                alt="Receipt screenshot"
                className="w-full object-contain rounded-xl"
              />
            </div>
          </div>
        </div>
      )}

      {/* Inspect Applicants Modal */}
      {inspectingJob && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 max-w-2xl w-full max-h-[85vh] overflow-y-auto space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-white">Applicants for "{inspectingJob.title}"</h3>
                <p className="text-xs text-slate-400">Total Applicants: {applicants.length}</p>
              </div>
              <button
                onClick={() => setInspectingJob(null)}
                className="text-slate-400 hover:text-white text-xs font-semibold px-2 py-1 bg-slate-800 rounded-lg"
              >
                Close
              </button>
            </div>

            {loadingApplicants ? (
              <div className="py-8 text-center text-slate-400 text-xs flex items-center justify-center gap-2">
                <RefreshCw className="w-4 h-4 animate-spin text-indigo-400" />
                <span>Loading applicants...</span>
              </div>
            ) : applicants.length === 0 ? (
              <div className="py-8 text-center text-slate-400 text-xs">
                No editors have applied for this job yet.
              </div>
            ) : (
              <div className="space-y-3">
                {applicants.map((app) => (
                  <div
                    key={app.id}
                    className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <div className="text-xs font-bold text-white">{app.freelancer_email}</div>
                      <span className="text-[10px] font-mono text-slate-400">UPI: {app.upi_id}</span>
                    </div>
                    <p className="text-xs text-slate-300">"{app.pitch}"</p>
                    <div className="flex items-center justify-between text-xs pt-1">
                      <a
                        href={app.portfolio_link}
                        target="_blank"
                        rel="noreferrer"
                        className="text-indigo-400 hover:text-indigo-300 flex items-center gap-1 underline"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>Portfolio Link</span>
                      </a>
                      <span className="text-[10px] text-slate-500">
                        Status: <strong className="text-slate-300">{app.status}</strong>
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
