import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { Navbar } from './components/Navbar';
import { FeedView } from './components/FeedView';
import { CreatorStudio } from './components/CreatorStudio';
import { FreelanceHub } from './components/FreelanceHub';
import { AdminDashboard } from './components/AdminDashboard';
import { AuthModal } from './components/AuthModal';
import { WithdrawModal } from './components/WithdrawModal';
import { ShieldCheck, Video, Coins, Award } from 'lucide-react';

function MainApp() {
  const { currentUser, isSuperAdmin } = useAuth();
  const [currentTab, setCurrentTab] = useState<'feed' | 'creator' | 'freelance' | 'admin' | 'withdrawals'>('feed');
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isWithdrawModalOpen, setIsWithdrawModalOpen] = useState(false);

  // Check URL path or hash to support /admin and /freelance routes
  useEffect(() => {
    const path = window.location.pathname;
    const hash = window.location.hash;
    if (path.includes('/admin') || hash === '#admin') {
      setCurrentTab('admin');
    } else if (path.includes('/freelance') || hash === '#freelance') {
      setCurrentTab('freelance');
    }
  }, []);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      {/* Navigation Header */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        openAuthModal={() => setIsAuthModalOpen(true)}
        openWithdrawModal={() => setIsWithdrawModalOpen(true)}
      />

      {/* Main View Area */}
      <main className="flex-1 pb-16">
        {currentTab === 'feed' && (
          <FeedView
            onGoToCreatorStudio={() => setCurrentTab('creator')}
            openAuthModal={() => setIsAuthModalOpen(true)}
          />
        )}

        {currentTab === 'creator' && (
          <CreatorStudio openAuthModal={() => setIsAuthModalOpen(true)} />
        )}

        {currentTab === 'freelance' && (
          <FreelanceHub openAuthModal={() => setIsAuthModalOpen(true)} />
        )}

        {currentTab === 'admin' && (
          <AdminDashboard />
        )}

        {currentTab === 'withdrawals' && (
          <div className="max-w-4xl mx-auto px-4 py-8">
            <div className="bg-slate-900 border border-slate-800 rounded-3xl p-8 text-center space-y-4">
              <div className="w-14 h-14 rounded-2xl bg-amber-500/10 text-amber-400 flex items-center justify-center mx-auto border border-amber-500/20">
                <Coins className="w-7 h-7" />
              </div>
              <h2 className="text-2xl font-bold text-white">VidQuest Escrow Payouts</h2>
              <p className="text-sm text-slate-400 max-w-md mx-auto">
                Users can withdraw their quiz earnings directly to their bank account via UPI.
                Select between Tier 1 (₹40), Tier 2 (₹50), and Tier 3 (₹100).
              </p>
              <div className="pt-2">
                <button
                  id="open-payout-modal-btn"
                  onClick={() => setIsWithdrawModalOpen(true)}
                  className="px-6 py-3 bg-gradient-to-r from-amber-500 to-rose-600 hover:from-amber-400 hover:to-rose-500 text-white font-bold text-sm rounded-xl shadow-lg transition-all"
                >
                  Open Payout Terminal
                </button>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 py-6 bg-slate-950 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-300">VidQuest</span>
            <span>• Launch Version Phase 1</span>
          </div>
          <div className="flex items-center gap-4 text-slate-400">
            <span>Manual UPI Escrow System</span>
          </div>
        </div>
      </footer>

      {/* Global Modals */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />

      <WithdrawModal
        isOpen={isWithdrawModalOpen}
        onClose={() => setIsWithdrawModalOpen(false)}
        openAuthModal={() => {
          setIsWithdrawModalOpen(false);
          setIsAuthModalOpen(true);
        }}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
