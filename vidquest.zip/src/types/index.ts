export type UserRole = 'user' | 'pending_creator' | 'approved_creator' | 'super_admin';

export interface UserDoc {
  uid: string;
  email: string;
  role: UserRole;
  wallet_balance: number;
  escrow_locked: number;
  completed_quizzes: string[]; // List of campaign/video IDs
  displayName?: string;
  photoURL?: string;
  createdAt?: string;
}

export type ApplicationStatus = 'pending' | 'approved' | 'rejected';

export interface CreatorApplication {
  id?: string;
  uid: string;
  email?: string;
  channel_link: string;
  channel_name?: string;
  subscriber_count?: string;
  description?: string;
  status: ApplicationStatus;
  createdAt: string;
}

export type CampaignStatus = 'pending_verification' | 'active' | 'completed' | 'rejected';

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswerIndex: number;
}

export interface Campaign {
  id?: string;
  creator_uid: string;
  creator_email?: string;
  creator_name?: string;
  title?: string;
  youtube_url: string;
  video_id?: string;
  budget: number;
  target_views?: number;
  views_count?: number;
  sender_upi_or_phone?: string;
  utr_number: string;
  receipt_url: string;
  status: CampaignStatus;
  reward_coins?: number;
  is_test?: boolean;
  is_test_mode?: boolean;
  teaser_url?: string;
  teaser_duration?: number;
  quiz_type?: 'manual' | 'ai_generated' | 'none';
  has_quiz?: boolean;
  ai_quiz_fee?: number;
  custom_questions?: QuizQuestion[];
  super_admin_accepted?: boolean;
  super_admin_decision_reason?: string;
  createdAt: string;
}

export type WithdrawalTier = 40 | 50 | 100;
export type WithdrawalStatus = 'pending' | 'paid' | 'rejected';
export type WithdrawalCategory = 'recharge' | 'google_play' | 'upi';

export interface Withdrawal {
  id?: string;
  uid: string;
  email?: string;
  amount: number;
  method: string;
  payment_details: string;
  category?: WithdrawalCategory;
  sim_number?: string;
  sim_operator?: string;
  google_play_email?: string;
  upi_id?: string;
  screenshot_url?: string;
  status: WithdrawalStatus;
  createdAt: string;
  paidAt?: string;
}

export interface EscrowSettings {
  upi_id: string;
  payee_name: string;
  phone_number?: string;
  qr_image_url?: string;
  updatedAt?: string;
  updatedBy?: string;
}

export type FreelanceJobCategory =
  | 'video_editing'
  | 'shorts_reels'
  | 'thumbnail_design'
  | 'audio_sound'
  | 'vfx_motion'
  | 'scriptwriting';

export type FreelanceJobStatus =
  | 'pending_super_admin'
  | 'open'
  | 'in_progress'
  | 'submitted'
  | 'completed'
  | 'rejected';

export interface MarketRateBenchmark {
  category: FreelanceJobCategory;
  name: string;
  minRecommended: number;
  marketAverage: number;
  description: string;
}

export const MARKET_RATE_BENCHMARKS: Record<FreelanceJobCategory, MarketRateBenchmark> = {
  video_editing: {
    category: 'video_editing',
    name: 'YouTube Full Video Editing',
    minRecommended: 800,
    marketAverage: 1500,
    description: 'Pacing, cutaways, B-roll placement, sound effects & color correction (8-15 mins)'
  },
  shorts_reels: {
    category: 'shorts_reels',
    name: 'Shorts & Reels Editing',
    minRecommended: 250,
    marketAverage: 500,
    description: 'Fast captions, punchy zoom-ins, dynamic sound effects & 3-sec retention hooks'
  },
  thumbnail_design: {
    category: 'thumbnail_design',
    name: 'CTR Thumbnail Design',
    minRecommended: 150,
    marketAverage: 350,
    description: 'Bold expressive imagery, readable high-contrast text & click optimization'
  },
  audio_sound: {
    category: 'audio_sound',
    name: 'Audio Cleanup & Mixing',
    minRecommended: 300,
    marketAverage: 600,
    description: 'Vocal noise removal, compression, EQ tuning & background music leveling'
  },
  vfx_motion: {
    category: 'vfx_motion',
    name: 'VFX & Motion Graphics',
    minRecommended: 1000,
    marketAverage: 2000,
    description: 'Custom intro animation, lower thirds, 3D title sequences & visual motion'
  },
  scriptwriting: {
    category: 'scriptwriting',
    name: 'Scriptwriting & Storyboard',
    minRecommended: 400,
    marketAverage: 800,
    description: 'Researched outline, audience retention hooks, narration flow & call-to-actions'
  }
};

export function calculatePlatformFee(budget: number): {
  feePercent: number;
  feeAmount: number;
  editorNetPayout: number;
} {
  // If budget < 1500: 15% platform commission (Editor receives 85%)
  // If budget >= 1500: 10% platform commission (Editor receives 90%)
  const feePercent = budget < 1500 ? 15 : 10;
  const feeAmount = Math.round((budget * feePercent) / 100);
  const editorNetPayout = Math.max(0, budget - feeAmount);
  return { feePercent, feeAmount, editorNetPayout };
}

export interface FreelanceJob {
  id?: string;
  creator_uid: string;
  creator_email: string;
  creator_name?: string;
  title: string;
  category: FreelanceJobCategory;
  description: string;
  raw_footage_url: string;      // Video assets/link that needs editing
  reference_video_url?: string; // Style reference video
  turnaround_days: number;      // Turnaround delivery expectation
  budget: number;               // Creator offered budget (INR)
  platform_fee_percent: number; // 10% or 15%
  platform_fee_amount: number;  // Company charge
  editor_net_payout: number;    // Take-home amount for editor
  utr_number: string;
  receipt_url: string;
  status: FreelanceJobStatus;
  applicant_count?: number;
  assigned_freelancer_uid?: string;
  assigned_freelancer_email?: string;
  assigned_freelancer_name?: string;
  assigned_freelancer_upi?: string;
  deliverable_url?: string;
  deliverable_notes?: string;
  super_admin_notes?: string;
  is_test_mode?: boolean;
  createdAt: string;
  completedAt?: string;
}

export interface FreelanceApplication {
  id?: string;
  job_id: string;
  job_title?: string;
  freelancer_uid: string;
  freelancer_email: string;
  freelancer_name?: string;
  portfolio_link: string;
  pitch: string;
  turnaround_commitment?: string;
  upi_id: string;
  status: 'pending' | 'accepted' | 'rejected' | 'work_submitted';
  work_deliverable_url?: string;
  work_notes?: string;
  submittedAt?: string;
  createdAt: string;
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}
