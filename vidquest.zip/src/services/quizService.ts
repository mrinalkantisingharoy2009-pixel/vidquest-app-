import { db, handleFirestoreError } from '../lib/firebase';
import { doc, runTransaction } from 'firebase/firestore';
import { QuizQuestion, OperationType } from '../types';

export interface QuizEvaluationResult {
  passed: boolean;
  score: number;
  totalQuestions: number;
  coinsAwarded: number;
  message: string;
}

/**
 * Standard question bank mapped to video IDs or default general engagement questions
 */
export const DEFAULT_QUIZ_QUESTIONS: Record<string, QuizQuestion[]> = {
  default: [
    {
      id: 'q1',
      question: 'What is the primary topic or message emphasized in this video?',
      options: [
        'Core demonstration and step-by-step walkthrough',
        'Unrelated background noise',
        'Generic stock footage',
        'End credits preview only'
      ],
      correctAnswerIndex: 0
    },
    {
      id: 'q2',
      question: 'Which key benefit or insight was highlighted by the creator?',
      options: [
        'Higher efficiency and improved user results',
        'Delaying project deployment',
        'Increasing unnecessary costs',
        'Ignoring user feedback'
      ],
      correctAnswerIndex: 0
    },
    {
      id: 'q3',
      question: 'What call to action was recommended in the presentation?',
      options: [
        'Review the key steps and verify implementation details',
        'Turn off the device immediately',
        'Delete all account history',
        'Ignore best practices'
      ],
      correctAnswerIndex: 0
    },
    {
      id: 'q4',
      question: 'How did the creator validate the effectiveness of the solution?',
      options: [
        'Through real-time metrics and practical evidence',
        'By guessing without testing',
        'By avoiding real examples',
        'By leaving questions unanswered'
      ],
      correctAnswerIndex: 0
    },
    {
      id: 'q5',
      question: 'What final takeaway did the creator conclude with?',
      options: [
        'Consistent application leads to scalable success',
        'Give up after first error',
        'Avoid taking notes or learning',
        'Never test before deploying'
      ],
      correctAnswerIndex: 0
    }
  ]
};

export function getQuizForCampaign(videoId: string, customQuestions?: QuizQuestion[]): QuizQuestion[] {
  if (customQuestions && customQuestions.length === 5) {
    return customQuestions;
  }
  return DEFAULT_QUIZ_QUESTIONS[videoId] || DEFAULT_QUIZ_QUESTIONS.default;
}

/**
 * Server/Atomic Evaluation and Transaction:
 * - Checks answers against true answer keys
 * - Runs an atomic Firestore transaction on the user document
 * - Verifies videoId has NOT already been completed
 * - If score >= 4, increments wallet_balance and appends videoId to completed_quizzes
 */
export async function evaluateAndCreditQuiz(
  userId: string,
  videoId: string,
  userAnswers: number[],
  questions: QuizQuestion[],
  rewardCoins = 50
): Promise<QuizEvaluationResult> {
  if (userAnswers.length !== 5) {
    throw new Error('All 5 questions must be answered');
  }

  // Calculate score
  let score = 0;
  for (let i = 0; i < 5; i++) {
    if (userAnswers[i] === questions[i].correctAnswerIndex) {
      score += 1;
    }
  }

  const passed = score >= 4;
  const userRef = doc(db, 'users', userId);

  try {
    const result = await runTransaction(db, async (transaction) => {
      const userSnap = await transaction.get(userRef);
      if (!userSnap.exists()) {
        throw new Error('User profile record does not exist');
      }

      const userData = userSnap.data();
      const completedList: string[] = userData.completed_quizzes || [];

      if (completedList.includes(videoId)) {
        throw new Error(rewardCoins > 0 ? 'You have already claimed rewards for this video quiz' : 'You have already completed this test quiz');
      }

      if (passed) {
        const newBalance = (userData.wallet_balance || 0) + (rewardCoins > 0 ? rewardCoins : 0);
        const newCompleted = [...completedList, videoId];

        transaction.update(userRef, {
          wallet_balance: newBalance,
          completed_quizzes: newCompleted
        });

        return {
          passed: true,
          score,
          totalQuestions: 5,
          coinsAwarded: rewardCoins > 0 ? rewardCoins : 0,
          message: rewardCoins > 0
            ? `Congratulations! You scored ${score}/5 and earned ₹${rewardCoins} coins!`
            : `Great job! You scored ${score}/5 on this test quiz. (Only for test purposes — no money or coins awarded).`
        };
      } else {
        return {
          passed: false,
          score,
          totalQuestions: 5,
          coinsAwarded: 0,
          message: `You scored ${score}/5. A minimum of 4/5 correct answers is required to claim the reward. Try again!`
        };
      }
    });

    return result;
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `users/${userId}`);
  }
}

/**
 * Direct reward claim for campaigns without a comprehension quiz (direct watch & earn)
 */
export async function creditWatchRewardDirectly(
  userId: string,
  videoId: string,
  rewardCoins = 50
): Promise<QuizEvaluationResult> {
  const userRef = doc(db, 'users', userId);

  try {
    const result = await runTransaction(db, async (transaction) => {
      const userSnap = await transaction.get(userRef);
      if (!userSnap.exists()) {
        throw new Error('User profile record does not exist');
      }

      const userData = userSnap.data();
      const completedList: string[] = userData.completed_quizzes || [];

      if (completedList.includes(videoId)) {
        throw new Error(rewardCoins > 0 ? 'You have already claimed rewards for watching this video' : 'You have already claimed this test video');
      }

      const newBalance = (userData.wallet_balance || 0) + (rewardCoins > 0 ? rewardCoins : 0);
      const newCompleted = [...completedList, videoId];

      transaction.update(userRef, {
        wallet_balance: newBalance,
        completed_quizzes: newCompleted
      });

      return {
        passed: true,
        score: 5,
        totalQuestions: 0,
        coinsAwarded: rewardCoins > 0 ? rewardCoins : 0,
        message: rewardCoins > 0
          ? `Verified! You claimed ₹${rewardCoins} coins for watching this video!`
          : `Watched! (Test video — no money or coins awarded).`
      };
    });

    return result;
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `users/${userId}`);
  }
}
