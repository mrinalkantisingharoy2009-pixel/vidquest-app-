import { db, handleFirestoreError } from '../lib/firebase';
import {
  collection,
  doc,
  setDoc,
  getDocs,
  query,
  where,
  runTransaction
} from 'firebase/firestore';
import { Withdrawal, OperationType, WithdrawalCategory } from '../types';

export interface WithdrawalMetadata {
  category?: WithdrawalCategory;
  sim_number?: string;
  sim_operator?: string;
  google_play_email?: string;
  upi_id?: string;
  screenshot_url?: string;
}

/**
 * User requests a withdrawal for one of the valid options:
 * - ₹40: Mobile SIM Recharge
 * - ₹50: Mobile SIM Recharge or Google Play Redeem Code
 * - ₹100+: Custom amount UPI direct transfer (provided wallet_balance >= amount)
 * Executes an atomic transaction locking the coins from wallet_balance into escrow_locked
 */
export async function requestWithdrawal(
  uid: string,
  email: string,
  amount: number,
  method: string,
  paymentDetails: string,
  metadata?: WithdrawalMetadata
): Promise<string> {
  const withdrawalId = `wth_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const userRef = doc(db, 'users', uid);
  const withdrawalRef = doc(db, 'withdrawals', withdrawalId);

  try {
    await runTransaction(db, async (transaction) => {
      const userSnap = await transaction.get(userRef);
      if (!userSnap.exists()) {
        throw new Error('User profile does not exist');
      }

      const userData = userSnap.data();
      const currentBalance = userData.wallet_balance || 0;
      const currentEscrow = userData.escrow_locked || 0;

      if (currentBalance < amount) {
        throw new Error(`Insufficient balance. You have ₹${currentBalance}, but ₹${amount} is required.`);
      }

      // 1. Move funds from wallet_balance to escrow_locked
      transaction.update(userRef, {
        wallet_balance: currentBalance - amount,
        escrow_locked: currentEscrow + amount
      });

      // 2. Create withdrawal record
      const withdrawalData: Withdrawal = {
        id: withdrawalId,
        uid,
        email,
        amount,
        method: method || 'UPI',
        payment_details: paymentDetails,
        status: 'pending',
        createdAt: new Date().toISOString(),
        ...(metadata?.category && { category: metadata.category }),
        ...(metadata?.sim_number && { sim_number: metadata.sim_number }),
        ...(metadata?.sim_operator && { sim_operator: metadata.sim_operator }),
        ...(metadata?.google_play_email && { google_play_email: metadata.google_play_email }),
        ...(metadata?.upi_id && { upi_id: metadata.upi_id }),
        ...(metadata?.screenshot_url && { screenshot_url: metadata.screenshot_url })
      };

      transaction.set(withdrawalRef, withdrawalData);
    });

    return withdrawalId;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `withdrawals/${withdrawalId}`);
  }
}

/**
 * Fetch withdrawals for a specific user
 */
export async function getUserWithdrawals(uid: string): Promise<Withdrawal[]> {
  try {
    const q = query(
      collection(db, 'withdrawals'),
      where('uid', '==', uid)
    );
    const snap = await getDocs(q);
    const list: Withdrawal[] = [];
    snap.forEach((d) => {
      list.push({ id: d.id, ...d.data() } as Withdrawal);
    });
    return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'withdrawals');
  }
}
