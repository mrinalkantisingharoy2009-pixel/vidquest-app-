import { db, handleFirestoreError } from '../lib/firebase';
import {
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
  updateDoc,
  deleteDoc,
  increment
} from 'firebase/firestore';
import {
  FreelanceJob,
  FreelanceApplication,
  OperationType,
  calculatePlatformFee
} from '../types';

/**
 * Creator creates a new freelance editing job
 */
export async function createFreelanceJob(
  jobData: Omit<FreelanceJob, 'id' | 'createdAt' | 'platform_fee_percent' | 'platform_fee_amount' | 'editor_net_payout'>
): Promise<string> {
  const jobId = `job_${jobData.creator_uid}_${Date.now()}`;
  const { feePercent, feeAmount, editorNetPayout } = calculatePlatformFee(jobData.budget);

  const fullJob: FreelanceJob = {
    ...jobData,
    id: jobId,
    platform_fee_percent: feePercent,
    platform_fee_amount: feeAmount,
    editor_net_payout: editorNetPayout,
    applicant_count: 0,
    createdAt: new Date().toISOString()
  };

  try {
    const jobRef = doc(db, 'freelance_jobs', jobId);
    await setDoc(jobRef, fullJob);
    return jobId;
  } catch (error) {
    throw new Error(handleFirestoreError(error, OperationType.CREATE, `freelance_jobs/${jobId}`));
  }
}

/**
 * Get open freelance jobs launched by Super Admin for the Freelance Hub
 */
export async function getOpenFreelanceJobs(): Promise<FreelanceJob[]> {
  try {
    const q = query(
      collection(db, 'freelance_jobs'),
      where('status', '==', 'open'),
      orderBy('createdAt', 'desc')
    );
    const snapshot = await getDocs(q);
    return snapshot.docs.map((docSnap) => ({
      id: docSnap.id,
      ...docSnap.data()
    })) as FreelanceJob[];
  } catch (error) {
    // Fallback without orderBy if index is building
    try {
      const qFallback = query(
        collection(db, 'freelance_jobs'),
        where('status', '==', 'open')
      );
      const snapshot = await getDocs(qFallback);
      const list = snapshot.docs.map((docSnap) => ({
        id: docSnap.id,
        ...docSnap.data()
      })) as FreelanceJob[];
      return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    } catch (fallbackError) {
      throw new Error(handleFirestoreError(fallbackError, OperationType.LIST, 'freelance_jobs'));
    }
  }
}

/**
 * Get all freelance jobs posted by a specific creator
 */
export async function getCreatorFreelanceJobs(creatorUid: string): Promise<FreelanceJob[]> {
  try {
    const q = query(
      collection(db, 'freelance_jobs'),
      where('creator_uid', '==', creatorUid)
    );
    const snapshot = await getDocs(q);
    const list = snapshot.docs.map((docSnap) => ({
      id: docSnap.id,
      ...docSnap.data()
    })) as FreelanceJob[];
    return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  } catch (error) {
    throw new Error(handleFirestoreError(error, OperationType.LIST, 'freelance_jobs'));
  }
}

/**
 * Get all freelance jobs for Super Admin desk
 */
export async function getAllFreelanceJobs(): Promise<FreelanceJob[]> {
  try {
    const snapshot = await getDocs(collection(db, 'freelance_jobs'));
    const list = snapshot.docs.map((docSnap) => ({
      id: docSnap.id,
      ...docSnap.data()
    })) as FreelanceJob[];
    return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  } catch (error) {
    throw new Error(handleFirestoreError(error, OperationType.LIST, 'freelance_jobs'));
  }
}

/**
 * Super Admin verifies payment and launches job to the Freelance Hub
 */
export async function approveAndLaunchFreelanceJob(jobId: string, notes?: string): Promise<void> {
  try {
    const jobRef = doc(db, 'freelance_jobs', jobId);
    await updateDoc(jobRef, {
      status: 'open',
      super_admin_notes: notes || 'Verified & Launched to Freelance Marketplace'
    });
  } catch (error) {
    throw new Error(handleFirestoreError(error, OperationType.UPDATE, `freelance_jobs/${jobId}`));
  }
}

/**
 * Super Admin rejects freelance job
 */
export async function rejectFreelanceJob(jobId: string, reason: string): Promise<void> {
  try {
    const jobRef = doc(db, 'freelance_jobs', jobId);
    await updateDoc(jobRef, {
      status: 'rejected',
      super_admin_notes: reason
    });
  } catch (error) {
    throw new Error(handleFirestoreError(error, OperationType.UPDATE, `freelance_jobs/${jobId}`));
  }
}

/**
 * Delete a freelance job
 */
export async function deleteFreelanceJob(jobId: string): Promise<void> {
  try {
    const jobRef = doc(db, 'freelance_jobs', jobId);
    await deleteDoc(jobRef);
  } catch (error) {
    throw new Error(handleFirestoreError(error, OperationType.DELETE, `freelance_jobs/${jobId}`));
  }
}

/**
 * Student / Editor applies for an open freelance job
 */
export async function applyForFreelanceJob(
  appData: Omit<FreelanceApplication, 'id' | 'createdAt' | 'status'>
): Promise<string> {
  const appId = `app_${appData.freelancer_uid}_${appData.job_id}_${Date.now()}`;
  const fullApp: FreelanceApplication = {
    ...appData,
    id: appId,
    status: 'pending',
    createdAt: new Date().toISOString()
  };

  try {
    const appRef = doc(db, 'freelance_applications', appId);
    await setDoc(appRef, fullApp);

    // Increment applicant count on job
    try {
      const jobRef = doc(db, 'freelance_jobs', appData.job_id);
      await updateDoc(jobRef, {
        applicant_count: increment(1)
      });
    } catch {
      // Non-critical
    }

    return appId;
  } catch (error) {
    throw new Error(handleFirestoreError(error, OperationType.CREATE, `freelance_applications/${appId}`));
  }
}

/**
 * Get applications for a specific job (for Creator and Super Admin)
 */
export async function getJobApplications(jobId: string): Promise<FreelanceApplication[]> {
  try {
    const q = query(
      collection(db, 'freelance_applications'),
      where('job_id', '==', jobId)
    );
    const snapshot = await getDocs(q);
    const list = snapshot.docs.map((docSnap) => ({
      id: docSnap.id,
      ...docSnap.data()
    })) as FreelanceApplication[];
    return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  } catch (error) {
    throw new Error(handleFirestoreError(error, OperationType.LIST, 'freelance_applications'));
  }
}

/**
 * Get applications made by the current user
 */
export async function getMyFreelanceApplications(freelancerUid: string): Promise<FreelanceApplication[]> {
  try {
    const q = query(
      collection(db, 'freelance_applications'),
      where('freelancer_uid', '==', freelancerUid)
    );
    const snapshot = await getDocs(q);
    const list = snapshot.docs.map((docSnap) => ({
      id: docSnap.id,
      ...docSnap.data()
    })) as FreelanceApplication[];
    return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  } catch (error) {
    throw new Error(handleFirestoreError(error, OperationType.LIST, 'freelance_applications'));
  }
}

/**
 * Creator or Super Admin selects an editor for the job
 */
export async function assignFreelancerToJob(
  jobId: string,
  app: FreelanceApplication
): Promise<void> {
  try {
    const jobRef = doc(db, 'freelance_jobs', jobId);
    await updateDoc(jobRef, {
      status: 'in_progress',
      assigned_freelancer_uid: app.freelancer_uid,
      assigned_freelancer_email: app.freelancer_email,
      assigned_freelancer_name: app.freelancer_name || 'Freelance Editor',
      assigned_freelancer_upi: app.upi_id
    });

    if (app.id) {
      const appRef = doc(db, 'freelance_applications', app.id);
      await updateDoc(appRef, {
        status: 'accepted'
      });
    }
  } catch (error) {
    throw new Error(handleFirestoreError(error, OperationType.UPDATE, `freelance_jobs/${jobId}`));
  }
}

/**
 * Assigned editor submits completed work link (e.g. Google Drive, WeTransfer, YouTube unlisted)
 */
export async function submitJobDeliverable(
  jobId: string,
  applicationId: string,
  deliverableUrl: string,
  deliverableNotes?: string
): Promise<void> {
  try {
    const jobRef = doc(db, 'freelance_jobs', jobId);
    await updateDoc(jobRef, {
      status: 'submitted',
      deliverable_url: deliverableUrl,
      deliverable_notes: deliverableNotes || ''
    });

    if (applicationId) {
      const appRef = doc(db, 'freelance_applications', applicationId);
      await updateDoc(appRef, {
        status: 'work_submitted',
        work_deliverable_url: deliverableUrl,
        work_notes: deliverableNotes || '',
        submittedAt: new Date().toISOString()
      });
    }
  } catch (error) {
    throw new Error(handleFirestoreError(error, OperationType.UPDATE, `freelance_jobs/${jobId}`));
  }
}

/**
 * Super Admin marks job completed and releases payout to editor
 */
export async function markJobCompletedAndPaid(jobId: string): Promise<void> {
  try {
    const jobRef = doc(db, 'freelance_jobs', jobId);
    await updateDoc(jobRef, {
      status: 'completed',
      completedAt: new Date().toISOString()
    });
  } catch (error) {
    throw new Error(handleFirestoreError(error, OperationType.UPDATE, `freelance_jobs/${jobId}`));
  }
}
