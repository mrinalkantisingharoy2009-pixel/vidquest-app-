import { db, handleFirestoreError } from '../lib/firebase';
import {
  collection,
  doc,
  setDoc,
  getDocs,
  query,
  where,
  orderBy,
  updateDoc,
  deleteDoc,
  increment
} from 'firebase/firestore';
import { Campaign, CreatorApplication, OperationType } from '../types';

/**
 * Extracts YouTube Video ID from various URL formats
 */
export function extractYouTubeId(url: string): string | null {
  if (!url) return null;
  const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
  const match = url.match(regExp);
  return (match && match[2].length === 11) ? match[2] : null;
}

/**
 * User submits creator application
 */
export async function submitCreatorApplication(
  uid: string,
  email: string,
  channelLink: string,
  channelName?: string,
  subscriberCount?: string,
  description?: string
): Promise<string> {
  const applicationId = `app_${uid}_${Date.now()}`;
  const appData: CreatorApplication = {
    id: applicationId,
    uid,
    email,
    channel_link: channelLink,
    channel_name: channelName || '',
    subscriber_count: subscriberCount || '',
    description: description || '',
    status: 'pending',
    createdAt: new Date().toISOString()
  };

  try {
    // 1. Create application doc
    await setDoc(doc(db, 'creator_applications', applicationId), appData);

    // 2. Set user role to pending_creator
    await updateDoc(doc(db, 'users', uid), {
      role: 'pending_creator'
    });

    return applicationId;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `creator_applications/${applicationId}`);
  }
}

/**
 * Approved Creator submits a new campaign with UTR number and receipt screenshot
 */
export async function createCampaign(campaign: Omit<Campaign, 'id' | 'createdAt' | 'status'> & { status?: Campaign['status'] }): Promise<string> {
  const campaignId = `camp_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const videoId = extractYouTubeId(campaign.youtube_url) || 'dQw4w9WgXcQ';

  const newCampaign: Campaign = {
    ...campaign,
    id: campaignId,
    video_id: videoId,
    status: campaign.status || 'pending_verification',
    createdAt: new Date().toISOString()
  };

  try {
    await setDoc(doc(db, 'campaigns', campaignId), newCampaign);
    return campaignId;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `campaigns/${campaignId}`);
  }
}

/**
 * Fetch active campaigns for public user feed
 */
export async function getActiveCampaigns(): Promise<Campaign[]> {
  try {
    const q = query(
      collection(db, 'campaigns'),
      where('status', '==', 'active')
    );
    const snap = await getDocs(q);
    const campaigns: Campaign[] = [];
    snap.forEach((d) => {
      campaigns.push({ id: d.id, ...d.data() } as Campaign);
    });
    // Sort client-side by createdAt descending
    return campaigns.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'campaigns');
  }
}

/**
 * Fetch campaigns created by a specific creator
 */
export async function getCreatorCampaigns(creatorUid: string): Promise<Campaign[]> {
  try {
    const q = query(
      collection(db, 'campaigns'),
      where('creator_uid', '==', creatorUid)
    );
    const snap = await getDocs(q);
    const campaigns: Campaign[] = [];
    snap.forEach((d) => {
      campaigns.push({ id: d.id, ...d.data() } as Campaign);
    });
    return campaigns.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'campaigns');
  }
}

/**
 * Delete a campaign (Super Admin can delete any; Creators can delete their own)
 */
export async function deleteCampaign(campaignId: string): Promise<void> {
  const campRef = doc(db, 'campaigns', campaignId);
  try {
    await deleteDoc(campRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `campaigns/${campaignId}`);
  }
}

/**
 * Increment campaign view count after quiz completion and check if target reached
 */
export async function incrementCampaignView(campaignId: string, currentViews?: number, targetViews?: number): Promise<void> {
  const campRef = doc(db, 'campaigns', campaignId);
  try {
    const nextViews = (currentViews || 0) + 1;
    const isCompleted = (targetViews || 0) > 0 && nextViews >= (targetViews || 0);

    await updateDoc(campRef, {
      views_count: increment(1),
      ...(isCompleted ? { status: 'completed' } : {})
    });
  } catch (error) {
    console.warn(`Could not increment view count for campaign ${campaignId}:`, error);
  }
}

