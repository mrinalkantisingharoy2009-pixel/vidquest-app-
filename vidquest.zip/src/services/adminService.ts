import { db, handleFirestoreError } from '../lib/firebase';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  setDoc,
  updateDoc,
  runTransaction
} from 'firebase/firestore';
import { CreatorApplication, Campaign, Withdrawal, EscrowSettings, OperationType } from '../types';

export const DEFAULT_ESCROW_SETTINGS: EscrowSettings = {
  upi_id: 'mrinalkantisingharoy2009@okhdfcbank',
  payee_name: 'Mrinal Kanti Singha Roy',
  phone_number: '',
  qr_image_url: '',
};

/**
 * Get current platform Escrow Settings (Super Admin UPI details & QR screenshot)
 */
export async function getEscrowSettings(): Promise<EscrowSettings> {
  try {
    const docRef = doc(db, 'system_settings', 'escrow');
    const snap = await getDoc(docRef);
    if (snap.exists()) {
      return { ...DEFAULT_ESCROW_SETTINGS, ...snap.data() } as EscrowSettings;
    }
    return DEFAULT_ESCROW_SETTINGS;
  } catch (error) {
    console.warn('Failed to load escrow settings, falling back to default:', error);
    return DEFAULT_ESCROW_SETTINGS;
  }
}

/**
 * Super Admin: Save updated Escrow Settings (QR screenshot, UPI ID, Phone Number, Payee Name)
 */
export async function saveEscrowSettings(settings: Partial<EscrowSettings>, adminEmail: string): Promise<void> {
  const docRef = doc(db, 'system_settings', 'escrow');
  try {
    await setDoc(
      docRef,
      {
        ...settings,
        updatedAt: new Date().toISOString(),
        updatedBy: adminEmail
      },
      { merge: true }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'system_settings/escrow');
  }
}

/**
 * Super Admin: Get all creator applications
 */
export async function getAllCreatorApplications(): Promise<CreatorApplication[]> {
  try {
    const snap = await getDocs(collection(db, 'creator_applications'));
    const list: CreatorApplication[] = [];
    snap.forEach((d) => {
      list.push({ id: d.id, ...d.data() } as CreatorApplication);
    });
    return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'creator_applications');
  }
}

/**
 * Super Admin: Approve creator application and promote user to 'approved_creator'
 */
export async function approveCreatorApplication(applicationId: string, applicantUid: string): Promise<void> {
  const appRef = doc(db, 'creator_applications', applicationId);
  const userRef = doc(db, 'users', applicantUid);

  try {
    await runTransaction(db, async (t) => {
      t.update(appRef, { status: 'approved' });
      t.update(userRef, { role: 'approved_creator' });
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `creator_applications/${applicationId}`);
  }
}

/**
 * Super Admin: Reject creator application
 */
export async function rejectCreatorApplication(applicationId: string, applicantUid: string): Promise<void> {
  const appRef = doc(db, 'creator_applications', applicationId);
  const userRef = doc(db, 'users', applicantUid);

  try {
    await runTransaction(db, async (t) => {
      t.update(appRef, { status: 'rejected' });
      t.update(userRef, { role: 'user' });
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `creator_applications/${applicationId}`);
  }
}

/**
 * Super Admin: Get all campaigns for verification desk
 */
export async function getAllCampaigns(): Promise<Campaign[]> {
  try {
    const snap = await getDocs(collection(db, 'campaigns'));
    const list: Campaign[] = [];
    snap.forEach((d) => {
      list.push({ id: d.id, ...d.data() } as Campaign);
    });
    return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'campaigns');
  }
}

/**
 * Super Admin: Verify campaign UTR & payment and Set to 'active' (Accept video into live feed)
 */
export async function setCampaignActive(campaignId: string): Promise<void> {
  const campRef = doc(db, 'campaigns', campaignId);
  try {
    await updateDoc(campRef, {
      status: 'active',
      super_admin_accepted: true
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `campaigns/${campaignId}`);
  }
}

/**
 * Super Admin: Explicitly Accept video campaign to release to public feed
 */
export async function acceptCampaign(campaignId: string): Promise<void> {
  const campRef = doc(db, 'campaigns', campaignId);
  try {
    await updateDoc(campRef, {
      status: 'active',
      super_admin_accepted: true
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `campaigns/${campaignId}`);
  }
}

/**
 * Super Admin: Reject video campaign with optional reason
 */
export async function rejectCampaign(campaignId: string, reason?: string): Promise<void> {
  const campRef = doc(db, 'campaigns', campaignId);
  try {
    await updateDoc(campRef, {
      status: 'rejected',
      super_admin_accepted: false,
      super_admin_decision_reason: reason || 'Video not approved by Super Admin'
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `campaigns/${campaignId}`);
  }
}

/**
 * Super Admin: Get all withdrawal requests for Payout Desk
 */
export async function getAllWithdrawals(): Promise<Withdrawal[]> {
  try {
    const snap = await getDocs(collection(db, 'withdrawals'));
    const list: Withdrawal[] = [];
    snap.forEach((d) => {
      list.push({ id: d.id, ...d.data() } as Withdrawal);
    });
    return list.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'withdrawals');
  }
}

/**
 * Super Admin: Mark a withdrawal request as 'paid'
 * Permanently deducts the amount from the user's locked escrow
 */
export async function markWithdrawalPaid(withdrawalId: string, userUid: string, amount: number): Promise<void> {
  const withdrawalRef = doc(db, 'withdrawals', withdrawalId);
  const userRef = doc(db, 'users', userUid);

  try {
    await runTransaction(db, async (t) => {
      const userSnap = await t.get(userRef);
      if (userSnap.exists()) {
        const userData = userSnap.data();
        const currentEscrow = userData.escrow_locked || 0;
        const newEscrow = Math.max(0, currentEscrow - amount);
        t.update(userRef, { escrow_locked: newEscrow });
      }

      t.update(withdrawalRef, {
        status: 'paid',
        paidAt: new Date().toISOString()
      });
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `withdrawals/${withdrawalId}`);
  }
}

/**
 * Super Admin: Delete a withdrawal record (e.g. demo / cleared records)
 */
export async function deleteWithdrawal(withdrawalId: string): Promise<void> {
  const withdrawalRef = doc(db, 'withdrawals', withdrawalId);
  try {
    const { deleteDoc } = await import('firebase/firestore');
    await deleteDoc(withdrawalRef);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `withdrawals/${withdrawalId}`);
  }
}

