import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User,
  auth,
  googleProvider,
  signInWithPopup,
  signOut,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  db,
  SUPER_ADMIN_EMAIL,
  handleFirestoreError
} from '../lib/firebase';
import { doc, getDoc, setDoc, onSnapshot } from 'firebase/firestore';
import { UserDoc, UserRole, OperationType } from '../types';

interface AuthContextType {
  currentUser: User | null;
  userProfile: UserDoc | null;
  role: UserRole;
  isSuperAdmin: boolean;
  loading: boolean;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, pass: string) => Promise<void>;
  signUpWithEmail: (email: string, pass: string) => Promise<void>;
  quickLoginAsAdmin: () => Promise<void>;
  quickLoginAsUser: (email?: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserDoc | null>(null);
  const [loading, setLoading] = useState(true);

  // Sync auth state
  useEffect(() => {
    let unsubscribeSnapshot: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);

      if (unsubscribeSnapshot) {
        unsubscribeSnapshot();
        unsubscribeSnapshot = null;
      }

      if (user) {
        const userRef = doc(db, 'users', user.uid);
        const userEmail = (user.email || '').toLowerCase().trim();
        const isSuperAdminEmail = userEmail === SUPER_ADMIN_EMAIL.toLowerCase();

        try {
          const snap = await getDoc(userRef);
          if (!snap.exists()) {
            const initialDoc: UserDoc = {
              uid: user.uid,
              email: user.email || '',
              role: isSuperAdminEmail ? 'super_admin' : 'user',
              wallet_balance: 0,
              escrow_locked: 0,
              completed_quizzes: [],
              displayName: user.displayName || user.email?.split('@')[0] || 'User',
              photoURL: user.photoURL || '',
              createdAt: new Date().toISOString(),
            };
            await setDoc(userRef, initialDoc);
            setUserProfile(initialDoc);
          } else {
            const data = snap.data() as UserDoc;
            // Ensure hardcoded super admin always has super_admin role
            if (isSuperAdminEmail && data.role !== 'super_admin') {
              await setDoc(userRef, { role: 'super_admin' }, { merge: true });
              data.role = 'super_admin';
            }
            setUserProfile(data);
          }
        } catch (error) {
          console.error('Error fetching/creating user doc:', error);
        }

        // Real-time listener for user profile changes (wallet updates, escrow, role changes)
        unsubscribeSnapshot = onSnapshot(
          userRef,
          (docSnap) => {
            if (docSnap.exists()) {
              const data = docSnap.data() as UserDoc;
              if (isSuperAdminEmail && data.role !== 'super_admin') {
                data.role = 'super_admin';
              }
              setUserProfile(data);
            }
          },
          (error) => {
            handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
          }
        );
      } else {
        setUserProfile(null);
      }
      setLoading(false);
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeSnapshot) unsubscribeSnapshot();
    };
  }, []);

  const signInWithGoogle = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err: unknown) {
      console.error('Google Sign-In Error:', err);
      throw err;
    }
  };

  const signInWithEmail = async (email: string, pass: string) => {
    await signInWithEmailAndPassword(auth, email, pass);
  };

  const signUpWithEmail = async (email: string, pass: string) => {
    await createUserWithEmailAndPassword(auth, email, pass);
  };

  // Helper for direct sign-in as Super Admin (if iframe restricts popups)
  const quickLoginAsAdmin = async () => {
    try {
      await signInWithEmailAndPassword(auth, SUPER_ADMIN_EMAIL, 'Admin@VidQuest2026!');
    } catch {
      try {
        await createUserWithEmailAndPassword(auth, SUPER_ADMIN_EMAIL, 'Admin@VidQuest2026!');
      } catch {
        // Fallback to Google Popup
        await signInWithGoogle();
      }
    }
  };

  // Helper for test user
  const quickLoginAsUser = async (testEmail = 'creator.tester@vidquest.io') => {
    try {
      await signInWithEmailAndPassword(auth, testEmail, 'User@VidQuest2026!');
    } catch {
      try {
        await createUserWithEmailAndPassword(auth, testEmail, 'User@VidQuest2026!');
      } catch (e) {
        console.error('Test user login error', e);
      }
    }
  };

  const logout = async () => {
    await signOut(auth);
    setUserProfile(null);
  };

  const isSuperAdmin = Boolean(
    currentUser?.email &&
    currentUser.email.toLowerCase() === SUPER_ADMIN_EMAIL.toLowerCase()
  );

  const role: UserRole = isSuperAdmin
    ? 'super_admin'
    : userProfile?.role || 'user';

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        role,
        isSuperAdmin,
        loading,
        signInWithGoogle,
        signInWithEmail,
        signUpWithEmail,
        quickLoginAsAdmin,
        quickLoginAsUser,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
